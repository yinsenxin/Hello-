# 【Summary】 #
Machine management service
The service is mainly used to manage Machine, Model, Design, Profile and Device related information
When automated test runs, you need to assign test cases based on this information
In addition, the service also provides the model version management function of Firm

# 【Environment installation】 #
[Go to Wiki](/../../wiki/wikis/flextestcore)

# 【Begin to develop】 #
[Go to Wiki](/../../wiki/wikis/flextestcore)

# 【Test】 #
测试环境&Debug（参照[共通链接](http://null)）

# 【Directory structure & description】 #
## 1.Component diagram ##
请参照：![ms-machinemanage][machinemanage]

[machinemanage]: ./img/ms-machinemanage.png "ms-machinemanage"
## 2.Directory structure ##

```
├─main
│  ├─java
│  │  └─jp
│  │      └─co
│  │          └─brother
│  │              └─machinemanage
│  │                  │  MachineManageApplication.java				//启动类
│  │                  │
│  │                  ├─aspect
│  │                  │      RestControllerAspect.java				//切面类
│  │                  │
│  │                  ├─config
│  │                  │      CorsConfig.java					//解决JS跨域访问的问题
│  │                  │      FeignConfig.java					//Fegin的配置文件
│  │                  │      QuartzConfig.java					//周期任务的配置文件
│  │                  │      RestTemplateConfig.java				//Http连接池的配置文件
│  │                  │      SwaggerConfig.java					//Swagger的配置文件
│  │                  │
│  │                  ├─constant						
│  │                  │      Constant.java					//常量的定义
│  │                  │      ProfileType.java					//Profile类型的定义
│  │                  │      UpdateStrategy.java				//Firmware更新策略定义
│  │                  │
│  │                  ├─controller		
│  │                  │      DesignController.java				//Design管理相关Web接口
│  │                  │      DeviceController.java				//Device管理相关Web接口
│  │                  │      FreeMarkerController.java				
│  │                  │      MachineController.java				//Machine管理相关Web接口
│  │                  │      ModelController.java				//Model管理相关Web接口
│  │                  │      ProfileController.java				//Profile管理相关Web接口
│  │                  │
│  │                  ├─domain							//实体类的定义
│  │                  │      DesignDO.java
│  │                  │      DeviceDO.java
│  │                  │      MachineDO.java
│  │                  │      ModelDO.java
│  │                  │      ModelFirmwareDO.java
│  │                  │      ProfileDO.java
│  │                  │
│  │                  ├─exception											
│  │                  │      ControllerExceptionHandler.java			//异常处理
│  │                  │      DataIsLockedException.java		                //自定义异常 -- 当前机器已经被其他用户锁定
│  │                  │      DataNotFoundException.java				//自定义异常 -- 未找到指定的数据
│  │                  │      KeyAlreadyExistsException.java			//自定义异常 -- 给定的主键名称已经存在(主键必须保证唯一性)
│  │                  │
│  │                  ├─pojo	  					        //各种POJO定义
│  │                  │      DesignPojo.java
│  │                  │      DesignStatusPojo.java
│  │                  │      DevicePojo.java
│  │                  │      DeviceStatusPojo.java
│  │                  │      MachinePojo.java
│  │                  │      MachineStatusPojo.java
│  │                  │      ModelFirmwarePojo.java
│  │                  │      ModelPojo.java
│  │                  │      ModelStatusPojo.java
│  │                  │      ProfilePojo.java
│  │                  │      ProfileStatusPojo.java
│  │                  │
│  │                  ├─proxy												
│  │                  │      MachineApiRouter.java			      //机器路由服务相关的接口
│  │                  │      ServiceRouter.java				      //服务路由相关的接口
│  │                  │
│  │                  ├─quartz
│  │                  │      CheckHeartBeatJob.java			      //检测Device是否在线的周期任务（不间断定期运行）
│  │                  │      CheckMachineLockExpiredJob.java		      //检测Machine的锁定状态是否过期的周期任务（不间断定期运行） 
│  │                  │      DesignRelevantJob.java			      //Design数据变更时触发的任务（触发后只运行一次）
│  │                  │      DeviceRelevantJob.java		              //Device数据变更时触发的任务（触发后只运行一次）
│  │                  │      MachineRelevantJob.java			      //Machine数据变更时触发的任务（触发后只运行一次）
│  │                  │      ModelRelevantJob.java			      //Model数据变更时触发的任务（触发后只运行一次）
│  │                  │      ProfileRelevantJob.java			      //Profile数据变更时触发的任务（触发后只运行一次）
│  │                  │
│  │                  ├─service
│  │                  │      DesignManager.java		        	      //Design数据管理模块
│  │                  │      DeviceManager.java		            	      //Device数据管理模块
│  │                  │      MachineManager.java							//Machine数据管理模块
│  │                  │      ModelManager.java				      //Model数据管理模块
│  │                  │      MyJobFactory.java				      //创建周期任务的实例
│  │                  │      ProfileManager.java			      //Profile数据管理模块
│  │                  │      QuartzManager.java				      //用于触发周期任务
│  │                  │
│  │                  ├─utils
│  │                  │      Base64ImageUtils.java		              //Base64数据与图片数据互相转换的工具类
│  │                  │      ExpressionEvaluator.java			      //用于判断机器是否满足指定条件的工具类的入口（通过将机器的实际状况代入表达式中，然后计算表达式的值）
│  │                  │      ExpressionException.java			      //用于判断机器是否满足指定条件的工具类
│  │                  │      ExpressionNode.java			      //用于判断机器是否满足指定条件的工具类
│  │                  │      ExpressionNodeType.java			      //用于判断机器是否满足指定条件的工具类
│  │                  │      ExpressionParser.java			      //用于判断机器是否满足指定条件的工具类
│  │                  │      GetRequestMappingValue.java	
│  │                  │      MongoDBUtils.java			              //MongoDB操作工具类
│  │                  │      RedisUtils.java								//Redis操作工具类
│  │                  │      StartupRunner.java				      //程序启动完毕之后执行的处理（只执行一次）
│  │                  │      ZipFileUtils.java				      //文件压缩/解压工具类
│  │                  │
│  │                  └─vo                 				      //数据转换的VO类
│  │                          ResultVO.java
│  │                          UploadedFirmwareVO.java
│  │
```

# 【Others】 #
* [issues](/../../flextestcore/issues)