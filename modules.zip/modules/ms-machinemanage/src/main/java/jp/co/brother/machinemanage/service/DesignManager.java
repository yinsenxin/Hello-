package jp.co.brother.machinemanage.service;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;

import javax.servlet.http.HttpServletResponse;

import org.apache.commons.io.FileUtils;
import org.apache.commons.lang.StringUtils;
import org.joda.time.DateTime;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;
import org.springframework.util.Assert;
import org.springframework.web.multipart.MultipartFile;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;

import jp.co.brother.machinemanage.constant.Constant;
import jp.co.brother.machinemanage.domain.DesignDO;
import jp.co.brother.machinemanage.exception.DataNotFoundException;
import jp.co.brother.machinemanage.pojo.DesignPojo;
import jp.co.brother.machinemanage.utils.Base64ImageUtils;
import jp.co.brother.machinemanage.utils.MongoDBUtils;
import jp.co.brother.machinemanage.utils.ZipFileUtils;
import jp.co.brother.machinemanage.vo.ResultVO;

@Component
public class DesignManager {

    @Autowired
    private MongoDBUtils<DesignDO> mongoDBUtils;
    @Autowired
    private QuartzManager quartzManager;
    @Autowired
    private Base64ImageUtils base64ImageUtils;
    @Autowired
    private ZipFileUtils zipFileUtils;

    @Value("${designimage.location}")
    private String FILE_PATH;
    @Value("${server.port}")
    private String serverPort;
    private static final Logger logger = LoggerFactory.getLogger(DesignManager.class);

    /**
     * Get all design data with no condition.
     * 
     * @return
     */
    public ResultVO getDesignData() {
        List<DesignPojo> designPojos = new ArrayList<>();
        /* Get data from mongoDB */
        List<DesignDO> designDOs = mongoDBUtils.findAll(DesignDO.class);
        /* Convert to POJO */
        for (DesignDO designDO : designDOs) {
            if (Objects.isNull(designDO)) {
                logger.warn("Invalid document");
                continue;
            }
            /* DO => POJO */
            DesignPojo design = domainToPojo(designDO);
            designPojos.add(design);
        }

        ResultVO result = new ResultVO(HttpStatus.OK);
        result.setData(designPojos);
        return result;
    }

    /**
     * Get the design data of the specified design.
     * 
     * @param designId ID of the specified design
     * @return
     * @throws IllegalArgumentException
     */
    public ResultVO getDesignData(String designId) {
        /* Check input parameter, make sure they are not null */
        Assert.notNull(designId, "DesignId must not be null!");

        ResultVO result = new ResultVO(HttpStatus.OK);
        /* Make search criteria */
        Query query = new Query();
        query.addCriteria(Criteria.where("designId").is(designId));
        /* Search data */
        DesignDO designDO = mongoDBUtils.findOne(query, DesignDO.class);
        if (Objects.nonNull(designDO)) {
            /* DO => POJO */
            DesignPojo design = domainToPojo(designDO);
            result.setData(design);
        } else {
            throw new DataNotFoundException("Target data not found!");
        }
        return result;
    }

    /**
     * Add a new design record.
     * 
     * @param designData design data
     * @return
     * @throws IllegalArgumentException
     */
    public ResultVO addDesignData(DesignPojo designData) {
        /* Check input parameter, make sure they are not null */
        Assert.notNull(designData, "Body of this request must not be null!");
        Assert.hasLength(designData.getDesignId(), "\"designId\" in the body must not be null or empty!");
        Assert.notNull(designData.getImageData(), "\"imageData\" in the body must not be null!");
        Assert.notNull(designData.getKeys(), "\"keys\" in the body must not be null!");
        Assert.notNull(designData.getScreen(), "\"screen\" in the body must not be null!");
        Assert.notNull(designData.getTouchPanel(), "\"touchPanel\" in the body must not be null!");

        /* Convert POJO to DO */
        DesignDO designDO = pojoToDomain(designData);
        /* Make search criteria */
        Query query = new Query();
        query.addCriteria(Criteria.where("designId").is(designDO.getDesignId()));
        /* Check if the target data exist */
        if (mongoDBUtils.exists(query, DesignDO.class)) {
            /* Replace old record */
            replaceOldRecord(designDO.getDesignId(), designDO);
        } else {
            /* Save new data */
            mongoDBUtils.insert(designDO);
        }

        /* Start a new thread to update the relevant data */
        quartzManager.updateDesignRelevantData(new String[] { designData.getDesignId() });

        return new ResultVO(HttpStatus.OK);
    }

    /**
     * Update the specified design record with the given design data.
     * 
     * @param designId   ID of the specified design
     * @param designData design data
     * @return
     * @throws IllegalArgumentException
     */
    public ResultVO updateDesignData(String designId, DesignPojo designData) {
        /* Check input parameter, make sure they are not null */
        Assert.notNull(designId, "DesignId must not be null!");
        Assert.notNull(designData, "Body of this request must not be null!");
        Assert.hasLength(designData.getDesignId(), "\"designId\" in the body must not be null or empty!");
        Assert.notNull(designData.getImageData(), "\"imageData\" in the body must not be null!");
        Assert.notNull(designData.getKeys(), "\"keys\" in the body must not be null!");
        Assert.notNull(designData.getScreen(), "\"screen\" in the body must not be null!");
        Assert.notNull(designData.getTouchPanel(), "\"touchPanel\" in the body must not be null!");

        ResultVO result = new ResultVO(HttpStatus.OK);
        /* Make search criteria */
        Query query = new Query();
        query.addCriteria(Criteria.where("designId").is(designId));
        /* Check if the target data exist */
        if (mongoDBUtils.exists(query, DesignDO.class)) {
            if (!designId.equals(designData.getDesignId())) {
                /* Check if the new designId already exist */
                Query query1 = new Query();
                query1.addCriteria(Criteria.where("designId").is(designData.getDesignId()));
                if (mongoDBUtils.exists(query1, DesignDO.class)) {
                    throw new IllegalArgumentException("The \"designId\" in the body has already been used!");
                }
            }

            /* Convert POJO to DO */
            DesignDO designDO = pojoToDomain(designData);
            /* Replace old record */
            replaceOldRecord(designId, designDO);
            /* Start a new thread to update the relevant data */
            quartzManager.updateDesignRelevantData(new String[] { designId, designData.getDesignId() });
        } else {
            throw new DataNotFoundException("Target data not found!");
        }

        return result;
    }

    /**
     * Delete the specified design record with the given designIds.
     * 
     * @param designIds ID of the specified designs
     * @return
     * @throws IllegalArgumentException
     */
    public ResultVO deleteDesignData(String[] designIds) {
        /* Check input parameter, make sure they are not null */
        Assert.notEmpty(designIds, "DesignIds must not be empty!");

        ResultVO result = new ResultVO(HttpStatus.OK);
        /* Make search criteria */
        Query query = new Query();
        query.addCriteria(Criteria.where("designId").in((Object[]) designIds));
        /* Delete data */
        List<DesignDO> deletedDatas = new ArrayList<>();
        deletedDatas = mongoDBUtils.findAllAndRemove(query, DesignDO.class);
        /* Analyze result */
        Map<String, Boolean> hMap = new HashMap<>();
        for (DesignDO designDO : deletedDatas) {
            if (Objects.isNull(designDO)) {
                logger.warn("Invalid document");
                continue;
            }
            /* Delete image data */
            if (StringUtils.isNotBlank(designDO.getImagePath())) {
                deleteLocalImage(designDO.getImagePath());
            }
            hMap.put(designDO.getDesignId(), true);
        }
        for (String designId : designIds) {
            if (!hMap.containsKey(designId)) {
                hMap.put(designId, false);
            }
        }
        result.setData(hMap);

        /* Start a new thread to update the relevant data */
        quartzManager.updateDesignRelevantData(designIds);

        return result;
    }

    /**
     * Download the design data of the specified designs.
     * 
     * @param response  response data of current HTTP request
     * @param designIds ID of the specified designs
     * @return
     */
    public ResultVO exportDesignData(HttpServletResponse response, String[] designIds) {
        /* Get all design data */
        List<DesignDO> designDOs = mongoDBUtils.findAll(DesignDO.class);
        designDOs.removeAll(Collections.singleton(null));

        /* Get target design data */
        List<DesignDO> targetDatas = new ArrayList<>();
        if (Objects.nonNull(designIds) && designIds.length > 0) {
            for (DesignDO designDO : designDOs) {
                String designId = designDO.getDesignId();
                if (Arrays.asList(designIds).contains(designId)) {
                    targetDatas.add(designDO);
                }
            }
        } else {
            targetDatas.addAll(designDOs);
        }

        /*********************************************/
        /* Save the target design data to a ZIP file */
        /*********************************************/
        String rootDirectoryName = "DesignExport_" + DateTime.now().toString(Constant.DATEFMT_FILE_NAME);
        String zipFileName = rootDirectoryName + ".zip";
        String dbFileName = rootDirectoryName + ".json";
        String dbFilePath = rootDirectoryName + "/" + dbFileName;
        String imageDirectoryName = rootDirectoryName + "/image/";
        try {
            /* Copy relevant image file */
            File imgDir = new File(imageDirectoryName);
            imgDir.mkdirs();
            for (DesignDO designDO : targetDatas) {
                /* Absolute path */
                String srcPath = designDO.getImagePath();
                String dstPath = imgDir.getAbsolutePath() + srcPath.substring(srcPath.lastIndexOf(File.separator));
                /* Modify the image path to a path relative to the current JSON file */
                designDO.setImagePath("image/" + srcPath.substring(srcPath.lastIndexOf(File.separator) + 1));
                try {
                    FileUtils.copyFile(new File(srcPath), new File(dstPath));
                } catch (Exception e) {
                    logger.info("Error occurred while copy design image");
                    logger.info("srcPath: {}", srcPath);
                    logger.info("dstPath: {}", dstPath);
                }
            }

            /* Make directory & create JSON file */
            File dbFile = new File(dbFilePath);
            dbFile.getParentFile().mkdirs();
            dbFile.createNewFile();

            FileWriter dbFileWriter = new FileWriter(dbFile);
            dbFileWriter.write(JSONObject.toJSONString(targetDatas));
            dbFileWriter.flush();
            dbFileWriter.close();

            /* ZIP target directory */
            zipFileUtils.zipFileWithTier(rootDirectoryName, zipFileName);

            /* Make response */
            File zipFile = new File(zipFileName);
            if (zipFile.exists()) {
                InputStream fis = new BufferedInputStream(new FileInputStream(zipFile.getAbsolutePath()));
                byte[] buffer = new byte[fis.available()];
                fis.read(buffer);
                fis.close();

                response.reset();
                response.setHeader("Content-Disposition", "attachment;fileName=" + zipFileName);
                response.addHeader("Content-Length", "" + zipFile.length());
                OutputStream toClient = new BufferedOutputStream(response.getOutputStream());
                response.setContentType("application/octet-stream");
                toClient.write(buffer);
                toClient.flush();
                toClient.close();
            }
        } catch (Exception e) {
            logger.info("Error occurred while export design data");
            logger.error("{}: {}", e.getClass().getName(), e.getMessage());
            e.printStackTrace();
        } finally {
            /* Delete local ZIP file */
            File zipFile = new File(zipFileName);
            if (zipFile.exists()) {
                zipFile.delete();
            }
            /* Delete local root directory */
            try {
                FileUtils.deleteDirectory(new File(rootDirectoryName));
            } catch (IOException e) {
                logger.info("Error occurred while deleting the temporary folder");
                logger.error("{}: {}", e.getClass().getName(), e.getMessage());
                e.printStackTrace();
            }
        }

        return null;
    }

    /**
     * Import design data.
     * 
     * @param file design data
     * @return
     */
    public ResultVO importDesignData(MultipartFile file) {
        ResultVO result = new ResultVO(HttpStatus.OK);
        JSONObject topContainer = new JSONObject();

        /* If the uploaded file is not empty */
        if (!file.isEmpty()) {
            /* Get file name */
            String zipFileName = file.getOriginalFilename()
                    .substring(file.getOriginalFilename().lastIndexOf(File.separator) + 1);
            /* Directory to store the temporary data */
            String tmpRootDir = zipFileName.substring(0, zipFileName.indexOf("."));
            /* ID of the design data that was successfully imported */
            List<String> designIds = new ArrayList<>();

            try {
                /* Read the uploaded ZIP file */
                File zipFile = new File(zipFileName);
                /* Caution: The path of the function MUST BE an absolute path */
                file.transferTo(new File(zipFile.getAbsolutePath()));

                /* Extract ZIP files */
                zipFileUtils.unZipFile(zipFile.getAbsolutePath(), tmpRootDir);

                /* Try to find a JSON file */
                List<File> fileList = getAllJsonFile(new File(tmpRootDir));
                if (!fileList.isEmpty()) {
                    /* Read JSON file */
                    File jsonFile = fileList.get(0);
                    InputStream fis = new BufferedInputStream(new FileInputStream(jsonFile));
                    byte[] buffer = new byte[fis.available()];
                    fis.read(buffer);
                    fis.close();

                    /* Convert JSON string to DesignDO object */
                    String jsonfileContent = new String(buffer, StandardCharsets.UTF_8);
                    List<DesignDO> designDOs = JSONObject.parseArray(jsonfileContent, DesignDO.class);
                    if (Objects.nonNull(designDOs)) {
                        JSONArray detail = new JSONArray();
                        designDOs.removeAll(Collections.singleton(null));
                        for (DesignDO designDO : designDOs) {
                            JSONObject errorInfo = new JSONObject();
                            /* Check design ID */
                            String designId = designDO.getDesignId();
                            if (StringUtils.isBlank(designId)) {
                                errorInfo.put("id", designId);
                                errorInfo.put("reason", "\"designId\" must not be null/\"\"");
                                detail.add(errorInfo);
                                continue;
                            }
                            /* Check image path */
                            String imagePath = designDO.getImagePath();
                            if (StringUtils.isBlank(imagePath)) {
                                errorInfo.put("id", designId);
                                errorInfo.put("reason", "\"imagePath\" must not be null/\"\"");
                                detail.add(errorInfo);
                                continue;
                            }
                            /* Check if the designId already exists */
                            Query query = new Query();
                            query.addCriteria(Criteria.where("designId").is(designId));
                            if (mongoDBUtils.exists(query, DesignDO.class)) {
                                errorInfo.put("id", designId);
                                errorInfo.put("reason", "\"designId\" already exists in DataBase");
                                detail.add(errorInfo);
                                continue;
                            }

                            /* Move image(Rename the image) */
                            String srcPath = jsonFile.getParentFile().getAbsolutePath() + "/" + imagePath;
                            String dstPath = (FILE_PATH.endsWith("/") ? FILE_PATH : FILE_PATH + "/")
                                    + DateTime.now().toString(Constant.DATEFMT_FILE_NAME)
                                    + imagePath.substring(imagePath.lastIndexOf("."));
                            try {
                                FileUtils.copyFile(new File(srcPath), new File(dstPath));
                            } catch (Exception e) {
                                errorInfo.put("id", designId);
                                errorInfo.put("reason", "Error occurred while copy design image");
                                detail.add(errorInfo);
                                continue;
                            }

                            /* Save data */
                            designDO.setImagePath(dstPath.replace("/", File.separator));
                            designDO.setLastModifyTime(DateTime.now().toString(Constant.DATEFMT_UPDATE_TIME));

                            mongoDBUtils.insert(designDO);
                            designIds.add(designId);
                        }

                        if (!detail.isEmpty()) {
                            topContainer.put("result", "NG");
                            topContainer.put("detail", detail);
                            result.setData(topContainer);
                        } else {
                            topContainer.put("result", "OK");
                            result.setData(topContainer);
                        }
                    } else {
                        topContainer.put("result", "NG");
                        topContainer.put("reason", "No valid design data");
                        result.setData(topContainer);
                    }
                } else {
                    topContainer.put("result", "NG");
                    topContainer.put("reason", "JSON file not found");
                    result.setData(topContainer);
                }
            } catch (Exception e) {
                logger.error("Error occurred while import design data");
                logger.error("{}: {}", e.getClass().getName(), e.getMessage());
                e.printStackTrace();
                topContainer.put("result", "NG");
                topContainer.put("reason", "Internal exception: " + e.getMessage());
                result.setData(topContainer);
            } finally {
                /* Delete local ZIP file */
                File zipFile = new File(zipFileName);
                if (zipFile.exists()) {
                    zipFile.delete();
                }
                /* Delete local root directory */
                try {
                    FileUtils.deleteDirectory(new File(tmpRootDir));
                } catch (IOException e) {
                    logger.info("Error occurred while deleting the temporary folder");
                    logger.error("{}: {}", e.getClass().getName(), e.getMessage());
                    e.printStackTrace();
                }
                /* Start a new thread to update the relevant data */
                quartzManager.updateDesignRelevantData(designIds.toArray(new String[0]));
            }
        } else {
            topContainer.put("result", "NG");
            topContainer.put("reason", "Empty file is uploaded.");
            result.setData(topContainer);
        }

        return result;
    }

    /**
     * Get the design image path of the specified design.
     * 
     * @param designId ID of the specified design
     * @return
     */
    public ResultVO getDesignImageURI(String designId) {
        /* Check input parameter, make sure they are not null */
        Assert.notNull(designId, "DesignId must not be null!");

        ResultVO result = new ResultVO(HttpStatus.OK);
        /* Make search criteria */
        Query query = new Query();
        query.addCriteria(Criteria.where("designId").is(designId));
        /* Search data */
        DesignDO designDO = mongoDBUtils.findOne(query, DesignDO.class);
        if (Objects.nonNull(designDO)) {
            /* get server IP */
            String IP = "APBSH0898";
            try {
                IP = InetAddress.getLocalHost().getHostName();
            } catch (UnknownHostException e) {
                logger.error("Failed to get the host name");
                e.printStackTrace();
            }

            /* Get image path */
            String imagePath = designDO.getImagePath();
            imagePath = imagePath.replace(File.separator, "/");
            /* get image's URI.(http://ip:port/runID/type/taskID_suitID_caseID.jpg) */
            String URI = imagePath.replaceFirst(FILE_PATH, String.format("http://%s:%s/", IP, serverPort));
            result.setData(URI);
        } else {
            throw new DataNotFoundException("Target data not found!");
        }
        return result;
    }

    /**
     * Get all designs that meet the specified condition
     * 
     * @param designIds ID of the target designs
     * @param datas     The field that needs to be returned
     * @return
     */
    public ResultVO queryDesignData(String[] designIds, String[] datas) {
        /* Make response */
        ResultVO result = new ResultVO(HttpStatus.OK);

        /* Query data */
        List<DesignPojo> designPojos = queryDesignDataByContent(designIds, datas);
        /* Make response data */
        if (Objects.nonNull(datas)) {
            List<Map<String, Object>> responseDatas = new ArrayList<>();
            List<String> names = Arrays.asList(datas);
            for (DesignPojo designPojo : designPojos) {
                Map<String, Object> map = new HashMap<>();
                if (names.contains("designId")) {
                    map.put("designId", designPojo.getDesignId());
                }
                if (names.contains("imageData")) {
                    map.put("imageData", designPojo.getImageData());
                }
                if (names.contains("keys")) {
                    map.put("keys", designPojo.getKeys());
                }
                if (names.contains("screen")) {
                    map.put("screen", designPojo.getScreen());
                }
                if (names.contains("touchPanel")) {
                    map.put("touchPanel", designPojo.getTouchPanel());
                }
                if (names.contains("lastModifyTime")) {
                    map.put("lastModifyTime", designPojo.getLastModifyTime());
                }
                responseDatas.add(map);
            }
            result.setData(responseDatas);
        } else {
            result.setData(designPojos);
        }

        return result;
    }

    /**
     * Search design data with specified content.
     * 
     * @param designIds
     * @param datas
     * @return
     */
    public List<DesignPojo> queryDesignDataByContent(String[] designIds, String[] datas) {
        List<DesignPojo> designPojos = new ArrayList<>();
        /* Make search criteria */
        Query query = new Query();
        if (Objects.nonNull(designIds) && designIds.length > 0) {
            query.addCriteria(Criteria.where("designId").in((Object[]) designIds));
        }

        datas = Objects.isNull(datas)
                ? new String[] { "designId", "imageData", "keys", "screen", "touchPanel", "lastModifyTime" }
                : datas;
        List<String> items = Arrays.asList(datas);
        List<DesignDO> designDOs = mongoDBUtils.find(query, DesignDO.class);
        for (DesignDO designDO : designDOs) {
            DesignPojo designPojo = new DesignPojo();
            if (items.contains("designId")) {
                designPojo.setDesignId(designDO.getDesignId());
            }
            if (items.contains("imageData")) {
                String base64 = null;
                String imagePath = designDO.getImagePath();
                try {
                    base64 = base64ImageUtils.encodeImageToBase64(imagePath);
                } catch (Exception e) {
                    logger.error("Error occurred while convert image to base64 data. imagePath: {}", imagePath);
                    logger.error("{} : {}", e.getClass().getName(), e.getMessage());
                }
                designPojo.setImageData(base64);
            }
            if (items.contains("keys")) {
                designPojo.setKeys(designDO.getKeys());
            }
            if (items.contains("screen")) {
                designPojo.setScreen(designDO.getScreen());
            }
            if (items.contains("touchPanel")) {
                designPojo.setTouchPanel(designDO.getTouchPanel());
            }
            if (items.contains("lastModifyTime")) {
                designPojo.setLastModifyTime(designDO.getLastModifyTime());
            }

            designPojos.add(designPojo);
        }
        return designPojos;
    }

    private List<File> getAllJsonFile(File file) {
        List<File> result = new ArrayList<>();
        if (file.exists()) {
            File[] files = file.listFiles();
            if (Objects.nonNull(files)) {
                for (File subFile : files) {
                    if (subFile.isDirectory()) {
                        result.addAll(getAllJsonFile(subFile));
                    } else {
                        String fileExt = subFile.getName().substring(subFile.getName().lastIndexOf(".") + 1);
                        if (fileExt.equalsIgnoreCase("json")) {
                            result.add(subFile);
                        }
                    }
                }
            }
        }
        return result;
    }

    /**
     * DO => POJO
     * 
     * @param designDO
     * @return
     */
    private final DesignPojo domainToPojo(DesignDO designDO) {
        DesignPojo designPojo = new DesignPojo();

        String base64 = null;
        String imagePath = designDO.getImagePath();
        try {
            base64 = base64ImageUtils.encodeImageToBase64(imagePath);
        } catch (Exception e) {
            logger.error("Error occurred while convert image to base64 data. imagePath: {}", imagePath);
            logger.error("{} : {}", e.getClass().getName(), e.getMessage());
        }
        designPojo.setDesignId(designDO.getDesignId());
        designPojo.setImageData(base64);
        designPojo.setKeys(designDO.getKeys());
        designPojo.setScreen(designDO.getScreen());
        designPojo.setTouchPanel(designDO.getTouchPanel());
        designPojo.setLastModifyTime(designDO.getLastModifyTime());

        return designPojo;
    }

    /**
     * POJO => DO
     * 
     * @param designPojo
     * @return
     * @throws IllegalArgumentException
     */
    private final DesignDO pojoToDomain(DesignPojo designPojo) {
        /* Get image path */
        String imagePath = FILE_PATH.endsWith("/") ? FILE_PATH : FILE_PATH + "/";
        String imageName = DateTime.now().toString(Constant.DATEFMT_FILE_NAME);
        /* Save image data */
        String fileName = null;
        try {
            fileName = base64ImageUtils.decodeBase64ToImage(designPojo.getImageData(), imagePath, imageName);
        } catch (Exception e) {
            logger.error("Error occurred while convert base64 data to image");
            logger.error("{} : {}", e.getClass().getName(), e.getMessage());
            throw new IllegalArgumentException(
                    String.format("Illegal base64 data! %s: %s", e.getClass().getName(), e.getMessage()));
        }

        /* POJO => DO */
        DesignDO designDO = new DesignDO();
        designDO.setDesignId(designPojo.getDesignId());
        designDO.setImagePath(Objects.isNull(fileName) ? "" : fileName);
        designDO.setKeys(designPojo.getKeys());
        designDO.setScreen(designPojo.getScreen());
        designDO.setTouchPanel(designPojo.getTouchPanel());
        designDO.setLastModifyTime(DateTime.now().toString(Constant.DATEFMT_UPDATE_TIME));
        return designDO;
    }

    /**
     * Replace the old data with the new data.(Which means the old data is exist)
     * 
     * @param oldDesignId ID of the old design data
     * @param designDO    New design data
     */
    private void replaceOldRecord(String oldDesignId, DesignDO designDO) {
        /* Make search criteria */
        Query query = new Query();
        query.addCriteria(Criteria.where("designId").is(oldDesignId));

        /* Delete old image file first */
        DesignDO oldDesign = mongoDBUtils.findOne(query, DesignDO.class);
        String oldImagePath = oldDesign.getImagePath();
        if (StringUtils.isNotBlank(oldImagePath)) {
            deleteLocalImage(oldImagePath);
        }

        /* Make update */
        Update update = new Update();
        update.set("designId", designDO.getDesignId());
        update.set("imagePath", designDO.getImagePath());
        update.set("keys", designDO.getKeys());
        update.set("screen", designDO.getScreen());
        update.set("touchPanel", designDO.getTouchPanel());
        update.set("lastModifyTime", designDO.getLastModifyTime());
        /* Update data */
        mongoDBUtils.upsert(query, update, DesignDO.class);
    }

    /**
     * Delete specified file.
     * 
     * @param imagePath
     */
    private void deleteLocalImage(String imagePath) {
        File file = new File(imagePath);
        if (file.exists() && file.isFile()) {
            file.delete();
        }
    }
}
