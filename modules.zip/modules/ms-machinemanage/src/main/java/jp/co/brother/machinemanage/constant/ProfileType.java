package jp.co.brother.machinemanage.constant;

public enum ProfileType {
	DEVICE_PROFILE("device"), MODEL_PROFILE("model");

	private String value = "";

	private ProfileType(String value) {
		this.value = value;
	}

	public String getValue() {
		return value;
	}
}