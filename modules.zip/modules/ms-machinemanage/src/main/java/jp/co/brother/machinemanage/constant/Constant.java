package jp.co.brother.machinemanage.constant;

public class Constant {

    /* v0.1.0 */
    public static final String FIRMWARE_VERSION_PATTERN = "v[0-9]+\\.[0-9]+\\.[0-9]+";

    /**
     * Date time format
     */
    public static final String DATEFMT_FILE_NAME = "yyyyMMddHHmmssSSS";
    public static final String DATEFMT_UPDATE_TIME = "yyyy-MM-dd HH:mm:ss";

    /**
     * Redis key. (MM_KV_machine_lock_time)
     */
    public static final String REDIS_KEY_MACHINELOCKTIME = "MM_KV_machine_lock_time";

    /**
     * Reason of the device status
     */
    public static final String DEVSTS_DEVICE_NOTFOUND = "Device not found";
    public static final String DEVSTS_PROFILE_NOTFOUND = "Profile not found";
    public static final String DEVSTS_INTERNAL_EXCEPTION = "Internal error";
    public static final String DEVSTS_SERVICE_DISCREPANCY = "Services does not meet the profile requirements";

    /**
     * Reason of the model status
     */
    public static final String MODELSTS_MODEL_NOTFOUND = "Model not found";
    public static final String MODELSTS_DESIGN_NOTFOUND = "Design not found";
    public static final String MODELSTS_PROFILE_NOTFOUND = "Profile not found";
    public static final String MODELSTS_PROFILE_WRONGTYPE = "Model's profile type is wrong";

    /**
     * Reason of the machine status
     */
    public static final String MACHINESTS_MACHINE_NOTFOUND = "Machine not found";
    public static final String MACHINESTS_SERVICE_DISCREPANCY = "Services does not meet the profile requirements";
    
    /**
     * Database-related entity mapping fields
     */
    public static final String DBQUERY_GROUPMODEL_ID = "group_model_id";
    public static final String DBQUERY_GROUP_ID = "group_id";
    public static final String DBQUERY_GROUP_DESCRIPTION = "description";
    public static final String DBQUERY_GROUP_CONDITION = "conditions";
    public static final String DBQUERY_GROUP_SUBORDINATE = "subordinate_list";
    public static final String DBQUERY_GROUPMODEL_DESCRIPTION = "description";
    public static final String DBQUERY_GROUPMODEL_CONDITION = "conditions";
    public static final String DBQUERY_GROUPMODEL_PROFILE = "profile_list";
    
    /**
     * Assert about message
     */
    public static final String ASSERT_GROUP_MESSAGE = "\"GroupId\" in the body must not be null or empry!";
    public static final String ASSERT_GROUP_ID_MESSAGE = "\"GroupId\" must not be null";
    public static final String ASSERT_GROUPMODEL_MESSAGE = "\"GroupModelId\" in the body must not be null or empry!";
    public static final String ASSERT_GROUPMODEL_ID_MESSAGE = "\"GroupModelId\" must not be null";
    public static final String ASSERT_REQUEST_BODY = "Body of this request must not be null!";
    public static final String ASSERT_GROUPMODEL_PROFILE = "\"ProfileList\" in the body must not be null!";
    public static final String ASSERT_GROUP_SUBORDINATE = "\"SubordinateList\" in the body must not be null!";
    
    public static final String KEYWORD = "keyword";
    public static final String DB_QUERY_MACHINE_MODEL_ID = "modelId";
    
}






