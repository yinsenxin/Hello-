package jp.co.brother.machinemanage.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import jp.co.brother.machinemanage.pojo.GroupPojo;
import jp.co.brother.machinemanage.service.GroupService;
import jp.co.brother.machinemanage.vo.ResultVO;

@RestController
@RequestMapping("/groups")
public class GroupController {
	
	@Autowired
	private GroupService groupService;
	
	/**
	 * Get all Group data
	 * @param groupModelIds 
	 * @return
	 */
	@GetMapping(value = "", produces = "application/json;charset=UTF-8")
    public ResultVO getGroupInfo(@RequestParam (name = "groupModelId", required = false) String [] groupModelId) {
        return groupService.getGroupData(groupModelId);
    }
	
	/**
	 * Get specified Group data according the groupId
	 * @param groupId
	 * @return
	 */
    @GetMapping(value = "/{groupId}", produces = "application/json;charset=UTF-8")
	public ResultVO getGroupInfoById(@PathVariable(name = "groupId", required = true) String groupId) {
		return groupService.getGroupDataById(groupId);
	}
    
    /**
     * Add a Group data
     * @param groupPojo
     * @return
     */
    @PostMapping(value = "", produces = "application/json;charset=UTF-8")
    public ResultVO addGroup(@RequestBody GroupPojo groupPojo) {
    	return groupService.addGroupData(groupPojo);
    }
    
    /**
     * Delete the specified group data according to the groupIds
     * @param groupIds
     * @return
     */
    @DeleteMapping(value = "/{groupId}", produces = "application/json;charset=UTF-8")
    public ResultVO deleteGroup(@PathVariable(name = "groupId", required = true) String [] groupId) {
    	return groupService.deleteGroupData(groupId);
    }
    
    /**
     * Modify the specified Group data according the groupId and GroupPoJo
     * @param groupId
     * @param groupPojo
     * @return
     */
    @PutMapping(value = "/{groupId}", produces = "application/json;charset=UTF-8")
    public ResultVO updateGroup(@PathVariable(name = "groupId", required = true) String groupId,
    							@RequestBody(required = true) GroupPojo groupPojo) {
    	return groupService.updateGroupData(groupId, groupPojo);
    }
    
    @GetMapping(value = "/status", produces = "application/json;charset=UTF-8")
    public ResultVO getGroupStatus(@RequestParam (name = "groupIds", required = false) String [] groupIds) {
    	return groupService.getGroupStatus(groupIds);
    }
}
