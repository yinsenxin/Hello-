package jp.co.brother.machinemanage.aspect;

import java.lang.reflect.Method;

import javax.servlet.http.HttpServletRequest;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;
import org.aspectj.lang.reflect.MethodSignature;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

@Aspect
@Component
public class RestControllerAspect {
    private final static Logger logger = LoggerFactory.getLogger(RestControllerAspect.class);

    @Pointcut("execution(* jp.co.brother.machinemanage.controller..*(..)) and @annotation(org.springframework.web.bind.annotation.RequestMapping)")
    private void cut() {
    }

    /**
     * 
     * @param joinPoint
     * @return
     * @throws Throwable
     */
    @Around("cut()")
    public Object apiLog(ProceedingJoinPoint joinPoint) throws Throwable {
        MethodSignature signature = (MethodSignature) joinPoint.getSignature();
        Method method = signature.getMethod();// 获取被拦截的方法
        String methodName = method.getName(); // 获取被拦截的方法名

        ServletRequestAttributes attributes = (ServletRequestAttributes) RequestContextHolder.getRequestAttributes();
        HttpServletRequest request = attributes.getRequest();

        /* Before */
        String userAgent = request.getHeader("user-agent");
        String uriPath = request.getRequestURI() + (request.getQueryString() == null ? "" : ("?" + request.getQueryString()));
        logger.info("Started request method [{}] params [{}] userAgent [{}]", methodName, uriPath, userAgent);
        long start = System.currentTimeMillis();

        /* Proceed */
        Object result = joinPoint.proceed();

        /* After */
        logger.info("Ended request method [{}] response is [{}] cost [{}] millis ", methodName, "", System.currentTimeMillis() - start);
        return result;
    }
}
