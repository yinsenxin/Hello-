package jp.co.brother.machinemanage.domain;

import lombok.Data;

@Data
public class ModelFirmwareDO {

    /**
     * The name of the firmware
     */
    private String name;
    /**
     * The version of the firmware
     */
    private String version;
    /**
     * The description of the firmware
     */
    private String description;
    /**
     * The relative path of the firmware
     */
    private String relativePath;
    /**
     * The upload date of the firmware
     */
    private String uploadDate;
}
