package jp.co.brother.machinemanage.controller;

import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import jp.co.brother.machinemanage.pojo.ModelFirmwarePojo;
import jp.co.brother.machinemanage.pojo.ModelPojo;
import jp.co.brother.machinemanage.service.ModelManager;
import jp.co.brother.machinemanage.vo.ResultVO;
import jp.co.brother.machinemanage.vo.UploadedFirmwareVO;

@RestController
@RequestMapping("/model")
public class ModelController {

    @Autowired
    private HttpServletResponse response;
    @Autowired
    private ModelManager modelManager;

    /**
     * Get all model data with no condition.
     * 
     * @return
     */
    @GetMapping(value = "/modelInfo", produces = "application/json;charset=UTF-8")
    public ResultVO getModelInfo() {
        return modelManager.getModelData();
    }

    /**
     * Get the model data of the specified model.
     * 
     * @param modelId ID of the specified model
     * @return
     */
    @GetMapping(value = "/modelInfo/{modelId}", produces = "application/json;charset=UTF-8")
    public ResultVO getModelInfoById(@PathVariable(name = "modelId", required = true) String modelId) {
        return modelManager.getModelData(modelId);
    }

    /**
     * Add a new model record.
     * 
     * @param modelData model data
     * @return
     */
    @PutMapping(value = "/add", produces = "application/json;charset=UTF-8")
    public ResultVO addModelInfo(@RequestBody ModelPojo modelData) {
        return modelManager.addModelData(modelData);
    }

    /**
     * Update the specified model record with the given model data.
     * 
     * @param modelId   ID of the specified model
     * @param modelData model data
     * @return
     */
    @PutMapping(value = "/update/{modelId}", produces = "application/json;charset=UTF-8")
    public ResultVO updateModelInfo(@PathVariable(name = "modelId", required = true) String modelId,
            @RequestBody(required = true) ModelPojo modelData) {
        return modelManager.updateModelData(modelId, modelData);
    }

    /**
     * Delete the specified model record with the given modelIds.
     * 
     * @param modelIds ID of the specified models
     * @return
     */
    @DeleteMapping(value = "/delete", produces = "application/json;charset=UTF-8")
    public ResultVO deleteModelInfo(@RequestParam(name = "modelIds", required = true) String[] modelIds) {
        return modelManager.deleteModelData(modelIds);
    }

    /**
     * Download the model data of the specified models.
     * 
     * @param modelIds ID of the specified models
     * @return
     */
    @GetMapping(value = "/export")
    public ResultVO exportModelInfo(@RequestParam(name = "modelIds", required = true) String[] modelIds) {
        return modelManager.exportModelData(response, modelIds);
    }

    /**
     * Import model data.
     * 
     * @param file model data
     * @return
     */
    @PostMapping(value = "/import", consumes = "multipart/form-data")
    public ResultVO importModelInfo(MultipartFile file) {
        return modelManager.importModelData(file);
    }

    /**
     * Get all models that meet the specified condition
     * 
     * @param modelIds   ID of the target models
     * @param designIds  DesignId of the target models
     * @param profileIds ProfileId of the target models
     * @param datas      The field that needs to be returned
     * @return
     */
    @GetMapping(value = "/query", produces = "application/json;charset=UTF-8")
    public ResultVO queryModelInfo(@RequestParam(name = "modelIds", required = false) String[] modelIds,
            @RequestParam(name = "designIds", required = false) String[] designIds,
            @RequestParam(name = "profileIds", required = false) String[] profileIds,
            @RequestParam(name = "datas", required = false) String[] datas) {
        return modelManager.queryModelData(modelIds, designIds, profileIds, datas);
    }

    /**
     * Get all firmware data of the specified model.
     * 
     * @param modelId ID of the specified model
     * @return
     */
    @GetMapping(value = "/firmware", produces = "application/json;charset=UTF-8")
    public ResultVO getModelFirmwareInfo(@RequestParam(name = "modelId", required = true) String modelId) {
        return modelManager.getModelFirmwareData(modelId);
    }

    /**
     * Add a new firmware record to the specified model.
     * 
     * @param modelId ID of the specified model
     * @param body    The firmware data
     * @return
     */
    @PostMapping(value = "/firmware/add", produces = "application/json;charset=UTF-8")
    public ResultVO addModelFirmwareInfo(@RequestParam(name = "modelId", required = true) String modelId,
            UploadedFirmwareVO firmware) {
        return modelManager.addModelFirmwareData(modelId, firmware);
    }

    /**
     * Delete the specified firmware record with the given modelId and version.
     * 
     * @param modelId ID of the specified model
     * @param version Version of the target firmware
     * @return
     */
    @DeleteMapping(value = "/firmware/delete", produces = "application/json;charset=UTF-8")
    public ResultVO deleteModelFirmwareInfo(@RequestParam(name = "modelId", required = true) String modelId,
            @RequestParam(name = "version", required = true) String[] version) {
        return modelManager.deleteModelFirmwareData(modelId, version);
    }
    /**
     * Update the specified model record with the given model data.
     * 
     * @param modelId   ID of the specified model
     * @param modelData model data
     * @return
     */
    @PutMapping(value = "/firmware/update", produces = "application/json;charset=UTF-8")
    public ResultVO updateFirmInfo(@RequestParam(name = "modelId", required = true) String modelId,
            @RequestBody(required = true) ModelFirmwarePojo firmwarePojo) {
        return modelManager.updateModelFirmwareData(modelId, firmwarePojo);
    }
    
    
}
