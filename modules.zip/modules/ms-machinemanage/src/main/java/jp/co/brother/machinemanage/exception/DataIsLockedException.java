package jp.co.brother.machinemanage.exception;

public class DataIsLockedException extends RuntimeException {
    /**
     * Automatic generated.
     */
    private static final long serialVersionUID = 1821713635064987799L;

    public DataIsLockedException(String s) {
        super(s);
    }
}