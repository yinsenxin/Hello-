package jp.co.brother.machinemanage.utils;

public enum ExpressionNodeType {
    Unknown, // 异常类型
    Plus, // +
    Subtract, // -
    MultiPly, // *
    Divide, // /
    LParentheses, // (
    RParentheses, // )
    Mod, // % (求模,取余)
    Power, // ^ (次幂)
    BitwiseAnd, // & (按位与)
    BitwiseOr, // | (按位或)
    And, // && 或 <并且> 或 并且 (逻辑与)
    Or, // || 或 <或者> 或 或者(逻辑或)
    Not, // ! (逻辑非)
    Equal, // == 或 = (相等)
    Unequal, // != 或 <> 或 ≠ (不等于)
    GT, // > (大于)
    LT, // < (小于)
    GTOrEqual, // >= 或 ≥(大于等于)
    LTOrEqual, // <= 或 ≤(小于等于)
    LShift, // << (左移位)
    RShift, // >> (右移位)
    Numeric, // 数值
    String, // 字符串
    Like, // @ 或 <包含> 或 包含(包含)
    NotLike, // !@ 或 <不包含> 或 不包含(不包含)
    StartWith, // !!$ (以什么开始)
    EndWith // !!@ (以什么结尾)
}
