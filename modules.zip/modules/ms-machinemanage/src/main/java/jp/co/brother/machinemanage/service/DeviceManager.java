package jp.co.brother.machinemanage.service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.util.Assert;
import org.springframework.web.client.RestTemplate;

import com.alibaba.fastjson.JSONObject;

import jp.co.brother.machinemanage.constant.Constant;
import jp.co.brother.machinemanage.domain.DeviceDO;
import jp.co.brother.machinemanage.exception.DataNotFoundException;
import jp.co.brother.machinemanage.pojo.DevicePojo;
import jp.co.brother.machinemanage.pojo.DeviceStatusPojo;
import jp.co.brother.machinemanage.pojo.ProfilePojo;
import jp.co.brother.machinemanage.utils.MongoDBUtils;
import jp.co.brother.machinemanage.vo.ResultVO;

@Component
public class DeviceManager {

    @Autowired
    private MongoDBUtils<DeviceDO> mongoDBUtils;
    @Autowired
    private QuartzManager quartzManager;
    @Autowired
    private ProfileManager profileManager;
    @Autowired
    private RestTemplate restTemplate;

    /* Device status data in the memory */
    Map<String, DeviceStatusPojo> deviceStatus = new HashMap<>();
    /* Map<DeviceId, counts> */
    Map<String, Integer> unreachRecord = new HashMap<>();
    private static final Logger logger = LoggerFactory.getLogger(DeviceManager.class);

    /**
     * Get the specified item of the specified deviceIds.
     * 
     * @param deviceIds ID of the specified devices
     * @return
     */
    public ResultVO getDeviceStatus(String[] deviceIds) {
        ResultVO result = new ResultVO(HttpStatus.OK);
        /* Get response data */
        Map<String, DeviceStatusPojo> status = getDeviceStatusById(deviceIds);
        result.setData(status);
        return result;
    }

    /**
     * Get all device data with no condition.
     * 
     * @return
     */
    public ResultVO getDeviceData() {
        List<DevicePojo> devicePojos = new ArrayList<>();
        /* Get data from mongoDB */
        List<DeviceDO> deviceDOs = mongoDBUtils.findAll(DeviceDO.class);
        /* Convert to POJO */
        for (DeviceDO deviceDO : deviceDOs) {
            if (Objects.isNull(deviceDO)) {
                logger.warn("Invalid document");
                continue;
            }
            /* DO => POJO */
            DevicePojo device = domainToPojo(deviceDO);
            devicePojos.add(device);
        }

        ResultVO result = new ResultVO(HttpStatus.OK);
        result.setData(devicePojos);
        return result;
    }

    /**
     * Get the device data of the specified device.
     * 
     * @param deviceId ID of the specified device
     * @return
     * @throws IllegalArgumentException, DataNotFoundException
     */
    public ResultVO getDeviceData(String deviceId) {
        /* Check input parameter, make sure they are not null */
        Assert.notNull(deviceId, "DeviceId must not be null!");

        ResultVO result = new ResultVO(HttpStatus.OK);
        /* Make search criteria */
        Query query = new Query();
        query.addCriteria(Criteria.where("deviceId").is(deviceId));
        /* Search data */
        DeviceDO deviceDO = mongoDBUtils.findOne(query, DeviceDO.class);
        if (Objects.nonNull(deviceDO)) {
            /* DO => POJO */
            DevicePojo device = domainToPojo(deviceDO);
            result.setData(device);
        } else {
            throw new DataNotFoundException("Target data not found!");
        }
        return result;
    }

    /**
     * Add a new device record.
     * 
     * @param deviceData device data
     * @return
     * @throws IllegalArgumentException, DataIsLockedException
     */
    public ResultVO addDeviceData(DevicePojo deviceData) {
        /* Check input parameter, make sure they are not null */
        Assert.notNull(deviceData, "Body of this request must not be null!");
        Assert.hasLength(deviceData.getDeviceId(), "\"deviceId\" in the body must not be null or empty!");
        Assert.notNull(deviceData.getDeviceCategory(), "\"deviceCategory\" in the body must not be null!");
        Assert.notNull(deviceData.getHeartBeat(), "\"heartBeat\" in the body must not be null!");
        Assert.notNull(deviceData.getServices(), "\"services\" in the body must not be null!");

        /* Convert POJO to DO */
        DeviceDO deviceDO = pojoToDomain(deviceData);

        /* Make search criteria */
        Query query = new Query();
        query.addCriteria(Criteria.where("deviceId").is(deviceDO.getDeviceId()));
        /* Check if the target data exist */
        if (mongoDBUtils.exists(query, DeviceDO.class)) {
            /* Make update */
            Update update = new Update();
            update.set("configurePage", deviceDO.getConfigurePage());
            update.set("deviceCategory", deviceDO.getDeviceCategory());
            update.set("heartBeat", deviceDO.getHeartBeat());
            update.set("description", deviceDO.getDescription());
            update.set("services", deviceDO.getServices());
            /* Update data */
            mongoDBUtils.upsert(query, update, DeviceDO.class);
        } else {
            /* Save new data */
            mongoDBUtils.insert(deviceDO);
        }

        /* Start a new thread to update the relevant data */
        quartzManager.updateDeviceRelevantData(new String[] { deviceDO.getDeviceId() });

        return new ResultVO(HttpStatus.OK);
    }

    /**
     * Delete the specified device record with the given deviceIds.
     * 
     * @param deviceIds ID of the specified devices
     * @return
     * @throws IllegalArgumentException, DataIsLockedException
     */
    public ResultVO deleteDeviceData(String[] deviceIds) {
        /* Check input parameter, make sure they are not null */
        Assert.notEmpty(deviceIds, "DeviceIds must not be empty!");

        ResultVO result = new ResultVO(HttpStatus.OK);
        /* Make search criteria */
        Query query = new Query();
        query.addCriteria(Criteria.where("deviceId").in((Object[]) deviceIds));
        /* Delete data */
        List<DeviceDO> deletedDatas = new ArrayList<>();
        deletedDatas = mongoDBUtils.findAllAndRemove(query, DeviceDO.class);
        /* Analyze result */
        Map<String, Boolean> hMap = new HashMap<>();
        for (DeviceDO deviceDO : deletedDatas) {
            if (Objects.isNull(deviceDO)) {
                logger.warn("Invalid document");
                continue;
            }
            hMap.put(deviceDO.getDeviceId(), true);
        }
        for (String deviceId : deviceIds) {
            if (!hMap.containsKey(deviceId)) {
                hMap.put(deviceId, false);
            }
        }
        result.setData(hMap);

        /* Start a new thread to update the relevant data */
        quartzManager.updateDeviceRelevantData(deviceIds);

        return result;
    }

    /**
     * Get all devices that meet the specified condition
     * 
     * @param deviceIds       ID of the target devices
     * @param deviceCategorys Category of the target devices
     * @param datas           The field that needs to be returned
     * @return
     */
    public ResultVO queryDeviceData(String[] deviceIds, String[] deviceCategorys, String[] datas) {
        /* Make response */
        ResultVO result = new ResultVO(HttpStatus.OK);

        /* Query data */
        List<DevicePojo> devicePojos = queryDeviceDataByContent(deviceIds, deviceCategorys, datas);
        /* Make response data */
        if (Objects.nonNull(datas)) {
            List<Map<String, Object>> responseDatas = new ArrayList<>();
            List<String> names = Arrays.asList(datas);
            for (DevicePojo devicePojo : devicePojos) {
                Map<String, Object> map = new HashMap<>();
                if (names.contains("deviceId")) {
                    map.put("deviceId", devicePojo.getDeviceId());
                }
                if (names.contains("configurePage")) {
                    map.put("configurePage", devicePojo.getConfigurePage());
                }
                if (names.contains("deviceCategory")) {
                    map.put("deviceCategory", devicePojo.getDeviceCategory());
                }
                if (names.contains("heartBeat")) {
                    map.put("heartBeat", devicePojo.getHeartBeat());
                }
                if (names.contains("description")) {
                    map.put("description", devicePojo.getDescription());
                }
                if (names.contains("services")) {
                    map.put("services", devicePojo.getServices());
                }
                responseDatas.add(map);
            }
            result.setData(responseDatas);
        } else {
            result.setData(devicePojos);
        }

        return result;
    }

    /**
     * Update device status when the profile information changes.(Delete/Modify/Add)
     * 
     * @param profileIds The ID of the profile that has changed
     */
    public void updateDeviceStatusByProfileId(String[] profileIds) {
        /* get all relevant devices */
        Query query = new Query();
        query.addCriteria(Criteria.where("deviceCategory").in((Object[]) profileIds));
        List<DeviceDO> deviceDOs = mongoDBUtils.find(query, DeviceDO.class);

        /* Update the status of each device */
        for (DeviceDO deviceDO : deviceDOs) {
            if (Objects.isNull(deviceDO)) {
                logger.warn("Invalid document");
                continue;
            }
            DeviceStatusPojo status = checkDeviceStatus(deviceDO.getDeviceCategory(), deviceDO.getServices());
            deviceStatus.put(deviceDO.getDeviceId(), status);
        }
    }

    /**
     * Update device status when the device information changes.(Delete/Modify/Add)
     * 
     * @param deviceIds The ID of the device that has changed
     */
    public void updateDeviceStatusByDeviceId(String[] deviceIds) {
        /* get all relevant devices */
        Query query = new Query();
        query.addCriteria(Criteria.where("deviceId").in((Object[]) deviceIds));
        List<DeviceDO> deviceDOs = mongoDBUtils.find(query, DeviceDO.class);

        /* Update the status of each device */
        List<String> existDeviceIds = new ArrayList<>();
        deviceDOs.removeAll(Collections.singleton(null));
        for (DeviceDO deviceDO : deviceDOs) {
            DeviceStatusPojo status = checkDeviceStatus(deviceDO.getDeviceCategory(), deviceDO.getServices());
            deviceStatus.put(deviceDO.getDeviceId(), status);
            existDeviceIds.add(deviceDO.getDeviceId());
        }

        /* Delete devices that does not exist */
        for (String deviceId : deviceIds) {
            if (!existDeviceIds.contains(deviceId)) {
                deviceStatus.remove(deviceId);
            }
        }
    }

    /**
     * Check device heart beat & update device status for scheduled job.
     */
    public List<String> updateDeviceStatus() {
        List<String> changedDeviceIds = new ArrayList<>();
        /* get all relevant devices */
        List<DeviceDO> deviceDOs = mongoDBUtils.findAll(DeviceDO.class);

        /* Remove invalid document */
        deviceDOs.removeAll(Collections.singleton(null));
        /* Check the heart beat of each device */
        for (DeviceDO deviceDO : deviceDOs) {
            /* deviceId */
            String deviceId = deviceDO.getDeviceId();
            try {
                /* Heart beat URL will not be null */
                String heartBeatURL = deviceDO.getHeartBeat();

                /* Make header */
                HttpHeaders headers = new HttpHeaders();
                headers.setContentType(MediaType.parseMediaType("application/json; charset=UTF-8"));
                HttpEntity<String> entity = new HttpEntity<String>(null, headers);
                /* Check heart beat */
                ResponseEntity<String> resultEntity = restTemplate.exchange(heartBeatURL, HttpMethod.GET, entity,
                        String.class);
                /* If status code is 200 and the "result" in the body is "success" */
                if ((resultEntity.getStatusCode() == HttpStatus.OK) && JSONObject.parseObject(resultEntity.getBody())
                        .getOrDefault("result", "").equals("success")) {
                    logger.info("Clear unreach count. deviceId: {}", deviceId);
                    /* Clear the exception record */
                    unreachRecord.remove(deviceId);
                } else {
                    logger.warn("Incorrect device heartbeat response. deviceId: {}, statusCode: {}, body: {}", deviceId,
                            resultEntity.getStatusCode(), resultEntity.getBody());
                    logger.info("New unreach count: {}", unreachRecord.getOrDefault(deviceId, 0) + 1);
                    /* Set exception record */
                    unreachRecord.put(deviceId, unreachRecord.getOrDefault(deviceId, 0) + 1);
                }
            } catch (Exception e) {
                logger.warn("Check device heart beat failed. deviceId: {}, url: {}", deviceId, deviceDO.getHeartBeat());
                logger.info("New unreach count: {}", unreachRecord.getOrDefault(deviceId, 0) + 1);
                logger.warn("{}: {}", e.getClass().getName(), e.getMessage());
                /* Set exception record */
                unreachRecord.put(deviceId, unreachRecord.getOrDefault(deviceId, 0) + 1);
            }
        }

        /* Remove all unreachable devices(if not response three times) */
        List<String> offLineDev = new ArrayList<>();
        for (String deviceId : unreachRecord.keySet()) {
            if (unreachRecord.get(deviceId) >= 3) {
                offLineDev.add(deviceId);
            }
        }
        for (String deviceId : offLineDev) {
            unreachRecord.remove(deviceId);
            deviceStatus.remove(deviceId);
            logger.info("Remove off-line device. deviceId: {}", deviceId);
        }
        Query query = new Query();
        query.addCriteria(Criteria.where("deviceId").in(offLineDev));
        List<DeviceDO> removedData = mongoDBUtils.findAllAndRemove(query, DeviceDO.class);

        deviceDOs.removeAll(removedData);
        /* Update the status of each device */
        for (DeviceDO deviceDO : deviceDOs) {
            /* Get deviceId */
            String deviceId = deviceDO.getDeviceId();
            DeviceStatusPojo oldStatus = deviceStatus.get(deviceId);
            DeviceStatusPojo status = checkDeviceStatus(deviceDO.getDeviceCategory(), deviceDO.getServices());
            /* If reason or healthy is changed */
            if (Objects.isNull(oldStatus) || !oldStatus.getReason().equalsIgnoreCase(status.getReason())
                    || oldStatus.isHealthy() != status.isHealthy()) {
                deviceStatus.put(deviceId, status);
                changedDeviceIds.add(deviceId);
            }
        }
        changedDeviceIds.addAll(offLineDev);

        return changedDeviceIds;
    }

    public List<DevicePojo> queryDeviceDataByContent(String[] deviceIds, String[] deviceCategorys, String[] datas) {
        List<DevicePojo> devicePojos = new ArrayList<>();
        /* Make search criteria */
        Query query = new Query();
        if (Objects.nonNull(deviceIds) && deviceIds.length > 0) {
            query.addCriteria(Criteria.where("deviceId").in((Object[]) deviceIds));
        }
        if (Objects.nonNull(deviceCategorys) && deviceCategorys.length > 0) {
            query.addCriteria(Criteria.where("deviceCategory").in((Object[]) deviceCategorys));
        }

        datas = Objects.isNull(datas)
                ? new String[] { "deviceId", "configurePage", "deviceCategory", "heartBeat", "description", "services" }
                : datas;
        List<String> items = Arrays.asList(datas);
        List<DeviceDO> deviceDOs = mongoDBUtils.find(query, DeviceDO.class);
        for (DeviceDO deviceDO : deviceDOs) {
            DevicePojo devicePojo = new DevicePojo();
            if (items.contains("deviceId")) {
                devicePojo.setDeviceId(deviceDO.getDeviceId());
            }
            if (items.contains("configurePage")) {
                devicePojo.setConfigurePage(deviceDO.getConfigurePage());
            }
            if (items.contains("deviceCategory")) {
                devicePojo.setDeviceCategory(deviceDO.getDeviceCategory());
            }
            if (items.contains("heartBeat")) {
                devicePojo.setHeartBeat(deviceDO.getHeartBeat());
            }
            if (items.contains("description")) {
                devicePojo.setDescription(deviceDO.getDescription());
            }
            if (items.contains("services")) {
                devicePojo.setServices(deviceDO.getServices());
            }

            devicePojos.add(devicePojo);
        }
        return devicePojos;
    }

    /**
     * Get the specified item of the specified deviceIds.
     * 
     * @param deviceIds
     * @return
     */
    public Map<String, DeviceStatusPojo> getDeviceStatusById(String[] deviceIds) {
        /* Make sure input parameter is an array */
        deviceIds = Objects.nonNull(deviceIds) ? deviceIds : deviceStatus.keySet().toArray(new String[0]);
        /* Make response data */
        Map<String, DeviceStatusPojo> result = new HashMap<>();
        for (String deviceId : deviceIds) {
            if (Objects.isNull(deviceId)) {
                continue;
            }
            result.put(deviceId,
                    deviceStatus.getOrDefault(deviceId, new DeviceStatusPojo(false, Constant.DEVSTS_DEVICE_NOTFOUND)));
        }
        return result;
    }

    /**
     * DO => POJO
     * 
     * @param deviceDO
     * @return
     */
    private final DevicePojo domainToPojo(DeviceDO deviceDO) {
        DevicePojo devicePojo = new DevicePojo();
        devicePojo.setDeviceId(deviceDO.getDeviceId());
        devicePojo.setConfigurePage(deviceDO.getConfigurePage());
        devicePojo.setDeviceCategory(deviceDO.getDeviceCategory());
        devicePojo.setHeartBeat(deviceDO.getHeartBeat());
        devicePojo.setDescription(deviceDO.getDescription());
        devicePojo.setServices(deviceDO.getServices());

        return devicePojo;
    }

    /**
     * POJO => DO
     * 
     * @param devicePojo
     * @return
     * @throws IllegalArgumentException
     */
    private final DeviceDO pojoToDomain(DevicePojo devicePojo) {
        DeviceDO deviceDO = new DeviceDO();
        deviceDO.setDeviceId(devicePojo.getDeviceId());
        deviceDO.setConfigurePage(devicePojo.getConfigurePage() == null ? "" : devicePojo.getConfigurePage());
        deviceDO.setDeviceCategory(devicePojo.getDeviceCategory());
        deviceDO.setHeartBeat(devicePojo.getHeartBeat());
        deviceDO.setDescription(devicePojo.getDescription() == null ? "" : devicePojo.getDescription());
        deviceDO.setServices(devicePojo.getServices());

        return deviceDO;
    }

    /**
     * Check if the service provided by the device matches the service requested by
     * the category.
     * 
     * @param profileId
     * @param services
     * @return
     */
    private DeviceStatusPojo checkDeviceStatus(String profileId, Map<String, Object> services) {
        DeviceStatusPojo deviceStatusPojo = new DeviceStatusPojo();
        try {
            /* Get profile information */
            ResultVO result = profileManager.getProfileData(profileId);
            ProfilePojo profilePojo = (ProfilePojo) result.getData();
            /* Get services required by profile */
            List<String> requiredServices = profilePojo.getServices();

            /* Get the services provided by the device */
            Map<String, Object> deviceServices = services;

            boolean healthy = deviceServices.keySet().containsAll(requiredServices);
            deviceStatusPojo.setHealthy(healthy);
            deviceStatusPojo.setReason(healthy == true ? "" : Constant.DEVSTS_SERVICE_DISCREPANCY);
        } catch (DataNotFoundException e) {
            logger.error("Specified profile data not found. ProfileID: {}", profileId);
            deviceStatusPojo.setHealthy(false);
            deviceStatusPojo.setReason(Constant.DEVSTS_PROFILE_NOTFOUND);
        } catch (Exception e) {
            deviceStatusPojo.setHealthy(false);
            deviceStatusPojo.setReason(Constant.DEVSTS_INTERNAL_EXCEPTION);
            logger.error("Error occurred while check device services");
            logger.error("{} : {}", e.getClass().getName(), e.getMessage());
        }
        return deviceStatusPojo;
    }
}
