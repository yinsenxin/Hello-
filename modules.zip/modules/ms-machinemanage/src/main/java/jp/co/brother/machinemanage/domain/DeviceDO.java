package jp.co.brother.machinemanage.domain;

import java.util.Map;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import lombok.Data;

@Data
@Document(collection = "Device")
public class DeviceDO {

    @Id
    private String id;
    /**
     * The unique ID of the device data
     */
    private String deviceId;
    /**
     * The address of the device configuration page. Example:
     * "http://127.0.0.1:5201/cameraConfig.html"
     */
    private String configurePage;
    /**
     * The category of the current device.
     */
    private String deviceCategory;
    /**
     * The heart-beat detection address of the current device. Example:
     * "http://127.0.0.1:5201/heartBeat"
     */
    private String heartBeat;
    /**
     * The description of the current device. Should be a JSON object
     */
    private Object description;
    /**
     * The services provided by the current device. Should be a JSON object
     */
    private Map<String, Object> services;
}
