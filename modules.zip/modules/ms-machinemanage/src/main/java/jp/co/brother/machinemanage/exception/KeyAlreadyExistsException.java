package jp.co.brother.machinemanage.exception;

public class KeyAlreadyExistsException extends RuntimeException {
    /**
     * Automatic generated
     */
    private static final long serialVersionUID = -9024041160751615488L;

    public KeyAlreadyExistsException(String s) {
        super(s);
    }
}
