package jp.co.brother.machinemanage.serviceImpl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Objects;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;
import org.springframework.util.Assert;

import jp.co.brother.machinemanage.constant.Constant;
import jp.co.brother.machinemanage.domain.GroupDO;
import jp.co.brother.machinemanage.exception.DataNotFoundException;
import jp.co.brother.machinemanage.pojo.GroupPojo;
import jp.co.brother.machinemanage.service.GroupService;
import jp.co.brother.machinemanage.service.MachineManager;
import jp.co.brother.machinemanage.utils.MongoDBUtils;
import jp.co.brother.machinemanage.vo.ResultVO;



@Component
public class GroupServiceImpl implements GroupService{
		

	private static final Logger logger = LoggerFactory.getLogger(GroupServiceImpl.class);
	@Autowired
    private MongoDBUtils<GroupDO> mongoDBUtils;
	@Autowired
	private MachineManager machineManager;
	
	/**
	 * Group relevant data
	 * PoJo => DO
	 * 
	 * @param groupPojo
	 * @return
	 */
	private final GroupDO pojoTodomain(GroupPojo groupPojo) {
		GroupDO groupDO = new GroupDO();
		groupDO.setDescription(groupPojo.getDescription() == null ? "" : groupPojo.getDescription());
		groupDO.setGroupId(groupPojo.getGroupId());
		groupDO.setGroupModelId(groupPojo.getGroupModelId());
		groupDO.setConditions(groupPojo.getConditions() == null ? new HashMap<>() : groupPojo.getConditions());
		groupDO.setSubordinateList(groupPojo.getSubordinateList() == null ? new ArrayList<>() : groupPojo.getSubordinateList() );
		
		return groupDO;
	}
	
	/**
	 * Group relevant data
	 * DO => PoJo
	 * 
	 * @param groupDO
	 * @return
	 */
	private final GroupPojo domainToPojo(GroupDO groupDO) {
		GroupPojo groupPojo = new GroupPojo();
		groupPojo.setDescription(groupDO.getDescription());
		groupPojo.setGroupId(groupDO.getGroupId());
		groupPojo.setGroupModelId(groupDO.getGroupModelId());
		groupPojo.setConditions(groupDO.getConditions());
		groupPojo.setSubordinateList(groupDO.getSubordinateList());
		return groupPojo;
	}
	
	/**
	 * Replace the old data with the new data.(Which means the old data is exist)
	 * @param groupId
	 * @param groupDO
	 */
	 private void replaceOldRecord(String groupId, GroupDO groupDO) {
	    	/*Make search criteria*/
	    	Query query = new Query();
	    	query.addCriteria(Criteria.where(Constant.DBQUERY_GROUP_ID).is(groupId));
	    	
	    	/*Make update*/
	    	Update update = new Update();
	    	update.set(Constant.DBQUERY_GROUP_ID, groupDO.getGroupId());
	    	update.set(Constant.DBQUERY_GROUPMODEL_ID, groupDO.getGroupModelId());
	    	update.set(Constant.DBQUERY_GROUP_DESCRIPTION, groupDO.getDescription());
	    	update.set(Constant.DBQUERY_GROUP_CONDITION, groupDO.getConditions());
	    	update.set(Constant.DBQUERY_GROUP_SUBORDINATE, groupDO.getSubordinateList());
	    	/*Update data*/
	    	mongoDBUtils.upsert(query, update, GroupDO.class);
	    }
	/**
	 * Get all the Group data
	 */
	@Override
	public ResultVO getGroupData(String [] groupModelIds) {
		
		ResultVO resultVO = new ResultVO(HttpStatus.OK);
		/*Make search*/
		List<GroupDO> groupDO = mongoDBUtils.findAll(GroupDO.class);
		List<GroupPojo> list = new ArrayList<>();
		for (GroupDO group : groupDO) {
			if (Objects.isNull(group)) {
				logger.warn("Invalid document");
				continue;
			}
			GroupPojo groupPojo = domainToPojo(group);
			list.add(groupPojo);
		}
		/*return All group data*/
		resultVO.setData(list);
		if (groupModelIds != null) {
			Query query = new Query();
			query.addCriteria(Criteria.where(Constant.DBQUERY_GROUPMODEL_ID).in((Object [])groupModelIds));
			List<GroupPojo> lists = new ArrayList<>();
			List<GroupDO> findAll = mongoDBUtils.find(query, GroupDO.class);
			for (GroupDO groupDOs : findAll) {
				GroupPojo groupPojo = domainToPojo(groupDOs);
				lists.add(groupPojo);
			}
			/*return specified group data*/
			resultVO.setData(lists);
		}
		
		return resultVO;
	}
	
	/**
	 * Get the specified Group data according the groupId
	 */
	@Override
	public ResultVO getGroupDataById(String groupId) {
		/* Check input parameter, make sure they are not null */
		Assert.notNull(groupId, Constant.ASSERT_GROUP_ID_MESSAGE);
		ResultVO resultVO = new ResultVO(HttpStatus.OK);
		/*Make search*/
		Query query = new Query();
		query.addCriteria(Criteria.where(Constant.DBQUERY_GROUP_ID).is(groupId));
		/*Search data*/
		GroupDO groupDO = mongoDBUtils.findOne(query, GroupDO.class);
		if (Objects.nonNull(groupDO)) {
			/*DO => POJO*/
			GroupPojo groupPojo = domainToPojo(groupDO);
			resultVO.setData(groupPojo);
		} else {
			throw new DataNotFoundException("Target data is not found");
		}
		return resultVO;
	}

	/**
	 * Add a group data
	 */
	@Override
	public ResultVO addGroupData(GroupPojo groupPojo) {
		/* Check input parameter, make sure they are not null */
		Assert.notNull(groupPojo, Constant.ASSERT_REQUEST_BODY);
		 Assert.notNull(groupPojo.getGroupModelId(), Constant.ASSERT_GROUPMODEL_MESSAGE);
        Assert.hasLength(groupPojo.getGroupId(), Constant.ASSERT_GROUP_MESSAGE);
        Assert.notNull(groupPojo.getSubordinateList(), Constant.ASSERT_GROUP_SUBORDINATE);

        ResultVO resultVO = new ResultVO(HttpStatus.OK);
        /* Convert POJO to DO */
		GroupDO groupDO = pojoTodomain(groupPojo);
		/*Make Search*/
		Query query = new Query();
		query.addCriteria(Criteria.where(Constant.DBQUERY_GROUP_ID).is(groupDO.getGroupId()));
		
		if (mongoDBUtils.exists(query, GroupDO.class)) {
			resultVO = new ResultVO(HttpStatus.CONFLICT);
			return resultVO;
		} else {
			mongoDBUtils.insert(groupDO);
		}
		
		return resultVO;
	}
	
	/**
	 * Modify the specified Group data according the groupId and GroupPoJo
	 */
	@Override
	public ResultVO updateGroupData(String groupId, GroupPojo groupPojo) {
		/* Check input parameter, make sure they are not null */
		Assert.notNull(groupId, Constant.ASSERT_GROUPMODEL_ID_MESSAGE);
        Assert.notNull(groupPojo, Constant.ASSERT_REQUEST_BODY);
        Assert.notNull(groupPojo.getGroupModelId(), Constant.ASSERT_GROUPMODEL_MESSAGE);
        Assert.hasLength(groupPojo.getGroupId(), Constant.ASSERT_GROUP_MESSAGE);
        Assert.notNull(groupPojo.getSubordinateList(), Constant.ASSERT_GROUP_SUBORDINATE);
		
        ResultVO resultVO = new ResultVO(HttpStatus.OK);
        /*Make Search*/
        Query query = new Query();
        query.addCriteria(Criteria.where(Constant.DBQUERY_GROUP_ID).is(groupId));
        /*Check if the target data exist*/
        if (mongoDBUtils.exists(query, GroupDO.class)) {
        	if (!groupId.equals(groupPojo.getGroupId())) {
        		Query query2 = new Query();
        		query2.addCriteria(Criteria.where(Constant.DBQUERY_GROUP_ID).is(groupPojo.getGroupId()));
        		if (mongoDBUtils.exists(query2, GroupDO.class)) {
        			throw new IllegalArgumentException("The \"groupId\" is exist!");
        		}
        	} 
        	/* Convert POJO to DO */
        	GroupDO groupDO = pojoTodomain(groupPojo);
        	replaceOldRecord(groupId, groupDO);
        } else {
        	throw new DataNotFoundException("Target data is not found!");
        }
        
		return resultVO;
	}

	/**
	 * Delete the specified group data according to the groupIds
	 */
	@Override
	public ResultVO deleteGroupData(String[] groupIds) {
		/* Check input parameter, make sure they are not null */
		Assert.notEmpty(groupIds, Constant.ASSERT_GROUP_ID_MESSAGE);
		ResultVO resultVO = new ResultVO(HttpStatus.OK);
		
		/*Make Search*/
		Query query = new Query();
		query.addCriteria(Criteria.where(Constant.DBQUERY_GROUP_ID).in((Object[]) groupIds));
		List<GroupDO> list = mongoDBUtils.findAllAndRemove(query, GroupDO.class);
		
		if (list.isEmpty()) 
			resultVO.setData(false);
		
		resultVO.setData(true);
		
		return resultVO;
	}
	
	/**
	 * Get specified group status
	 */
	@Override
	public ResultVO getGroupStatus(String [] groupIds) {
		
		ResultVO resultVO = new ResultVO(HttpStatus.OK);
		/*TODO: */
		resultVO.setData(true);
		return resultVO;
	}
}





