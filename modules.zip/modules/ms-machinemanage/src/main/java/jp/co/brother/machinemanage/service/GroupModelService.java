package jp.co.brother.machinemanage.service;

import jp.co.brother.machinemanage.pojo.GroupModelPojo;
import jp.co.brother.machinemanage.vo.ResultVO;

public interface GroupModelService {
	
	/**
	 * Get all the GroupModel data
	 * @return
	 */
	ResultVO getGroupModelData(String groupModelId);
	
	/**
	 * Get the specified GroupModel data according the groupModelId
	 * @param groupModelId 
	 * @return
	 */
	ResultVO getGroupModelDataById(String groupModelId);
	
	/**
	 * Add a groupModel data
	 * @param groupModelPojo
	 * @return
	 */
	ResultVO addGroupModelData(GroupModelPojo groupModelPojo);
	
	/**
	 * Delete the specified groupModel data according to the groupModelIds
	 * @param groupModelIds
	 * @return
	 */
	ResultVO deleteGroupModelData(String [] groupModelIds);
	
	/**
	 * Modify the specified GroupModel data according the groupModelId and GroupModelPoJo
	 * @param groupModelId
	 * @param groupModelPojo
	 * @return
	 */
	ResultVO updateGroupModelData(String groupModelId, GroupModelPojo groupModelPojo);
	
}
