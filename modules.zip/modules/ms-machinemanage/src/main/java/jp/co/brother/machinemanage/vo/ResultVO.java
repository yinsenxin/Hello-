package jp.co.brother.machinemanage.vo;

import org.springframework.http.HttpStatus;

import lombok.Data;

@Data
public class ResultVO {
    private Integer code;
    private String message;
    private Object data;

    public ResultVO() {

    }

    public ResultVO(HttpStatus status) {
        this.code = status.value();
        this.message = status.getReasonPhrase();
    }

    public ResultVO(HttpStatus status, String message) {
        this.code = status.value();
        this.message = message;
    }

    public ResultVO(Integer code, String message) {
        this.code = code;
        this.message = message;
    }
}
