package jp.co.brother.machinemanage.pojo;

import java.util.Map;

import lombok.Data;

@Data
public class GroupStatusPojo {
	/**
	 * this is a healthy about Group
	 */
	private Boolean healthy;
	/**
	 * this is a reason about Group
	 */
	private String reason;
	/**
	 * this is a map about Group
	 */
	private Map<String, MachineStatusPojo> map;
	
	
	
	
	
	
	
	
}
