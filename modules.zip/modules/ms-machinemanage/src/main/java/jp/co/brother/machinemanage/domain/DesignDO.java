package jp.co.brother.machinemanage.domain;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import com.alibaba.fastjson.annotation.JSONField;
import lombok.Data;

@Data
@Document(collection = "Design")
public class DesignDO {

    @Id
    @JSONField(serialize = false)
    private String id;
    /**
     * The unique ID of the design data
     */
    private String designId;
    /**
     * The relative path of the Design image. Example: "upload/1213150618485.bmp"
     */
    private String imagePath;
    /**
     * The collection of key position information on the Design image. Example:
     * {"key_1":{"x":1028,"y":59,"w":74,"h":46}}
     */
    private Object keys;
    /**
     * The screen position information on the Design image. Example:
     * {"x":493,"y":52,"w":366,"h":214}
     */
    private Object screen;
    /**
     * The touch panel position information on the Design image. Example:
     * {"x":493,"y":52,"w":366,"h":214}
     */
    private Object touchPanel;
    /**
     * The time when this data was last modified
     */
    @JSONField(serialize = false)
    private String lastModifyTime;
}
