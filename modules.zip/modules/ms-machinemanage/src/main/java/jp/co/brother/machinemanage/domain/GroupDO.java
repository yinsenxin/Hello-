package jp.co.brother.machinemanage.domain;

import java.util.List;
import java.util.Map;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.Field;

import com.alibaba.fastjson.annotation.JSONField;

import lombok.Data;

@Data
@Document(collection = "group_machine")
public class GroupDO {
	
	@Id
    @JSONField(serialize = false)
	private String id;
	/**
	 * The unique ID of the group data.
	 */
	@Field("group_id")
	private String groupId;
	/**
	 * The ID of the groupModel data;
	 */
	@Field("group_model_id")
	private String groupModelId;
	/**
	 * The list of the Subordinate data;
	 */
	@Field("subordinate_list")
	private List<Subordinate> subordinateList;
	/**
	 * This is a conditions;
	 */
	private Map<String, Object> conditions;
	/**
	 * This is a description
	 */
	private String description;
}
