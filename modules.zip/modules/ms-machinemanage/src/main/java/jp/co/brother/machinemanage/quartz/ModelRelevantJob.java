package jp.co.brother.machinemanage.quartz;

import org.quartz.DisallowConcurrentExecution;
import org.quartz.Job;
import org.quartz.JobDataMap;
import org.quartz.JobExecutionContext;
import org.quartz.PersistJobDataAfterExecution;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;

import jp.co.brother.machinemanage.service.MachineManager;
import jp.co.brother.machinemanage.service.ModelManager;

@Component
@DisallowConcurrentExecution
@PersistJobDataAfterExecution
public class ModelRelevantJob implements Job {

    @Autowired
    private ModelManager modelManager;
    @Autowired
    private MachineManager machineManager;

    private static final Logger logger = LoggerFactory.getLogger(ModelRelevantJob.class);

    public ModelRelevantJob() {
    }

    @Override
    public void execute(JobExecutionContext context) {
        try {
            JobDataMap jobDataMap = context.getTrigger().getJobDataMap();
            JSONArray modelIds = JSONObject.parseArray(jobDataMap.getString("modelIds"));
            logger.info("Some model have changed, update the relevant data. modelIds: {}", modelIds);

            /* Maintain model status */
            modelManager.updateModelStatusByModelId(modelIds.toArray(new String[0]));
            /* Maintain machine status */
            machineManager.updateMachineStatusByModelId(modelIds.toArray(new String[0]));
        } catch (Exception e) {
            logger.error("{} : {}", e.getClass().getName(), e.getMessage());
            e.printStackTrace();
        }
    }
}