package jp.co.brother.machinemanage.domain;

import java.util.List;
import java.util.Map;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.Field;

import com.alibaba.fastjson.annotation.JSONField;

import lombok.Data;

@Data
@Document(collection = "group_model")
public class GroupModelDO {
	@Id
    @JSONField(serialize = false)
	private String id;
	/**
	 * The unique ID of the groupModel data.
	 */
	@Field("group_model_id")
	private String groupModelId;
	/**
	 * The ID of the Profile data;
	 */
	@Field("profile_list")
	private List<ProfileDO> profileList;
	/**
	 * This is a conditions;
	 */
	private Map<String, List<String>> conditions;
	/**
	 * This is a description
	 */
	private String description;
}
