package jp.co.brother.machinemanage.service;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang.StringUtils;
import org.joda.time.DateTime;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;
import org.springframework.util.Assert;
import org.springframework.web.multipart.MultipartFile;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;

import jp.co.brother.machinemanage.constant.Constant;
import jp.co.brother.machinemanage.constant.ProfileType;
import jp.co.brother.machinemanage.domain.ModelDO;
import jp.co.brother.machinemanage.domain.ModelFirmwareDO;
import jp.co.brother.machinemanage.exception.DataNotFoundException;
import jp.co.brother.machinemanage.exception.KeyAlreadyExistsException;
import jp.co.brother.machinemanage.pojo.DesignPojo;
import jp.co.brother.machinemanage.pojo.ModelFirmwarePojo;
import jp.co.brother.machinemanage.pojo.ModelPojo;
import jp.co.brother.machinemanage.pojo.ModelStatusPojo;
import jp.co.brother.machinemanage.pojo.ProfilePojo;
import jp.co.brother.machinemanage.proxy.ServiceRouter;
import jp.co.brother.machinemanage.utils.MongoDBUtils;
import jp.co.brother.machinemanage.vo.ResultVO;
import jp.co.brother.machinemanage.vo.UploadedFirmwareVO;

@Component
public class ModelManager {

    @Autowired
    private MongoDBUtils<ModelDO> mongoDBUtils;
    @Autowired
    private QuartzManager quartzManager;
    @Autowired
    private ProfileManager profileManager;
    @Autowired
    private DesignManager designManager;
    @Autowired
    private ServiceRouter serviceRouter;

    @Value("${firmware.location}")
    private String ROOT_LOCATION;
    @Value("${server.port}")
    private String serverPort;

    /* Model status data in the memory */
    Map<String, ModelStatusPojo> modelStatus = new HashMap<>();
    private static final Logger logger = LoggerFactory.getLogger(ModelManager.class);

    /**
     * Get all model data with no condition.
     * 
     * @return
     */
    public ResultVO getModelData() {
        List<ModelPojo> modelPojos = new ArrayList<>();
        /* Get data from mongoDB */
        List<ModelDO> modelDOs = mongoDBUtils.findAll(ModelDO.class);
        /* Convert to POJO */
        for (ModelDO modelDO : modelDOs) {
            if (Objects.isNull(modelDO)) {
                logger.warn("Invalid document");
                continue;
            }
            /* DO => POJO */
            ModelPojo model = domainToPojo(modelDO);
            modelPojos.add(model);
        }

        ResultVO result = new ResultVO(HttpStatus.OK);
        result.setData(modelPojos);
        return result;
    }

    /**
     * Get the model data of the specified model.
     * 
     * @param modelId ID of the specified model
     * @return
     * @throws IllegalArgumentException
     */
    public ResultVO getModelData(String modelId) {
        /* Check input parameter, make sure they are not null */
        Assert.notNull(modelId, "ModelId must not be null!");

        ResultVO result = new ResultVO(HttpStatus.OK);
        /* Make search criteria */
        Query query = new Query();
        query.addCriteria(Criteria.where("modelId").is(modelId));
        /* Search data */
        ModelDO modelDO = mongoDBUtils.findOne(query, ModelDO.class);
        if (Objects.nonNull(modelDO)) {
            /* DO => POJO */
            ModelPojo model = domainToPojo(modelDO);
            result.setData(model);
        } else {
            throw new DataNotFoundException("Target data not found!");
        }
        return result;
    }

    /**
     * Add a new model record.
     * 
     * @param modelData model data
     * @return
     * @throws IllegalArgumentException
     */
    public ResultVO addModelData(ModelPojo modelData) {
        /* Check input parameter, make sure they are not null */
        Assert.notNull(modelData, "Body of this request must not be null!");
        Assert.hasLength(modelData.getModelId(), "\"modelId\" in the body must not be null or empty!");
        Assert.notNull(modelData.getDesignId(), "\"designId\" in the body must not be null!");
        Assert.notNull(modelData.getProfileId(), "\"profileId\" in the body must not be null!");

        /* Convert POJO to DO */
        ModelDO modelDO = pojoToDomain(modelData);
        /* Make search criteria */
        Query query = new Query();
        query.addCriteria(Criteria.where("modelId").is(modelDO.getModelId()));
        /* Check if the target data exist */
        if (mongoDBUtils.exists(query, ModelDO.class)) {
            /* Replace old record */
            replaceOldRecord(modelDO.getModelId(), modelDO);
        } else {
            /* Save new data */
            mongoDBUtils.insert(modelDO);
        }

        /* Start a new thread to update the relevant data */
        quartzManager.updateModelRelevantData(new String[] { modelData.getModelId() });

        return new ResultVO(HttpStatus.OK);
    }

    /**
     * Update the specified model record with the given model data.
     * 
     * @param modelId   ID of the specified model
     * @param modelData model data
     * @return
     * @throws IllegalArgumentException
     */
    public ResultVO updateModelData(String modelId, ModelPojo modelData) {
        /* Check input parameter, make sure they are not null */
        Assert.notNull(modelId, "ModelId must not be null!");
        Assert.notNull(modelData, "Body of this request must not be null!");
        Assert.hasLength(modelData.getModelId(), "\"modelId\" in the body must not be null or empty!");
        Assert.notNull(modelData.getDesignId(), "\"designId\" in the body must not be null!");
        Assert.notNull(modelData.getProfileId(), "\"profileId\" in the body must not be null!");

        ResultVO result = new ResultVO(HttpStatus.OK);
        /* Make search criteria */
        Query query = new Query();
        query.addCriteria(Criteria.where("modelId").is(modelId));
        /* Check if the target data exist */
        if (mongoDBUtils.exists(query, ModelDO.class)) {
            if (!modelId.equals(modelData.getModelId())) {
                /* Check if the new modelId already exist */
                Query query1 = new Query();
                query1.addCriteria(Criteria.where("modelId").is(modelData.getModelId()));
                if (mongoDBUtils.exists(query1, ModelDO.class)) {
                    throw new IllegalArgumentException("The \"modelId\" in the body has already been used!");
                }
            }

            /* Convert POJO to DO */
            ModelDO modelDO = pojoToDomain(modelData);
            /* Replace old record */
            replaceOldRecord(modelId, modelDO);
            /* Start a new thread to update the relevant data */
            quartzManager.updateModelRelevantData(new String[] { modelId, modelData.getModelId() });
        } else {
            throw new DataNotFoundException("Target data not found!");
        }

        return result;
    }

    /**
     * Delete the specified model record with the given modelIds.
     * 
     * @param modelIds ID of the specified models
     * @return
     * @throws IllegalArgumentException
     */
    public ResultVO deleteModelData(String[] modelIds) {
        /* Check input parameter, make sure they are not null */
        Assert.notEmpty(modelIds, "ModelIds must not be empty!");

        ResultVO result = new ResultVO(HttpStatus.OK);
        /* Make search criteria */
        Query query = new Query();
        query.addCriteria(Criteria.where("modelId").in((Object[]) modelIds));
        /* Delete data */
        List<ModelDO> deletedDatas = new ArrayList<>();
        deletedDatas = mongoDBUtils.findAllAndRemove(query, ModelDO.class);
        /* Analyze result */
        Map<String, Boolean> hMap = new HashMap<>();
        for (ModelDO modelDO : deletedDatas) {
            if (Objects.isNull(modelDO)) {
                logger.warn("Invalid document");
                continue;
            }
            hMap.put(modelDO.getModelId(), true);
        }
        for (String modelId : modelIds) {
            if (!hMap.containsKey(modelId)) {
                hMap.put(modelId, false);
            }
        }
        result.setData(hMap);

        /* Start a new thread to update the relevant data */
        quartzManager.updateModelRelevantData(modelIds);

        return result;
    }

    /**
     * Download the model data of the specified models.
     * 
     * @param response response data of current HTTP request
     * @param modelIds ID of the specified models
     * @return
     */
    public ResultVO exportModelData(HttpServletResponse response, String[] modelIds) {
        /* Get all model data */
        List<ModelDO> modelDOs = mongoDBUtils.findAll(ModelDO.class);
        modelDOs.removeAll(Collections.singleton(null));

        /* Get target model data */
        List<ModelDO> targetDatas = new ArrayList<>();
        if (Objects.nonNull(modelIds) && modelIds.length > 0) {
            for (ModelDO modelDO : modelDOs) {
                String modelId = modelDO.getModelId();
                if (Arrays.asList(modelIds).contains(modelId)) {
                    targetDatas.add(modelDO);
                }
            }
        } else {
            targetDatas.addAll(modelDOs);
        }

        /***********************************************/
        /* Save the target model data to a JSON file */
        /***********************************************/
        String zipFileName = "ModelExport_" + DateTime.now().toString(Constant.DATEFMT_FILE_NAME) + ".json";
        try {
            /* Make directory & create JSON file */
            File dbFile = new File(zipFileName);
            dbFile.createNewFile();

            FileWriter dbFileWriter = new FileWriter(dbFile);
            dbFileWriter.write(JSONObject.toJSONString(targetDatas));
            dbFileWriter.flush();
            dbFileWriter.close();

            /* Make response */
            File zipFile = new File(zipFileName);
            if (zipFile.exists()) {
                InputStream fis = new BufferedInputStream(new FileInputStream(zipFile.getAbsolutePath()));
                byte[] buffer = new byte[fis.available()];
                fis.read(buffer);
                fis.close();

                response.reset();
                response.setHeader("Content-Disposition", "attachment;fileName=" + zipFileName);
                response.addHeader("Content-Length", "" + zipFile.length());
                OutputStream toClient = new BufferedOutputStream(response.getOutputStream());
                response.setContentType("application/octet-stream");
                toClient.write(buffer);
                toClient.flush();
                toClient.close();
            }
        } catch (Exception e) {
            logger.info("Error occurred while export model data");
            logger.error("{}: {}", e.getClass().getName(), e.getMessage());
            e.printStackTrace();
        } finally {
            /* Delete local JSON file */
            File zipFile = new File(zipFileName);
            if (zipFile.exists()) {
                zipFile.delete();
            }
        }

        return null;
    }

    /**
     * Import model data.
     * 
     * @param file model data
     * @return
     */
    public ResultVO importModelData(MultipartFile file) {
        ResultVO result = new ResultVO(HttpStatus.OK);
        JSONObject topContainer = new JSONObject();

        /* If the uploaded file is not empty */
        if (!file.isEmpty()) {
            /* ID of the model data that was successfully imported */
            List<String> modelIds = new ArrayList<>();

            try {
                /* Read the uploaded JSON file */
                String jsonfileContent = new String(file.getBytes(), StandardCharsets.UTF_8);

                /* Convert JSON string to ModelDO object */
                List<ModelDO> modelDOs = JSONObject.parseArray(jsonfileContent, ModelDO.class);
                if (Objects.nonNull(modelDOs)) {
                    JSONArray detail = new JSONArray();
                    modelDOs.removeAll(Collections.singleton(null));
                    for (ModelDO modelDO : modelDOs) {
                        JSONObject errorInfo = new JSONObject();
                        /* Check model ID */
                        String modelId = modelDO.getModelId();
                        if (StringUtils.isBlank(modelId)) {
                            errorInfo.put("id", modelId);
                            errorInfo.put("reason", "\"modelId\" must not be null/\"\"");
                            detail.add(errorInfo);
                            continue;
                        }
                        /* Check if the modelId already exists */
                        Query query = new Query();
                        query.addCriteria(Criteria.where("modelId").is(modelId));
                        if (mongoDBUtils.exists(query, ModelDO.class)) {
                            errorInfo.put("id", modelId);
                            errorInfo.put("reason", "\"modelId\" already exists in DataBase");
                            detail.add(errorInfo);
                            continue;
                        }

                        /* Save data */
                        mongoDBUtils.insert(modelDO);
                        modelIds.add(modelId);
                    }

                    if (!detail.isEmpty()) {
                        topContainer.put("result", "NG");
                        topContainer.put("detail", detail);
                        result.setData(topContainer);
                    } else {
                        topContainer.put("result", "OK");
                        result.setData(topContainer);
                    }
                } else {
                    topContainer.put("result", "NG");
                    topContainer.put("reason", "No valid model data");
                    result.setData(topContainer);
                }
            } catch (Exception e) {
                logger.error("Error occurred while import model data");
                logger.error("{}: {}", e.getClass().getName(), e.getMessage());
                e.printStackTrace();
                topContainer.put("result", "NG");
                topContainer.put("reason", "Internal exception: " + e.getMessage());
                result.setData(topContainer);
            } finally {
                /* Start a new thread to update the relevant data */
                quartzManager.updateModelRelevantData(modelIds.toArray(new String[0]));
            }
        } else {
            topContainer.put("result", "NG");
            topContainer.put("reason", "Empty file is uploaded.");
            result.setData(topContainer);
        }

        return result;
    }

    /**
     * Get all models that meet the specified condition
     * 
     * @param modelIds   ID of the target models
     * @param designIds  DesignId of the target models
     * @param profileIds ProfileId of the target models
     * @param datas      The field that needs to be returned
     * @return
     */
    public ResultVO queryModelData(String[] modelIds, String[] designIds, String[] profileIds, String[] datas) {
        /* Make response */
        ResultVO result = new ResultVO(HttpStatus.OK);

        /* Query data */
        List<ModelPojo> modelPojos = queryModelDataByContent(modelIds, designIds, profileIds, datas);
        /* Make response data */
        if (Objects.nonNull(datas)) {
            List<Map<String, Object>> responseDatas = new ArrayList<>();
            List<String> names = Arrays.asList(datas);
            for (ModelPojo modelPojo : modelPojos) {
                Map<String, Object> map = new HashMap<>();
                if (names.contains("modelId")) {
                    map.put("modelId", modelPojo.getModelId());
                }
                if (names.contains("designId")) {
                    map.put("designId", modelPojo.getDesignId());
                }
                if (names.contains("profileId")) {
                    map.put("profileId", modelPojo.getProfileId());
                }
                if (names.contains("screenInfo")) {
                    map.put("screenInfo", modelPojo.getScreenInfo());
                }
                if (names.contains("conditions")) {
                    map.put("conditions", modelPojo.getConditions());
                }
                if (names.contains("description")) {
                    map.put("description", modelPojo.getDescription());
                }
                responseDatas.add(map);
            }
            result.setData(responseDatas);
        } else {
            result.setData(modelPojos);
        }

        return result;
    }

    /**
     * Get all firmware data of the specified model.
     * 
     * @param modelId ID of the specified model
     * @return
     */
    public ResultVO getModelFirmwareData(String modelId) {
        /* Check input parameter, make sure they are not null */
        Assert.notNull(modelId, "ModelId must not be null!");

        /* Search model data */
        Query query = new Query();
        query.addCriteria(Criteria.where("modelId").is(modelId));
        ModelDO modelDO = mongoDBUtils.findOne(query, ModelDO.class);
        if (Objects.nonNull(modelDO)) {
            /* Get firmware data */
            Map<String, ModelFirmwareDO> firmwares = modelDO.getFirmwares();
            List<ModelFirmwarePojo> modelFirmwarePojos = new ArrayList<>();
            if (Objects.nonNull(firmwares)) {
                for (String key : firmwares.keySet()) {
                    ModelFirmwareDO firmwareDO = firmwares.get(key);

                    /* Convert to ModelFirmwarePojo */
                    ModelFirmwarePojo firmwarePojo = new ModelFirmwarePojo();
                    firmwarePojo.setName(firmwareDO.getName());
                    firmwarePojo.setVersion(firmwareDO.getVersion());
                    firmwarePojo.setDescription(firmwareDO.getDescription());
                    firmwarePojo.setUploadDate(firmwareDO.getUploadDate());
                    firmwarePojo.setUrl(relativePathToUrl(firmwareDO.getRelativePath()));

                    modelFirmwarePojos.add(firmwarePojo);
                }
            }

            ResultVO result = new ResultVO(HttpStatus.OK);
            result.setData(modelFirmwarePojos);
            return result;
        } else {
            throw new DataNotFoundException("Target data not found!");
        }
    }

    /**
     * Add a new firmware record to the specified model.
     * 
     * @param modelId ID of the specified model
     * @param body    The firmware data
     * @return
     */
    public ResultVO addModelFirmwareData(String modelId, UploadedFirmwareVO firmware) {
        /* Check input parameter, make sure they are not null */
        Assert.notNull(modelId, "ModelId must not be null!");
        Assert.notNull(firmware, "Body of this request must not be null!");
        Assert.notNull(firmware.getFile(), "\"file\" in the body must not be null!");
        Assert.hasLength(firmware.getVersion(), "\"version\" in the body must not be null or empty!");
        /* Check the format of the version(should be like v0.1.0) */
        String str = firmware.getVersion();
        String pattern = Constant.FIRMWARE_VERSION_PATTERN;
        Pattern r = Pattern.compile(pattern);
        Matcher m = r.matcher(str);
        Assert.isTrue(m.find() && m.group().equals(str), "The format of \"version\" is incorrect! Legal format: \"v\" + number + \".\" + number + \".\" + number!");

        /* Check if the specified model exists */
        Query query = new Query();
        query.addCriteria(Criteria.where("modelId").is(modelId));
        ModelDO modelDO = mongoDBUtils.findOne(query, ModelDO.class);
        if (Objects.nonNull(modelDO)) {
            /* Get the information of the input body */
            MultipartFile multipartFile = firmware.getFile();
            String name = firmware.getName();
            String version = firmware.getVersion();
            String description = firmware.getDescription();

            /* Get firmware data and make sure it is not null */
            Map<String, ModelFirmwareDO> firmwares = modelDO.getFirmwares();
            if (Objects.isNull(firmwares)) {
                firmwares = new HashMap<>();
            }

            /* Check if the firmware version already exists */
            if (!firmwares.containsKey(version)) {
                /* Save input file */
                String relativePath = String.format("%s/%s/%s", modelId, version, name);
                try {
                    ROOT_LOCATION = ROOT_LOCATION.endsWith("/") ? ROOT_LOCATION : ROOT_LOCATION + "/";
                    File file = new File(ROOT_LOCATION + relativePath);
                    file.getParentFile().mkdirs();
                    multipartFile.transferTo(file);
                } catch (Exception e) {
                    logger.error("Transfer multipartFile to file failed. {}: {}", e.getClass().getName(),
                            e.getMessage());
                    e.printStackTrace();
                }

                /* Save data */
                ModelFirmwareDO firmwareDO = new ModelFirmwareDO();
                firmwareDO.setName(name);
                firmwareDO.setVersion(version);
                firmwareDO.setDescription(description);
                firmwareDO.setRelativePath(relativePath);
                firmwareDO.setUploadDate(DateTime.now().toString(Constant.DATEFMT_UPDATE_TIME));
                firmwares.put(version, firmwareDO);

                /* Update mongoDB */
                Update update = new Update();
                update.set("firmwares", firmwares);
                mongoDBUtils.upsert(query, update, ModelDO.class);

                return new ResultVO(HttpStatus.OK);
            } else {
                throw new KeyAlreadyExistsException("The given version already exists!");
            }
        } else {
            throw new DataNotFoundException("Target data not found!");
        }
    }

    /**
     * Delete the specified firmware record with the given modelId and version.
     * 
     * @param modelId ID of the specified model
     * @param version Version of the target firmware
     * @return
     */
    public ResultVO deleteModelFirmwareData(String modelId, String[] versions) {
        /* Check input parameter, make sure they are not null */
        Assert.notNull(modelId, "ModelId must not be null!");
        Assert.notEmpty(versions, "Versions must not be empty");

        /* Check if the specified model exists */
        Query query = new Query();
        query.addCriteria(Criteria.where("modelId").is(modelId));
        ModelDO modelDO = mongoDBUtils.findOne(query, ModelDO.class);
        if (Objects.nonNull(modelDO)) {
            /* Get firmware data and make sure it is not null */
            Map<String, ModelFirmwareDO> firmwares = modelDO.getFirmwares();
            if (Objects.isNull(firmwares)) {
                firmwares = new HashMap<>();
            }

            /* Delete specified record */
            for (String version : versions) {
                if (firmwares.containsKey(version)) {
                    /* Delete local file */
                    ModelFirmwareDO firmwareDO = firmwares.get(version);
                    String relativePath = firmwareDO.getRelativePath();
                    ROOT_LOCATION = ROOT_LOCATION.endsWith("/") ? ROOT_LOCATION : ROOT_LOCATION + "/";
                    File file = new File(ROOT_LOCATION + relativePath);
                    if (file.exists() && file.isFile()) {
                        file.delete();
                    }
                    /* Delete parent folder */
                    file.getParentFile().delete();
                    /* Delete record */
                    firmwares.remove(version);
                }
            }

            /* Update mongoDB */
            Update update = new Update();
            update.set("firmwares", firmwares);
            mongoDBUtils.upsert(query, update, ModelDO.class);

            return new ResultVO(HttpStatus.OK);
        } else {
            throw new DataNotFoundException("Target data not found!");
        }
    }

    /**
     * Check if the version1 is bigger than version2
     * 
     * @param version1
     * @param version2
     * @return
     *      If result > 0, means version1 > version2;
     *      If result < 0, means version1 < version2;
     *      If result = 0, means version1 = version2;
     */
    public int compareFirmwareVersion(String version1, String version2) {
        String pattern = Constant.FIRMWARE_VERSION_PATTERN;
        Pattern r = Pattern.compile(pattern);
        Matcher m1 = r.matcher(version1);
        Matcher m2 = r.matcher(version2);
        if (m1.find() && m1.group().equals(version1) && m2.find() && m2.group().equals(version2)) {
            String[] str1 = version1.substring(1).split("\\.");
            String[] str2 = version2.substring(1).split("\\.");
            for (int i = 0; i < 3; i++) {
                int temp = Integer.parseInt(str1[0]) - Integer.parseInt(str2[0]);
                if (temp == 0) {
                    continue;
                }
                return temp;
            }
        } else {
            logger.error("Format of the input parameter is unexpected! version1: {}, version2: {}", version1, version2);
        }
        return 0;
    }

    /**
     * Query model firmware data by specified condition.
     * 
     * @param modelId ID of the model
     * @param version Version of the firmware data
     * @return
     */
    public Map<String, ModelFirmwarePojo> queryModelFirmwareDataByContent(String modelId, String version) {
        /* ModelId must be valid */
        if (StringUtils.isBlank(modelId)) {
            return null;
        }

        Query query = new Query();
        query.addCriteria(Criteria.where("modelId").is(modelId));
        ModelDO modelDO = mongoDBUtils.findOne(query, ModelDO.class);
        if (Objects.nonNull(modelDO)) {
            Map<String, ModelFirmwareDO> firmwareDOs = modelDO.getFirmwares();
            if (Objects.nonNull(firmwareDOs)) {
                Map<String, ModelFirmwarePojo> result = null;
                if (StringUtils.isBlank(version)) {
                    result = new HashMap<>();
                    for (String key : firmwareDOs.keySet()) {
                        /* Convert to ModelFirmwarePojo */
                        ModelFirmwarePojo firmwarePojo = new ModelFirmwarePojo();
                        firmwarePojo.setName(firmwareDOs.get(key).getName());
                        firmwarePojo.setVersion(firmwareDOs.get(key).getVersion());
                        firmwarePojo.setDescription(firmwareDOs.get(key).getDescription());
                        firmwarePojo.setUploadDate(firmwareDOs.get(key).getUploadDate());
                        firmwarePojo.setUrl(relativePathToUrl(firmwareDOs.get(key).getRelativePath()));

                        result.put(key, firmwarePojo);
                    }
                } else if (firmwareDOs.containsKey(version)) {
                    result = new HashMap<>();
                    /* Convert to ModelFirmwarePojo */
                    ModelFirmwarePojo firmwarePojo = new ModelFirmwarePojo();
                    firmwarePojo.setName(firmwareDOs.get(version).getName());
                    firmwarePojo.setVersion(firmwareDOs.get(version).getVersion());
                    firmwarePojo.setDescription(firmwareDOs.get(version).getDescription());
                    firmwarePojo.setUploadDate(firmwareDOs.get(version).getUploadDate());
                    firmwarePojo.setUrl(relativePathToUrl(firmwareDOs.get(version).getRelativePath()));

                    result.put(version, firmwarePojo);
                }
                return result;
            } else {
                logger.info("Current model record contains no firmware data. modelId: {}", modelId);
            }
        } else {
            logger.info("Specified model record not found! modelId: {}", modelId);
        }
        return null;
    }
    
    /**
     * Update the specified firmware record with the given firmware data.
     * 
     * @param modelId   ID of the specified model
     * @param
     * @return
     * 
     */
    public ResultVO updateModelFirmwareData(String modelId, ModelFirmwarePojo modelFirmwarePojo) {
    	Assert.notNull(modelId, "ModelId must not be null!");
        Assert.notNull(modelFirmwarePojo, "Body of this request must not be null!");
        Assert.hasLength(modelFirmwarePojo.getDescription(), "\"description\" in the body must not be null or empty!");
        Assert.notNull(modelFirmwarePojo.getName(), "\"name\" in the body must not be null!");
        Assert.notNull(modelFirmwarePojo.getUploadDate(), "\"uploadDate\" in the body must not be null!");
        Assert.notNull(modelFirmwarePojo.getUrl(), "\"url\" in the body must not be null!");
        Assert.notNull(modelFirmwarePojo.getVersion(), "\"version\" in the body must not be null!");
    	
        ResultVO result = new ResultVO(HttpStatus.OK);
        Query query = new Query();
        query.addCriteria(Criteria.where("modelId").is(modelId));
        ModelDO modelDO = mongoDBUtils.findOne(query, ModelDO.class);
        if(Objects.nonNull(modelDO)) {
        		Map<String, ModelFirmwareDO> firmwares = modelDO.getFirmwares();
					if(firmwares.containsKey(modelFirmwarePojo.getVersion())) {
						ModelFirmwareDO firmwareDO = firmwares.get(modelFirmwarePojo.getVersion());
						firmwareDO.setDescription(modelFirmwarePojo.getDescription());
						Update update = new Update();
		        		update.set("firmwares", firmwares);
		        		mongoDBUtils.upsert(query, update, ModelDO.class);
					} else {
						throw new DataNotFoundException("Invalid document");
					}
        }else {
        	throw new DataNotFoundException("Invalid document");
        }
    	return result;
    }
    
    /**
     * Update model status when the profile information changes.(Delete/Modify/Add)
     * 
     * @param profileIds The ID of the profile that has changed
     */
    public void updateModelStatusByProfileId(String[] profileIds) {
        /* Make search Criteria */
        Query query = new Query();
        query.addCriteria(Criteria.where("profileId").in((Object[]) profileIds));
        /* Get all relevant models */
        List<ModelDO> modelDOs = mongoDBUtils.find(query, ModelDO.class);

        /* Get all modelIds */
        List<String> modelIds = new ArrayList<>();
        modelDOs.removeAll(Collections.singleton(null));
        for (ModelDO modelDO : modelDOs) {
            modelIds.add(modelDO.getModelId());
        }

        updateModelStatus(modelIds.toArray(new String[0]));
    }

    /**
     * Update model status when the design information changes.(Delete/Modify/Add)
     * 
     * @param designIds The ID of the design that has changed
     */
    public void updateModelStatusByDesignId(String[] designIds) {
        /* Make search Criteria */
        Query query = new Query();
        query.addCriteria(Criteria.where("designId").in((Object[]) designIds));
        /* Get all relevant models */
        List<ModelDO> modelDOs = mongoDBUtils.find(query, ModelDO.class);

        /* Get all modelIds */
        List<String> modelIds = new ArrayList<>();
        modelDOs.removeAll(Collections.singleton(null));
        for (ModelDO modelDO : modelDOs) {
            modelIds.add(modelDO.getModelId());
        }

        updateModelStatus(modelIds.toArray(new String[0]));
    }

    /**
     * Update model status when the model information changes.(Delete/Modify/Add)
     * 
     * @param modelIds The ID of the model that has changed
     */
    public void updateModelStatusByModelId(String[] modelIds) {
        updateModelStatus(modelIds);
    }

    /**
     * Search model data with specified content.
     * 
     * @param modelIds
     * @param designIds
     * @param profileIds
     * @param datas
     * @return
     */
    public List<ModelPojo> queryModelDataByContent(String[] modelIds, String[] designIds, String[] profileIds,
            String[] datas) {
        List<ModelPojo> modelPojos = new ArrayList<>();
        /* Make search criteria */
        Query query = new Query();
        if (Objects.nonNull(modelIds) && modelIds.length > 0) {
            query.addCriteria(Criteria.where("modelId").in((Object[]) modelIds));
        }
        if (Objects.nonNull(designIds) && designIds.length > 0) {
            query.addCriteria(Criteria.where("designId").in((Object[]) designIds));
        }
        if (Objects.nonNull(profileIds) && profileIds.length > 0) {
            query.addCriteria(Criteria.where("profileId").in((Object[]) profileIds));
        }

        datas = Objects.isNull(datas)
                ? new String[] { "modelId", "designId", "profileId", "screenInfo", "conditions", "description" }
                : datas;
        List<String> items = Arrays.asList(datas);
        List<ModelDO> modelDOs = mongoDBUtils.find(query, ModelDO.class);
        for (ModelDO modelDO : modelDOs) {
            ModelPojo modelPojo = new ModelPojo();
            if (items.contains("modelId")) {
                modelPojo.setModelId(modelDO.getModelId());
            }
            if (items.contains("designId")) {
                modelPojo.setDesignId(modelDO.getDesignId());
            }
            if (items.contains("profileId")) {
                modelPojo.setProfileId(modelDO.getProfileId());
            }
            if (items.contains("screenInfo")) {
                modelPojo.setScreenInfo(modelDO.getScreenInfo());
            }
            if (items.contains("conditions")) {
                modelPojo.setConditions(modelDO.getConditions());
            }
            if (items.contains("description")) {
                modelPojo.setDescription(modelDO.getDescription());
            }
            modelPojos.add(modelPojo);
        }
        return modelPojos;
    }

    /**
     * Get the specified item of the specified modelIds.
     * 
     * @param modelIds ID of the specified models
     * @return
     */
    public Map<String, ModelStatusPojo> getModelStatus(String[] modelIds) {
        /* Make sure input parameter is an array */
        modelIds = Objects.nonNull(modelIds) ? modelIds : new String[0];
        /* Make response data */
        Map<String, ModelStatusPojo> status = new HashMap<>();
        for (String modelId : modelIds) {
            if (Objects.isNull(modelId)) {
                continue;
            }
            status.put(modelId,
                    modelStatus.getOrDefault(modelId, new ModelStatusPojo(false, Constant.MODELSTS_MODEL_NOTFOUND)));
        }

        return status;
    }

    /**
     * Update the status of the specified modelIds
     * 
     * @param modelIds ID of the model that needs to be updated
     */
    private void updateModelStatus(String[] modelIds) {
        /******************************************************/
        /* Get the detail information of the specified models */
        /******************************************************/
        Query query = new Query();
        query.addCriteria(Criteria.where("modelId").in((Object[]) modelIds));
        List<ModelDO> modelDOs = mongoDBUtils.find(query, ModelDO.class);
        modelDOs.removeAll(Collections.singleton(null));

        /*************************************************************/
        /* Get the information of the corresponding profiles/designs */
        /*************************************************************/
        List<String> profileIds = new ArrayList<>();
        List<String> designIds = new ArrayList<>();
        for (ModelDO modelDO : modelDOs) {
            profileIds.add(modelDO.getProfileId());
            designIds.add(modelDO.getDesignId());
        }

        /* Get profile information */
        List<ProfilePojo> profilePojos = profileManager.queryProfileDataByContent(profileIds.toArray(new String[0]),
                null, new String[] { "profileId", "profileType" });
        List<String> validProfileIds = new ArrayList<>();
        List<String> invalidProfileIds = new ArrayList<>();
        profilePojos.removeAll(Collections.singleton(null));
        for (ProfilePojo profilePojo : profilePojos) {
            if (ProfileType.MODEL_PROFILE.getValue().equalsIgnoreCase(profilePojo.getProfileType())) {
                validProfileIds.add(profilePojo.getProfileId());
            } else {
                invalidProfileIds.add(profilePojo.getProfileId());
            }
        }

        /* Get design information */
        List<DesignPojo> designPojos = designManager.queryDesignDataByContent(designIds.toArray(new String[0]),
                new String[] { "designId" });
        List<String> validDesignIds = new ArrayList<>();
        designPojos.removeAll(Collections.singleton(null));
        for (DesignPojo designPojo : designPojos) {
            validDesignIds.add(designPojo.getDesignId());
        }

        /*************************************************/
        /* Update the status of all the specified models */
        /*************************************************/
        List<String> validModelIds = new ArrayList<>();
        for (ModelDO modelDO : modelDOs) {
            /* Model status structure */
            ModelStatusPojo modelStatusPojo = new ModelStatusPojo();

            String designId = modelDO.getDesignId();
            String profileId = modelDO.getProfileId();
            /********************************************************/
            /* Update the status information of the current profile */
            /********************************************************/
            if (validProfileIds.contains(profileId)) {
                modelStatusPojo.getProfileStatus().setHealthy(true);
                modelStatusPojo.getProfileStatus().setReason("");
            } else if (invalidProfileIds.contains(profileId)) {
                modelStatusPojo.getProfileStatus().setHealthy(false);
                modelStatusPojo.getProfileStatus().setReason(Constant.MODELSTS_PROFILE_WRONGTYPE);
            } else {
                modelStatusPojo.getProfileStatus().setHealthy(false);
                modelStatusPojo.getProfileStatus().setReason(Constant.MODELSTS_PROFILE_NOTFOUND);
            }

            /*******************************************************/
            /* Update the status information of the current design */
            /*******************************************************/
            if (validDesignIds.contains(designId)) {
                modelStatusPojo.getDesignStatus().setHealthy(true);
                modelStatusPojo.getDesignStatus().setReason("");
            } else {
                modelStatusPojo.getDesignStatus().setHealthy(false);
                modelStatusPojo.getDesignStatus().setReason(Constant.MODELSTS_DESIGN_NOTFOUND);
            }

            /******************************************/
            /* Determine the final state of the model */
            /******************************************/
            if (modelStatusPojo.getProfileStatus().isHealthy() && modelStatusPojo.getDesignStatus().isHealthy()) {
                modelStatusPojo.setHealthy(true);
                modelStatusPojo.setReason("");
            } else {
                modelStatusPojo.setHealthy(false);
                if (modelStatusPojo.getProfileStatus().isHealthy() == false) {
                    modelStatusPojo.setReason(modelStatusPojo.getProfileStatus().getReason());
                } else {
                    modelStatusPojo.setReason(modelStatusPojo.getDesignStatus().getReason());
                }
            }
            modelStatus.put(modelDO.getModelId(), modelStatusPojo);
            validModelIds.add(modelDO.getModelId());
        }

        /**************************************************/
        /* Remove the information of the deleted modelIds */
        /**************************************************/
        for (String modelId : modelIds) {
            if (!validModelIds.contains(modelId)) {
                modelStatus.remove(modelId);
            }
        }

        /**************************/
        /* Refresh other services */
        /**************************/
        try {
            serviceRouter.doUpdateRouterFile(Arrays.asList(modelIds));
        } catch (Exception e) {
            logger.warn("Update service router failed. {} : {}", e.getClass().getName(), e.getMessage());
        }
    }

    /**
     * DO => POJO
     * 
     * @param modelDO
     * @return
     */
    private final ModelPojo domainToPojo(ModelDO modelDO) {
        ModelPojo modelPojo = new ModelPojo();
        modelPojo.setModelId(modelDO.getModelId());
        modelPojo.setDesignId(modelDO.getDesignId());
        modelPojo.setProfileId(modelDO.getProfileId());
        modelPojo.setScreenInfo(modelDO.getScreenInfo());
        modelPojo.setConditions(modelDO.getConditions());
        modelPojo.setDescription(modelDO.getDescription());
        return modelPojo;
    }

    /**
     * POJO => DO
     * 
     * @param modelPojo
     * @return
     * @throws IllegalArgumentException
     */
    private final ModelDO pojoToDomain(ModelPojo modelPojo) {
        ModelDO modelDO = new ModelDO();
        modelDO.setModelId(modelPojo.getModelId());
        modelDO.setDesignId(modelPojo.getDesignId());
        modelDO.setProfileId(modelPojo.getProfileId());
        modelDO.setScreenInfo(modelPojo.getScreenInfo() == null ? "{}" : modelPojo.getScreenInfo());
        modelDO.setConditions(modelPojo.getConditions() == null ? new HashMap<>() : modelPojo.getConditions());
        modelDO.setDescription(modelPojo.getDescription() == null ? "" : modelPojo.getDescription());
        return modelDO;
    }
    
    /**
     * Replace the old data with the new data.(Which means the old data is exist)
     * 
     * @param oldModelId ID of the old model data
     * @param modelDO    New model data
     */
    private void replaceOldRecord(String oldModelId, ModelDO modelDO) {
        /* Make search criteria */
        Query query = new Query();
        query.addCriteria(Criteria.where("modelId").is(oldModelId));

        /* Make update */
        Update update = new Update();
        update.set("modelId", modelDO.getModelId());
        update.set("designId", modelDO.getDesignId());
        update.set("profileId", modelDO.getProfileId());
        update.set("screenInfo", modelDO.getScreenInfo());
        update.set("conditions", modelDO.getConditions());
        update.set("description", modelDO.getDescription());
        /* Update data */
        mongoDBUtils.upsert(query, update, ModelDO.class);
    }

    /**
     * RelativePath ⇒ URI
     * 
     * @param relativePath
     * @return
     */
    private String relativePathToUrl(String relativePath) {
        try {
            String IP = InetAddress.getLocalHost().getHostName();
            relativePath = relativePath.replace(File.separator, "/");
            return String.format("http://%s:%s/%s", IP, serverPort, relativePath);
        } catch (UnknownHostException e) {
            logger.error("Failed to get the host name");
            e.printStackTrace();
            return null;
        }
    }
}
