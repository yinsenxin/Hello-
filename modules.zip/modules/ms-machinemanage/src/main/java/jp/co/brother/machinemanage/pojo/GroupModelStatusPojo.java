package jp.co.brother.machinemanage.pojo;

import lombok.Data;

@Data
public class GroupModelStatusPojo {
	/**
	 * this is a healthy about GroupModel
	 */
	private Boolean healthy;
	/**
	 * this is a reason about GroupModel
	 */
	private String reason;
	/**
	 * this is a profileStatusPojo data  about GroupModel
	 */
	private ProfileStatusPojo profileStatusPojo;
	
	public GroupModelStatusPojo() {
		this.healthy = false;
		this.reason = "";
		this.profileStatusPojo = new ProfileStatusPojo();
	}
	
	
	public GroupModelStatusPojo(Boolean healthy, String reason) {
		this.healthy = healthy;
		this.reason = reason;
		this.profileStatusPojo = new ProfileStatusPojo();
		
	}
	
	
}
