package jp.co.brother.machinemanage.constant;

public enum UpdateStrategy {
    /**
     * The update strategy of the machine firmware.
     *     AUTO  : Always updated to the latest version
     *     MANUAL: Update to the specified version
     *     NONE  : Do not update
     */
    AUTO("auto"), MANUAL("manual"), NONE("none");

    private String value = "";

    private UpdateStrategy(String value) {
        this.value = value;
    }

    public String getValue() {
        return value;
    }
}
