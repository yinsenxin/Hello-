package jp.co.brother.machinemanage.pojo;

import java.util.List;

import lombok.Data;

@Data
public class ProfilePojo {

	/**
	 * The unique ID of the profile data.
	 */
	private String profileId;
	/**
	 * The type of the profile data.
	 */
	private String profileType;
	/**
	 * The service that the current profile should provide.
	 */
	private List<String> services;
}
