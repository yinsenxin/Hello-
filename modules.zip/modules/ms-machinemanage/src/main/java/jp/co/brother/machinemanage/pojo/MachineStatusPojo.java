package jp.co.brother.machinemanage.pojo;

import java.util.HashMap;
import java.util.Map;

import lombok.Data;

@Data
public class MachineStatusPojo {

    private boolean healthy;
    private String reason;
    private ModelStatusPojo modelStatus;
    private Map<String, DeviceStatusPojo> deviceStatus;

    public MachineStatusPojo() {
        this.healthy = false;
        this.reason = "";
        this.modelStatus = new ModelStatusPojo();
        this.deviceStatus = new HashMap<>();
    }

    public MachineStatusPojo(boolean healthy, String reason) {
        this.healthy = healthy;
        this.reason = reason;
        this.modelStatus = new ModelStatusPojo();
        this.deviceStatus = new HashMap<>();
    }
}
