package jp.co.brother.machinemanage.domain;

import java.util.List;
import java.util.Map;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import com.alibaba.fastjson.annotation.JSONField;

import jp.co.brother.machinemanage.constant.UpdateStrategy;
import lombok.Data;

@Data
@Document(collection = "Machine")
public class MachineDO {

    @Id
    @JSONField(serialize = false)
    private String id;
    /**
     * The unique ID of the machine data.
     */
    private String machineId;
    /**
     * The ID of the model to which the current machine belongs.
     */
    private String modelId;
    /**
     * The conditions of the current machine.
     */
    private Map<String, Object> conditions;
    /**
     * The devices bound by the current machine.
     */
    private List<String> bindDevices;
    /**
     * The description of the current machine.
     */
    private String description;
    /**
     * The strategy of how to update the machine firmware.
     */
    private UpdateStrategy updateStrategy;
    /**
     * The specified firmware version.
     * (This item is valid if and only if the update strategy is "MANUAL")
     */
    private String firmwareVersion;
    /**
     * The ID of the user who is currently using the machine.
     */
    @JSONField(serialize = false)
    private String userId;
}
