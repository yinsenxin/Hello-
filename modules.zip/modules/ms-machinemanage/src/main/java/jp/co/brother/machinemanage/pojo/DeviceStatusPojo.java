package jp.co.brother.machinemanage.pojo;

import lombok.Data;

@Data
public class DeviceStatusPojo {

    private boolean healthy;
    private String reason;

    public DeviceStatusPojo() {
        this.healthy = false;
        this.reason = "";
    }

    public DeviceStatusPojo(boolean healthy, String reason) {
        this.healthy = healthy;
        this.reason = reason;
    }
}
