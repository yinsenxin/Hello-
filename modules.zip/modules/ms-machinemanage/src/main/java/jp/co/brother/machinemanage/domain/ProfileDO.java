package jp.co.brother.machinemanage.domain;

import java.util.List;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import com.alibaba.fastjson.annotation.JSONField;

import jp.co.brother.machinemanage.constant.ProfileType;
import lombok.Data;

@Data
@Document(collection = "Profile")
public class ProfileDO {

    @Id
    @JSONField(serialize = false)
    private String id;
    /**
     * The unique ID of the profile data.
     */
    private String profileId;
    /**
     * The type of the profile data.
     */
    private ProfileType profileType;
    /**
     * The service that the current profile should provide.
     */
    private List<String> services;
}
