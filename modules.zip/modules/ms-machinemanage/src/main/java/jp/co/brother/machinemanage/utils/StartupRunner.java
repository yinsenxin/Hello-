package jp.co.brother.machinemanage.utils;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import jp.co.brother.machinemanage.pojo.DevicePojo;
import jp.co.brother.machinemanage.pojo.MachinePojo;
import jp.co.brother.machinemanage.pojo.ModelPojo;
import jp.co.brother.machinemanage.service.DeviceManager;
import jp.co.brother.machinemanage.service.MachineManager;
import jp.co.brother.machinemanage.service.ModelManager;


@Component
public class StartupRunner implements CommandLineRunner {

    @Autowired
    private DeviceManager deviceManager;
    @Autowired
    private ModelManager modelManager;
    @Autowired
    private MachineManager machineManager;
    private static final Logger logger = LoggerFactory.getLogger(StartupRunner.class);

    @Override
    public void run(String... args) {
        logger.info("Application startup finished, initialize data state cache...");

        try {
            List<DevicePojo> devicePojos = deviceManager.queryDeviceDataByContent(null, null,
                    new String[] { "deviceId" });
            List<String> deviceIds = new ArrayList<>();
            for (DevicePojo devicePojo : devicePojos) {
                deviceIds.add(devicePojo.getDeviceId());
            }
            deviceManager.updateDeviceStatusByDeviceId(deviceIds.toArray(new String[0]));

            List<ModelPojo> modelPojos = modelManager.queryModelDataByContent(null, null, null,
                    new String[] { "modelId" });
            List<String> modelIds = new ArrayList<>();
            for (ModelPojo modelPojo : modelPojos) {
                modelIds.add(modelPojo.getModelId());
            }
            modelManager.updateModelStatusByModelId(modelIds.toArray(new String[0]));

            List<MachinePojo> machinePojos = machineManager.queryMachineDataByContent(null, null, null,
                    new String[] { "machineId" });
            List<String> machineIds = new ArrayList<>();
            for (MachinePojo machinePojo : machinePojos) {
                machineIds.add(machinePojo.getMachineId());
            }
            machineManager.updateMachineStatusByMachineId(machineIds.toArray(new String[0]));
            logger.info("Finished!");
        } catch (Exception e) {
            logger.info("Exception happened, initialize operation failed! {}: {}", e.getClass().getName(),
                    e.getMessage());
            e.printStackTrace();
        }
    }
}