package jp.co.brother.machinemanage.service;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.InputStream;
import java.io.OutputStream;
import java.math.BigDecimal;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Hashtable;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang.StringEscapeUtils;
import org.apache.commons.lang.StringUtils;
import org.joda.time.DateTime;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;
import org.springframework.util.Assert;
import org.springframework.web.multipart.MultipartFile;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;

import jp.co.brother.machinemanage.constant.Constant;
import jp.co.brother.machinemanage.constant.UpdateStrategy;
import jp.co.brother.machinemanage.domain.MachineDO;
import jp.co.brother.machinemanage.exception.DataIsLockedException;
import jp.co.brother.machinemanage.exception.DataNotFoundException;
import jp.co.brother.machinemanage.pojo.DevicePojo;
import jp.co.brother.machinemanage.pojo.MachinePojo;
import jp.co.brother.machinemanage.pojo.MachineStatusPojo;
import jp.co.brother.machinemanage.pojo.ModelFirmwarePojo;
import jp.co.brother.machinemanage.pojo.ModelPojo;
import jp.co.brother.machinemanage.pojo.ProfilePojo;
import jp.co.brother.machinemanage.proxy.MachineApiRouter;
import jp.co.brother.machinemanage.proxy.ServiceRouter;
import jp.co.brother.machinemanage.utils.ExpressionEvaluator;
import jp.co.brother.machinemanage.utils.MongoDBUtils;
import jp.co.brother.machinemanage.utils.RedisUtils;
import jp.co.brother.machinemanage.vo.ResultVO;

@Component
public class MachineManager {

    @Autowired
    private MongoDBUtils<MachineDO> mongoDBUtils;
    @Autowired
    private QuartzManager quartzManager;
    @Autowired
    private ModelManager modelManager;
    @Autowired
    private ProfileManager profileManager;
    @Autowired
    private DeviceManager deviceManager;
    @Autowired
    private MachineApiRouter machineApiRouter;
    @Autowired
    private ServiceRouter serviceRouter;
    @Autowired
    private RedisUtils redisUtils;

    /* Map<DeviceId, MachineStatusPojo> */
    Map<String, MachineStatusPojo> machineStatus = new HashMap<>();
    private static final Logger logger = LoggerFactory.getLogger(MachineManager.class);

    /**
     * Get the status data of the specified machines.
     *
     * @param machineIds ID of the specified machines
     * @return
     */
    public ResultVO getMachineStatus(String[] machineIds) {
        ResultVO result = new ResultVO(HttpStatus.OK);
        /* Make sure input parameter is an array */
        machineIds = Objects.nonNull(machineIds) ? machineIds : machineStatus.keySet().toArray(new String[0]);
        /* Make response data */
        Map<String, MachineStatusPojo> status = new HashMap<>();
        for (String machineId : machineIds) {
            if (Objects.isNull(machineId)) {
                continue;
            }
            MachineStatusPojo machineStatusPojo = machineStatus.getOrDefault(machineId,
                    new MachineStatusPojo(false, Constant.MACHINESTS_MACHINE_NOTFOUND));
            status.put(machineId, machineStatusPojo);
        }
        result.setData(status);
        return result;
    }

    /**
     * Get the machines with specified conditions
     *
     * @param modelId
     * @param condition
     * @return
     */
    public ResultVO matchingMachine(String modelId, String condition) {
        ResultVO vo = new ResultVO(HttpStatus.OK);

        List<String> conditionalMachines = new ArrayList<>(0);
        // 获取所有机器
        Query query = new Query();
        query.addCriteria(Criteria.where("modelId").is(modelId));
        List<MachineDO> machineDOs = mongoDBUtils.find(query, MachineDO.class);
        // 判断检索条件
        if (StringUtils.isBlank(condition)) {
            // 如果条件为空，则返回该机型下的所有机器
            for (MachineDO machineDO : machineDOs) {
                conditionalMachines.add(machineDO.getMachineId());
            }
        } else {
            // 如果条件不为空，首先获取当前机型的所有可能条件的名称，并设定一个默认值
            // 反转义
            condition = StringEscapeUtils.unescapeHtml(condition);
            /**
             * ★注意 ： 这里的totalConditions中只保存了当前机型的所有可能拥有的Condition的默认值
             * 目的是为了保证当某一机器中没有ConditionA，但是Case的条件中包含ConditionA时，关于
             * ConditionA的判断结果会被判定为False
             */
            Hashtable<String, String> totalConditions = new Hashtable<>(0);
            for (MachineDO machineDO : machineDOs) {
                Map<String, Object> machineCondition = machineDO.getConditions();
                // 获取条件的名称及类型。由于是同一种机型，所以名称相同的条件，它的类型一定也是相同的，默认值也设为相同的
                for (String key : machineCondition.keySet()) {
                    Object value = machineCondition.get(key);

                    // 判断value的类型是数字还是字符串。如果是数字，则默认值为-1;如果是字符串，则默认值为""
                    if (isNumeric(value.toString())) {
                        value = -1;
                    } else {
                        value = "";
                    }

                    // 保存数据
                    totalConditions.put(key, value.toString());
                }
            }

            /**
             * 对totalConditions中的所有Key按照长度进行排序，保证先替换较长的condition。 避免出现以下问题：
             * 机器条件为：Tray==4和Skip Tray==1 ； Case条件为：Tray>=2&&Skip Tray==1
             * 先替换Tray==4时，会得到4>=2&&Skip 4==1的结果，导致机器无法匹配
             */
            List<String> totalKeys = new ArrayList<>(totalConditions.keySet());
            Collections.sort(totalKeys, new Comparator<Object>() {
                @Override
                public int compare(Object o1, Object o2) {
                    String str1 = o1.toString();
                    String str2 = o2.toString();
                    return str1.length() < str2.length() ? 1 : -1;
                }
            });

            // 分别判断每一台机器是否满足条件（不区分大小写）
            for (MachineDO machineDO : machineDOs) {
                String requiredCondition = condition.toLowerCase();
                Map<String, Object> machineCondition = machineDO.getConditions();

                // 替换表达式内的值。
                // 替换原则是：针对本机型所有可能的条件，从当前机器中获取该条件的值（如果未设定则使用默认值）。然后判断入力的condition中是否包含该条件，如果包含，则将该条件对应的值替换进去。
                for (String key : totalKeys) {
                    String keyTmp = key.toLowerCase();
                    Object valueTmp = machineCondition.getOrDefault(key, totalConditions.get(key));

                    // 判断value的类型是数字还是字符串。如果是数字，直接转换成字符串即可；如果是字符串，则需要给其加上双引号。
                    if (isNumeric(valueTmp.toString())) {
                        valueTmp = valueTmp.toString();
                    } else {
                        valueTmp = "\"" + machineCondition.get(key) + "\"";
                    }

                    if (requiredCondition.contains(keyTmp)) {
                        requiredCondition = requiredCondition.replaceAll(keyTmp, valueTmp.toString());
                    }
                }

                // 将表达式转换为全部小写
                requiredCondition = requiredCondition.toLowerCase();
                // 计算表达式的值
                Object result = null;
                try {
                    result = ExpressionEvaluator.eval(requiredCondition);
                } catch (Exception e) {
                    logger.error("condition expression error. expression: {}", requiredCondition);
                }
                // 判断表达式结果
                if (Objects.nonNull(result) && result.toString().equals("true")) {
                    conditionalMachines.add(machineDO.getMachineId());
                }
            }
        }

        vo.setData(conditionalMachines);
        return vo;
    }

    /**
     * Get all machine data with no condition.
     *
     * @return
     */
    public ResultVO getMachineData() {
        List<MachinePojo> machinePojos = new ArrayList<>();
        /* Get data from mongoDB */
        List<MachineDO> machineDOs = mongoDBUtils.findAll(MachineDO.class);
        /* Convert to POJO */
        for (MachineDO machineDO : machineDOs) {
            if (Objects.isNull(machineDO)) {
                logger.warn("Invalid document");
                continue;
            }
            /* DO => POJO */
            MachinePojo machine = domainToPojo(machineDO);
            machinePojos.add(machine);
        }

        ResultVO result = new ResultVO(HttpStatus.OK);
        result.setData(machinePojos);
        return result;
    }

    /**
     * Get the machine data of the specified machine.
     *
     * @param machineId ID of the specified machine
     * @return
     * @throws IllegalArgumentException, DataNotFoundException
     */
    public ResultVO getMachineData(String machineId) {
        /* Check input parameter, make sure they are not null */
        Assert.notNull(machineId, "MachineId must not be null!");

        ResultVO result = new ResultVO(HttpStatus.OK);
        /* Make search criteria */
        Query query = new Query();
        query.addCriteria(Criteria.where("machineId").is(machineId));
        /* Search data */
        MachineDO machineDO = mongoDBUtils.findOne(query, MachineDO.class);
        if (Objects.nonNull(machineDO)) {
            /* DO => POJO */
            MachinePojo machine = domainToPojo(machineDO);
            result.setData(machine);
        } else {
            throw new DataNotFoundException("Target data not found!");
        }
        return result;
    }

    /**
     * Add a new machine record.
     *
     * @param machineData machine data
     * @return
     * @throws IllegalArgumentException, DataIsLockedException
     */
    public ResultVO addMachineData(MachinePojo machineData) {
        /* Check input parameter, make sure they are not null */
        Assert.notNull(machineData, "Body of this request must not be null!");
        Assert.hasLength(machineData.getMachineId(), "\"machineId\" in the body must not be null or empty!");
        Assert.notNull(machineData.getModelId(), "\"modelId\" in the body must not be null!");
        Assert.notNull(machineData.getConditions(), "\"conditions\" in the body must not be null!");
        Assert.notNull(machineData.getBindDevices(), "\"bindDevices\" in the body must not be null!");
        Assert.notNull(machineData.getDescription(), "\"description\" in the body must not be null!");
        /* If the firmware version has been specified */
        if (Objects.nonNull(machineData.getFirmware())) {
            /* Check the format of the version(should be like v0.1.0) */
            String str = machineData.getFirmware();
            String pattern = Constant.FIRMWARE_VERSION_PATTERN;
            Pattern r = Pattern.compile(pattern);
            Matcher m = r.matcher(str);
            Assert.isTrue(m.find() && m.group().equals(str), "The format of \"version\" is incorrect! Legal format: \"v\" + number + \".\" + number + \".\" + number!");
        }
        /* DO NOT check userId. It is unused */

        /* Convert POJO to DO */
        MachineDO machineDO = pojoToDomain(machineData);

        /* Make search criteria */
        Query query = new Query();
        query.addCriteria(Criteria.where("machineId").is(machineDO.getMachineId()));
        /* Check if the target data exist */
        if (mongoDBUtils.exists(query, MachineDO.class)) {
            /* If current machine is locked by somebody, can not overwrite the data */
            if (isMachineLocked(machineDO.getMachineId())) {
                throw new DataIsLockedException("Target data is locked!");
            }

            /* Replace old record */
            replaceOldRecord(machineDO.getMachineId(), machineDO);
        } else {
            /* Save new data */
            mongoDBUtils.insert(machineDO);
        }

        /* Start a new thread to update the relevant data */
        quartzManager.updateMachineRelevantData(new String[]{machineData.getMachineId()});

        return new ResultVO(HttpStatus.OK);
    }

    /**
     * Update the specified machine record with the given machine data.
     *
     * @param machineId   ID of the specified machine
     * @param machineData machine data
     * @return
     * @throws IllegalArgumentException, DataIsLockedException,
     *                                   DataNotFoundException
     */
    public ResultVO updateMachineData(String machineId, MachinePojo machineData) {
        /* Check input parameter, make sure they are not null */
        Assert.notNull(machineId, "MachineId must not be null!");
        Assert.notNull(machineData, "Body of this request must not be null!");
        Assert.hasLength(machineData.getMachineId(), "\"machineId\" in the body must not be null or empty!");
        Assert.notNull(machineData.getModelId(), "\"modelId\" in the body must not be null!");
        Assert.notNull(machineData.getConditions(), "\"conditions\" in the body must not be null!");
        Assert.notNull(machineData.getBindDevices(), "\"bindDevices\" in the body must not be null!");
        Assert.notNull(machineData.getDescription(), "\"description\" in the body must not be null!");
        /* If the firmware version has been specified */
        if (Objects.nonNull(machineData.getFirmware())) {
            /* Check the format of the version(should be like v0.1.0) */
            String str = machineData.getFirmware();
            String pattern = Constant.FIRMWARE_VERSION_PATTERN;
            Pattern r = Pattern.compile(pattern);
            Matcher m = r.matcher(str);
            Assert.isTrue(m.find() && m.group().equals(str), "The format of \"version\" is incorrect! Legal format: \"v\" + number + \".\" + number + \".\" + number!");
        }
        /* DO NOT check userId. It is unused */

        ResultVO result = new ResultVO(HttpStatus.OK);
        /* Make search criteria */
        Query query = new Query();
        query.addCriteria(Criteria.where("machineId").is(machineId));
        /* Check if the target data exist */
        if (mongoDBUtils.exists(query, MachineDO.class)) {
            /* If current machine is locked by somebody, can not overwrite the data */
            if (isMachineLocked(machineId)) {
                throw new DataIsLockedException("Target data is locked!");
            }

            if (!machineId.equals(machineData.getMachineId())) {
                /* Check if the new machineId already exist */
                Query query1 = new Query();
                query1.addCriteria(Criteria.where("machineId").is(machineData.getMachineId()));
                if (mongoDBUtils.exists(query1, MachineDO.class)) {
                    throw new IllegalArgumentException("The \"machineId\" in the body has already been used!");
                }
            }

            /* Convert POJO to DO */
            MachineDO machineDO = pojoToDomain(machineData);
            /* Replace old record */
            replaceOldRecord(machineId, machineDO);
            /* Start a new thread to update the relevant data */
            quartzManager.updateMachineRelevantData(new String[]{machineId, machineData.getMachineId()});
        } else {
            throw new DataNotFoundException("Target data not found!");
        }
        return result;
    }

    /**
     * Lock the specified machine record with the specified userId.
     *
     * @param userId     The ID of the user who wants to lock the machine.
     * @param machineIds target machines
     * @return
     * @throws IllegalArgumentException, DataIsLockedException
     */
    public ResultVO lockMachineData(String userId, String[] machineIds) {
        /* Check input parameter, make sure they are not null */
        Assert.notNull(userId, "userId must not be null!");
        Assert.notEmpty(machineIds, "MachineIds must not be empty!");

        /* If any of the machines have been locked */
        if (isMachineLocked(userId, machineIds)) {
            throw new DataIsLockedException("Target data is locked!");
        }

        ResultVO result = new ResultVO(HttpStatus.OK);
        /* Make search criteria */
        Query query = new Query();
        query.addCriteria(Criteria.where("machineId").in((Object[]) machineIds));

        /* Check if all machineIDs are exist */
        HashSet<String> hSet = new HashSet<String>(Arrays.asList(machineIds));
        List<MachineDO> machineDOs = mongoDBUtils.find(query, MachineDO.class);
        if (machineDOs.size() != hSet.size()) {
            throw new DataNotFoundException("Target data not found!");
        }

        /* Make update */
        Update update = new Update();
        update.set("userId", userId);
        /* Update data */
        mongoDBUtils.updateMulti(query, update, MachineDO.class);
        /* Update machine lock status cache */
        DateTime dt = DateTime.now();
        for (String machineId : machineIds) {
            redisUtils.upsertMachineLockInfo(machineId, dt);
        }

        /* Start a new thread to update the relevant data */
        quartzManager.updateMachineRelevantData(machineIds);

        return result;
    }

    /**
     * Unlock the machine locked by the specified user.
     *
     * @param userId     The ID of the user who locked the machine
     * @param machineIds target machines
     * @return
     * @throws IllegalArgumentException
     */
    public ResultVO unlockMachineData(String userId, String[] machineIds) {
        /* Check input parameter, make sure they are not null */
        Assert.notNull(userId, "userId must not be null!");
        Assert.notEmpty(machineIds, "MachineIds must not be empty!");

        ResultVO result = new ResultVO(HttpStatus.OK);
        /* Make search criteria */
        Query query = new Query();
        query.addCriteria(Criteria.where("machineId").in((Object[]) machineIds).and("userId").is(userId));

        /* Check if all machineIDs are exist */
        HashSet<String> hSet = new HashSet<String>(Arrays.asList(machineIds));
        List<MachineDO> machineDOs = mongoDBUtils.find(query, MachineDO.class);
        if (machineDOs.size() != hSet.size()) {
            throw new DataNotFoundException("Target data not found!");
        }

        /* Make update */
        Update update = new Update();
        update.set("userId", "");
        /* Update data */
        mongoDBUtils.updateMulti(query, update, MachineDO.class);
        /* Update machine lock status cache */
        redisUtils.removeMachineLockInfo((Object[]) machineIds);

        /* Start a new thread to update the relevant data */
        quartzManager.updateMachineRelevantData(machineIds);

        return result;
    }

    /**
     * Unlock the specified machine.
     *
     * @param machineId target machine
     * @return
     */
    public ResultVO forceUnlockMachineData(String machineId) {
        /* Check input parameter, make sure they are not null */
        Assert.notNull(machineId, "userId must not be null!");

        ResultVO result = new ResultVO(HttpStatus.OK);
        /* Make search criteria */
        Query query = new Query();
        query.addCriteria(Criteria.where("machineId").is(machineId));

        /* Check if all machineIDs are exist */
        List<MachineDO> machineDOs = mongoDBUtils.find(query, MachineDO.class);
        if (machineDOs.isEmpty()) {
            throw new DataNotFoundException("Target data not found!");
        }

        /* Make update */
        Update update = new Update();
        update.set("userId", "");
        /* Update data */
        mongoDBUtils.updateMulti(query, update, MachineDO.class);
        /* Update machine lock status cache */
        redisUtils.removeMachineLockInfo(machineId);

        /* Start a new thread to update the relevant data */
        quartzManager.updateMachineRelevantData(new String[]{machineId});

        return result;
    }

    /**
     * Delete the specified machine record with the given machineIds.
     *
     * @param machineIds ID of the specified machines
     * @return
     * @throws IllegalArgumentException, DataIsLockedException
     */
    public ResultVO deleteMachineData(String[] machineIds) {
        /* Check input parameter, make sure they are not null */
        Assert.notEmpty(machineIds, "MachineIds must not be empty!");

        /* If current machine is locked by somebody, can not overwrite the data */
        if (isMachineLocked(machineIds)) {
            throw new DataIsLockedException("Target data is locked!");
        }

        ResultVO result = new ResultVO(HttpStatus.OK);
        /* Make search criteria */
        Query query = new Query();
        query.addCriteria(Criteria.where("machineId").in((Object[]) machineIds));
        /* Delete data */
        List<MachineDO> deletedDatas = new ArrayList<>();
        deletedDatas = mongoDBUtils.findAllAndRemove(query, MachineDO.class);
        /* Analyze result */
        Map<String, Boolean> hMap = new HashMap<>();
        for (MachineDO machineDO : deletedDatas) {
            if (Objects.isNull(machineDO)) {
                logger.warn("Invalid document");
                continue;
            }
            hMap.put(machineDO.getMachineId(), true);
        }
        for (String machineId : machineIds) {
            if (!hMap.containsKey(machineId)) {
                hMap.put(machineId, false);
            }
        }
        result.setData(hMap);

        /* Start a new thread to update the relevant data */
        quartzManager.updateMachineRelevantData(machineIds);

        return result;
    }

    /**
     * Download the machine data of the specified machines.
     *
     * @param response   response data of current HTTP request
     * @param machineIds ID of the specified machines
     * @return
     */
    public ResultVO exportMachineData(HttpServletResponse response, String[] machineIds) {
        /* Get all machine data */
        List<MachineDO> machineDOs = mongoDBUtils.findAll(MachineDO.class);
        machineDOs.removeAll(Collections.singleton(null));

        /* Get target machine data */
        List<MachineDO> targetDatas = new ArrayList<>();
        if (Objects.nonNull(machineIds) && machineIds.length > 0) {
            for (MachineDO machineDO : machineDOs) {
                String machineId = machineDO.getMachineId();
                if (Arrays.asList(machineIds).contains(machineId)) {
                    targetDatas.add(machineDO);
                }
            }
        } else {
            targetDatas.addAll(machineDOs);
        }

        /***********************************************/
        /* Save the target machine data to a JSON file */
        /***********************************************/
        String zipFileName = "MachineExport_" + DateTime.now().toString(Constant.DATEFMT_FILE_NAME) + ".json";
        try {
            /* Make directory & create JSON file */
            File dbFile = new File(zipFileName);
            dbFile.createNewFile();

            FileWriter dbFileWriter = new FileWriter(dbFile);
            dbFileWriter.write(JSONObject.toJSONString(targetDatas));
            dbFileWriter.flush();
            dbFileWriter.close();

            /* Make response */
            File zipFile = new File(zipFileName);
            if (zipFile.exists()) {
                InputStream fis = new BufferedInputStream(new FileInputStream(zipFile.getAbsolutePath()));
                byte[] buffer = new byte[fis.available()];
                fis.read(buffer);
                fis.close();

                response.reset();
                response.setHeader("Content-Disposition", "attachment;fileName=" + zipFileName);
                response.addHeader("Content-Length", "" + zipFile.length());
                OutputStream toClient = new BufferedOutputStream(response.getOutputStream());
                response.setContentType("application/octet-stream");
                toClient.write(buffer);
                toClient.flush();
                toClient.close();
            }
        } catch (Exception e) {
            logger.info("Error occurred while export machine data");
            logger.error("{}: {}", e.getClass().getName(), e.getMessage());
            e.printStackTrace();
        } finally {
            /* Delete local JSON file */
            File zipFile = new File(zipFileName);
            if (zipFile.exists()) {
                zipFile.delete();
            }
        }

        return null;
    }

    /**
     * Import machine data.
     *
     * @param file machine data
     * @return
     */
    public ResultVO importMachineData(MultipartFile file) {
        ResultVO result = new ResultVO(HttpStatus.OK);
        JSONObject topContainer = new JSONObject();

        /* If the uploaded file is not empty */
        if (!file.isEmpty()) {
            /* ID of the machine data that was successfully imported */
            List<String> machineIds = new ArrayList<>();

            try {
                /* Read the uploaded JSON file */
                String jsonfileContent = new String(file.getBytes(), StandardCharsets.UTF_8);

                /* Convert JSON string to MachineDO object */
                List<MachineDO> machineDOs = JSONObject.parseArray(jsonfileContent, MachineDO.class);
                if (Objects.nonNull(machineDOs)) {
                    JSONArray detail = new JSONArray();
                    machineDOs.removeAll(Collections.singleton(null));
                    for (MachineDO machineDO : machineDOs) {
                        JSONObject errorInfo = new JSONObject();
                        /* Check machine ID */
                        String machineId = machineDO.getMachineId();
                        if (StringUtils.isBlank(machineId)) {
                            errorInfo.put("id", machineId);
                            errorInfo.put("reason", "\"machineId\" must not be null/\"\"");
                            detail.add(errorInfo);
                            continue;
                        }
                        /* Check if the machineId already exists */
                        Query query = new Query();
                        query.addCriteria(Criteria.where("machineId").is(machineId));
                        if (mongoDBUtils.exists(query, MachineDO.class)) {
                            errorInfo.put("id", machineId);
                            errorInfo.put("reason", "\"machineId\" already exists in DataBase");
                            detail.add(errorInfo);
                            continue;
                        }

                        /* Save data */
                        mongoDBUtils.insert(machineDO);
                        machineIds.add(machineId);
                    }

                    if (!detail.isEmpty()) {
                        topContainer.put("result", "NG");
                        topContainer.put("detail", detail);
                        result.setData(topContainer);
                    } else {
                        topContainer.put("result", "OK");
                        result.setData(topContainer);
                    }
                } else {
                    topContainer.put("result", "NG");
                    topContainer.put("reason", "No valid machine data");
                    result.setData(topContainer);
                }
            } catch (Exception e) {
                logger.error("Error occurred while import machine data");
                logger.error("{}: {}", e.getClass().getName(), e.getMessage());
                e.printStackTrace();
                topContainer.put("result", "NG");
                topContainer.put("reason", "Internal exception: " + e.getMessage());
                result.setData(topContainer);
            } finally {
                /* Start a new thread to update the relevant data */
                quartzManager.updateMachineRelevantData(machineIds.toArray(new String[0]));
            }
        } else {
            topContainer.put("result", "NG");
            topContainer.put("reason", "Empty file is uploaded.");
            result.setData(topContainer);
        }

        return result;
    }

    /**
     * Get all machines that meet the specified condition
     *
     * @param machineIds ID of the target machines
     * @param modelIds   ModelId of the target machines
     * @param userIds    UserId of the target machines
     * @param datas      The field that needs to be returned
     * @return
     */
    public ResultVO queryMachineData(String[] machineIds, String[] modelIds, String[] userIds, String[] datas) {
        /* Make response */
        ResultVO result = new ResultVO(HttpStatus.OK);

        /* Query data */
        List<MachinePojo> machinePojos = queryMachineDataByContent(machineIds, modelIds, userIds, datas);
        /* Make response data */
        if (Objects.nonNull(datas)) {
            List<Map<String, Object>> responseDatas = new ArrayList<>();
            List<String> names = Arrays.asList(datas);
            for (MachinePojo machinePojo : machinePojos) {
                Map<String, Object> map = new HashMap<>();
                if (names.contains("machineId")) {
                    map.put("machineId", machinePojo.getMachineId());
                }
                if (names.contains("modelId")) {
                    map.put("modelId", machinePojo.getModelId());
                }
                if (names.contains("conditions")) {
                    map.put("conditions", machinePojo.getConditions());
                }
                if (names.contains("bindDevices")) {
                    map.put("bindDevices", machinePojo.getBindDevices());
                }
                if (names.contains("description")) {
                    map.put("description", machinePojo.getDescription());
                }
                if (names.contains("updateStrategy")) {
                    map.put("updateStrategy", machinePojo.getUpdateStrategy());
                }
                if (names.contains("firmware")) {
                    map.put("firmware", machinePojo.getFirmware());
                }
                if (names.contains("userId")) {
                    map.put("userId", machinePojo.getUserId());
                }
                responseDatas.add(map);
            }
            result.setData(responseDatas);
        } else {
            result.setData(machinePojos);
        }

        return result;
    }

    /**
     * Check if the firmware version of the machine needs to be updated.
     *
     * @param machineId      ID of the target machine
     * @param clientFirmware The current firmware version of the specified machine
     * @return
     */
    public ResultVO checkFirmwareUpdate(String machineId, String clientFirmware) {
        Assert.notNull(machineId, "MachineId must not be null!");
        Assert.notNull(clientFirmware, "Firmware must not be null!");

        /* Get the update settings of the specified machine */
        Query query = new Query();
        query.addCriteria(Criteria.where("machineId").is(machineId));
        MachineDO machineDO = mongoDBUtils.findOne(query, MachineDO.class);
        if (Objects.isNull(machineDO)) {
            throw new DataNotFoundException("Target data not found! Please check if the machineId is correct.");
        }

        ResultVO result = new ResultVO(HttpStatus.OK);
        JSONObject json = new JSONObject();
        /* Get update strategy and firmware */
        UpdateStrategy strategy = machineDO.getUpdateStrategy();
        String firmwareVersion = machineDO.getFirmwareVersion();
        if (strategy == UpdateStrategy.AUTO) {
            /* Get all firmware data */
            Map<String, ModelFirmwarePojo> firmwarePojos = modelManager
                    .queryModelFirmwareDataByContent(machineDO.getModelId(), null);
            if (Objects.nonNull(firmwarePojos)) {
                /* Find the latest firmware version */
                List<String> versionInfos = new ArrayList<>(firmwarePojos.keySet());
                /* Sort */
                Collections.sort(versionInfos, new Comparator<String>() {
                    @Override
                    public int compare(String version1, String version2) {
                        return modelManager.compareFirmwareVersion(version1, version2);
                    }
                });

                ModelFirmwarePojo firmwarePojo = firmwarePojos.get(versionInfos.get(versionInfos.size() - 1));
                /* Tell client to update to the latest firmware */
                json.put("update", true);
                json.put("firmware", firmwarePojo.getVersion());
                json.put("url", firmwarePojo.getUrl());
            } else {
                /* Get firmware information failed, tell client DO NOT UPDATE */
                logger.error("Failed to get the latest firmware, will not update the client. machineId: {}", machineId);
                json.put("update", false);
            }
        } else if (strategy == UpdateStrategy.MANUAL) {
            Map<String, ModelFirmwarePojo> firmwarePojos = modelManager
                    .queryModelFirmwareDataByContent(machineDO.getModelId(), firmwareVersion);
            if (Objects.nonNull(firmwarePojos)) {
                ModelFirmwarePojo firmwarePojo = firmwarePojos.get(firmwareVersion);
                /* Tell client to update to the latest firmware */
                json.put("update", true);
                json.put("firmware", firmwarePojo.getVersion());
                json.put("url", firmwarePojo.getUrl());
            } else {
                /* Get firmware information failed, tell client DO NOT UPDATE */
                logger.error(
                        "Failed to get the latest firmware, will not update the client. machineId: {}, version: {}",
                        machineId, firmwareVersion);
                json.put("update", false);
            }
        } else if (strategy == UpdateStrategy.NONE) {
            logger.info("Update strategy of the specified machine is NONE, will not update the machine");
            json.put("update", false);
        } else {
            logger.error("Update strategy of the specified machine is not specified");
        }

        /* Check the firmware version */
        if (clientFirmware.equals(json.get("firmware"))) {
            json.put("update", false);
        }

        result.setData(json);
        return result;
    }

    /**
     * Update machine status when the profile information
     * changes.(Delete/Modify/Add)
     *
     * @param profileIds The ID of the profile that has changed
     */
    public void updateMachineStatusByProfileId(String[] profileIds) {
        /*
         * Profile changes will affect the state of the model and the device. But, it
         * WILL NOT change the number of devices/models
         */
        /* Get affected modelIds */
        List<ModelPojo> modelPojos = modelManager.queryModelDataByContent(null, null, profileIds,
                new String[]{"modelId"});
        List<String> modelIds = new ArrayList<>();
        modelPojos.removeAll(Collections.singleton(null));
        for (ModelPojo modelPojo : modelPojos) {
            modelIds.add(modelPojo.getModelId());
        }
        updateMachineStatusByModelId(modelIds.toArray(new String[0]));

        /* Get affected deviceIds */
        List<DevicePojo> devicePojos = deviceManager.queryDeviceDataByContent(null, profileIds,
                new String[]{"deviceId"});
        List<String> deviceIds = new ArrayList<>();
        devicePojos.removeAll(Collections.singleton(null));
        for (DevicePojo devicePojo : devicePojos) {
            deviceIds.add(devicePojo.getDeviceId());
        }
        updateMachineStatusByDeviceId(deviceIds.toArray(new String[0]));
    }

    /**
     * Update machine status when the design information changes.(Delete/Modify/Add)
     *
     * @param designIds The ID of the design that has changed
     */
    public void updateMachineStatusByDesignId(String[] designIds) {
        /*
         * Changes in Design information will affect Model information(the model status,
         * not the required service list). Therefore, the state of the machine using
         * this model information will also be affected.
         */
        List<ModelPojo> modelPojos = modelManager.queryModelDataByContent(null, designIds, null,
                new String[]{"modelId"});
        List<String> modelIds = new ArrayList<>();
        modelPojos.removeAll(Collections.singleton(null));
        for (ModelPojo modelPojo : modelPojos) {
            modelIds.add(modelPojo.getModelId());
        }

        updateMachineStatusByModelId(modelIds.toArray(new String[0]));
    }

    /**
     * Update machine status when the model information changes.(Delete/Modify/Add)
     *
     * @param modelIds The ID of the model that has changed
     */
    public void updateMachineStatusByModelId(String[] modelIds) {
        /* Make search Criteria */
        Query query = new Query();
        query.addCriteria(Criteria.where("modelId").in((Object[]) modelIds));
        /* Get all relevant machines with the specified modelIds */
        List<MachineDO> machineDOs = mongoDBUtils.find(query, MachineDO.class);

        /* Get all machineIds */
        List<String> machineIds = new ArrayList<>();
        machineDOs.removeAll(Collections.singleton(null));
        /* Update the status information of the machines */
        for (MachineDO machineDO : machineDOs) {
            machineIds.add(machineDO.getMachineId());
        }

        updateMachineStatus(machineIds.toArray(new String[0]));
    }

    /**
     * Update machine status when the device information changes.(Delete/Modify/Add)
     *
     * @param deviceIds The ID of the device that has changed
     */
    public void updateMachineStatusByDeviceId(String[] deviceIds) {
        /* Make search Criteria */
        Query query = new Query();
        query.addCriteria(Criteria.where("bindDevices").in((Object[]) deviceIds));
        /* Get all relevant machines with the specified deviceIds */
        List<MachineDO> machineDOs = mongoDBUtils.find(query, MachineDO.class);

        /* Get all machineIds */
        List<String> machineIds = new ArrayList<>();
        machineDOs.removeAll(Collections.singleton(null));
        for (MachineDO machineDO : machineDOs) {
            machineIds.add(machineDO.getMachineId());
        }

        updateMachineStatus(machineIds.toArray(new String[0]));
    }

    /**
     * Update machine status when the machine information
     * changes.(Delete/Modify/Add)
     *
     * @param machineIds The ID of the machine that has changed
     */
    public void updateMachineStatusByMachineId(String[] machineIds) {
        updateMachineStatus(machineIds);
    }

    /**
     * Update the status of the specified machineIds
     *
     * @param machineIds ID of the machine that needs to be updated
     */
    private void updateMachineStatus(String[] machineIds) {
        /********************************************************/
        /* Get the detail information of the specified machines */
        /********************************************************/
        Query query = new Query();
        query.addCriteria(Criteria.where("machineId").in((Object[]) machineIds));
        List<MachineDO> machineDOs = mongoDBUtils.find(query, MachineDO.class);
        machineDOs.removeAll(Collections.singleton(null));

        /********************************************************************/
        /* Get the information of the corresponding models/devices/profiles */
        /********************************************************************/
        List<String> modelIds = new ArrayList<>();
        List<String> deviceIds = new ArrayList<>();
        for (MachineDO machineDO : machineDOs) {
            modelIds.add(machineDO.getModelId());
            deviceIds.addAll(machineDO.getBindDevices());
        }

        /* Get model information */
        List<ModelPojo> modelPojos = modelManager.queryModelDataByContent(modelIds.toArray(new String[0]), null, null,
                new String[]{"modelId", "profileId"});
        Map<String, String> mapModelIdProfileId = new HashMap<>();
        modelPojos.removeAll(Collections.singleton(null));
        for (ModelPojo modelPojo : modelPojos) {
            mapModelIdProfileId.put(modelPojo.getModelId(), modelPojo.getProfileId());
        }

        /* Get device information */
        List<DevicePojo> devicePojos = deviceManager.queryDeviceDataByContent(deviceIds.toArray(new String[0]), null,
                new String[]{"deviceId", "services"});
        Map<String, DevicePojo> mapDeviceIdDevicePojo = new HashMap<>();
        devicePojos.removeAll(Collections.singleton(null));
        for (DevicePojo devicePojo : devicePojos) {
            mapDeviceIdDevicePojo.put(devicePojo.getDeviceId(), devicePojo);
        }

        /* Get profile information */
        List<ProfilePojo> profilePojos = profileManager.queryProfileDataByContent(
                mapModelIdProfileId.values().toArray(new String[0]), null, new String[]{"profileId", "services"});
        Map<String, ProfilePojo> mapProfileIdProfilePojo = new HashMap<>();
        profilePojos.removeAll(Collections.singleton(null));
        for (ProfilePojo profilePojo : profilePojos) {
            mapProfileIdProfilePojo.put(profilePojo.getProfileId(), profilePojo);
        }

        /***************************************************/
        /* Update the status of all the specified machines */
        /***************************************************/
        List<String> validMachineIds = new ArrayList<>();
        for (MachineDO machineDO : machineDOs) {
            /* Machine status structure */
            MachineStatusPojo machineStatusPojo = new MachineStatusPojo();

            /****************************************************/
            /* Update the status information of all the devices */
            /****************************************************/
            List<String> bindDevices = machineDO.getBindDevices();
            machineStatusPojo.setDeviceStatus(deviceManager.getDeviceStatusById(bindDevices.toArray(new String[0])));

            /******************************************************/
            /* Update the status information of the current model */
            /******************************************************/
            String modelId = machineDO.getModelId();
            machineStatusPojo.setModelStatus(modelManager.getModelStatus(new String[]{modelId}).get(modelId));

            /***********************************************************/
            /* Check whether the service provided by the machine meets */
            /* the requirements of Profile */
            /***********************************************************/
            if (mapModelIdProfileId.containsKey(modelId)) {
                /* ModelId is valid */
                String profileId = mapModelIdProfileId.get(modelId);
                if (mapProfileIdProfilePojo.containsKey(profileId)) {
                    /* ProfileId is valid */
                    List<String> requiredServices = mapProfileIdProfilePojo.get(profileId).getServices();
                    List<String> providedServices = new ArrayList<>();
                    for (String deviceId : bindDevices) {
                        if (machineStatusPojo.getDeviceStatus().get(deviceId).isHealthy()
                                && mapDeviceIdDevicePojo.containsKey(deviceId)) {
                            providedServices.addAll(mapDeviceIdDevicePojo.get(deviceId).getServices().keySet());
                        }
                    }

                    if (providedServices.containsAll(requiredServices)
                            && machineStatusPojo.getModelStatus().isHealthy()) {
                        machineStatusPojo.setHealthy(true);
                        machineStatusPojo.setReason("");
                    } else {
                        machineStatusPojo.setHealthy(false);
                        if (machineStatusPojo.getModelStatus().isHealthy() == false) {
                            machineStatusPojo.setReason(machineStatusPojo.getModelStatus().getReason());
                        } else {
                            machineStatusPojo.setReason(Constant.MACHINESTS_SERVICE_DISCREPANCY);
                        }
                    }
                } else {
                    /*
                     * The model information of the current machine exists. But, the profile
                     * information of the model does not exist
                     */
                    machineStatusPojo.setHealthy(false);
                    machineStatusPojo.setReason(machineStatusPojo.getModelStatus().getReason());
                }
            } else {
                /* The model information of the current machine does not exist */
                machineStatusPojo.setHealthy(false);
                machineStatusPojo.setReason(machineStatusPojo.getModelStatus().getReason());
            }
            machineStatus.put(machineDO.getMachineId(), machineStatusPojo);
            validMachineIds.add(machineDO.getMachineId());
        }

        /****************************************************/
        /* Remove the information of the deleted machineIds */
        /****************************************************/
        for (String machineId : machineIds) {
            if (!validMachineIds.contains(machineId)) {
                machineStatus.remove(machineId);
            }
        }

        /**************************/
        /* Refresh other services */
        /**************************/
        try {
            machineApiRouter.doUpdateCache(StringUtils.join(machineIds, ','));
        } catch (Exception e) {
            logger.warn("Update machine router failed. {} : {}", e.getClass().getName(), e.getMessage());
        }
        try {
            serviceRouter.doUpdateRouterService(Arrays.asList(machineIds));
        } catch (Exception e) {
            logger.warn("Update service router failed. {} : {}", e.getClass().getName(), e.getMessage());
        }
    }

    /**
     * Search machine data with specified content.
     *
     * @param machineIds
     * @param modelIds
     * @param userIds
     * @param datas
     * @return
     */
    public List<MachinePojo> queryMachineDataByContent(String[] machineIds, String[] modelIds, String[] userIds,
                                                       String[] datas) {
        List<MachinePojo> machinePojos = new ArrayList<>();
        /* Make search criteria */
        Query query = new Query();
        if (Objects.nonNull(machineIds) && machineIds.length > 0) {
            query.addCriteria(Criteria.where("machineId").in((Object[]) machineIds));
        }
        if (Objects.nonNull(modelIds) && modelIds.length > 0) {
            query.addCriteria(Criteria.where("modelId").in((Object[]) modelIds));
        }
        if (Objects.nonNull(userIds) && userIds.length > 0) {
            query.addCriteria(Criteria.where("userId").in((Object[]) userIds));
        }

        datas = Objects.isNull(datas)
                ? new String[]{"machineId", "modelId", "conditions", "bindDevices", "description", "userId"}
                : datas;
        List<String> items = Arrays.asList(datas);
        List<MachineDO> machineDOs = mongoDBUtils.find(query, MachineDO.class);
        for (MachineDO machineDO : machineDOs) {
            MachinePojo machinePojo = new MachinePojo();
            if (items.contains("machineId")) {
                machinePojo.setMachineId(machineDO.getMachineId());
            }
            if (items.contains("modelId")) {
                machinePojo.setModelId(machineDO.getModelId());
            }
            if (items.contains("conditions")) {
                machinePojo.setConditions(machineDO.getConditions());
            }
            if (items.contains("bindDevices")) {
                machinePojo.setBindDevices(machineDO.getBindDevices());
            }
            if (items.contains("description")) {
                machinePojo.setDescription(machineDO.getDescription());
            }
            if (items.contains("updateStrategy")) {
                machinePojo.setUpdateStrategy(machineDO.getUpdateStrategy().getValue());
            }
            if (items.contains("firmware")) {
                machinePojo.setFirmware(machineDO.getFirmwareVersion());
            }
            if (items.contains("userId")) {
                machinePojo.setUserId(machineDO.getUserId());
            }
            machinePojos.add(machinePojo);
        }
        return machinePojos;
    }

    /**
     * Check if the given machineId is locked by some body.
     *
     * @param machineId
     * @return
     */
    private boolean isMachineLocked(String machineId) {
        Query query = new Query();
        query.addCriteria(Criteria.where("machineId").is(machineId).and("userId").regex("^(?!\\s).{1,}[^\\s]$"));
        /**
         * If the "userId" of the machine data contains any non-blank character, will
         * return true.
         */
        return mongoDBUtils.exists(query, MachineDO.class);
    }

    /**
     * Check if the given machineId is locked by some body except the specified user.
     *
     * @param userId
     * @param machineId
     * @return
     */
    private boolean isMachineLocked(String userId, String machineId) {
        Query query = new Query();
        query.addCriteria(Criteria.where("machineId").is(machineId));
        if (mongoDBUtils.exists(query, MachineDO.class)) {
            MachineDO machineDO = mongoDBUtils.findOne(query, MachineDO.class);
            if (StringUtils.isNotBlank(machineDO.getUserId()) && !userId.equals(machineDO.getUserId())) {
                return true;
            }
        }
        return false;
    }

    /**
     * Check if the given machineIds is locked by some body.
     *
     * @param machineId
     * @return
     */
    private boolean isMachineLocked(String[] machineIds) {
        /**
         * If any of the machines have been locked, return true.
         */
        for (String machineId : machineIds) {
            if (isMachineLocked(machineId)) {
                return true;
            }
        }
        return false;
    }

    /**
     * Check if the given machineIds is locked by some body except the specified user.
     *
     * @param userId
     * @param machineId
     * @return
     */
    private boolean isMachineLocked(String userId, String[] machineIds) {
        /**
         * If any of the machines have been locked, return true.
         */
        for (String machineId : machineIds) {
            if (isMachineLocked(userId, machineId)) {
                return true;
            }
        }
        return false;
    }

    /**
     * DO => POJO
     *
     * @param machineDO
     * @return
     */
    private final MachinePojo domainToPojo(MachineDO machineDO) {
        MachinePojo machinePojo = new MachinePojo();
        machinePojo.setMachineId(machineDO.getMachineId());
        machinePojo.setModelId(machineDO.getModelId());
        machinePojo.setConditions(machineDO.getConditions());
        machinePojo.setBindDevices(machineDO.getBindDevices());
        machinePojo.setDescription(machineDO.getDescription());
        UpdateStrategy strategy = machineDO.getUpdateStrategy();
        machinePojo.setUpdateStrategy(Objects.nonNull(strategy) ? strategy.getValue() : null);
        machinePojo.setFirmware(machineDO.getFirmwareVersion());
        machinePojo.setUserId(machineDO.getUserId());

        return machinePojo;
    }

    /**
     * POJO => DO
     *
     * @param machinePojo
     * @return
     * @throws IllegalArgumentException
     */
    private final MachineDO pojoToDomain(MachinePojo machinePojo) {
        MachineDO machineDO = new MachineDO();
        machineDO.setMachineId(machinePojo.getMachineId());
        machineDO.setModelId(machinePojo.getModelId());
        machineDO.setConditions(machinePojo.getConditions());
        machineDO.setBindDevices(machinePojo.getBindDevices());
        machineDO.setDescription(machinePojo.getDescription());
        UpdateStrategy strategy = UpdateStrategy.AUTO;
        if (UpdateStrategy.MANUAL.getValue().equalsIgnoreCase(machinePojo.getUpdateStrategy())) {
            strategy = UpdateStrategy.MANUAL;
        } else if (UpdateStrategy.NONE.getValue().equalsIgnoreCase(machinePojo.getUpdateStrategy())) {
            strategy = UpdateStrategy.NONE;
        }
        machineDO.setUpdateStrategy(strategy);
        machineDO.setFirmwareVersion(machinePojo.getFirmware());
        /* "userId" can only be set via "/machine/lock" API */
        machineDO.setUserId("");

        return machineDO;
    }

    /**
     * Replace the old data with the new data.(Which means the old data is exist)
     *
     * @param oldMachineId ID of the old machine data
     * @param machineDO    New machine data
     */
    private void replaceOldRecord(String oldMachineId, MachineDO machineDO) {
        /* Make search criteria */
        Query query = new Query();
        query.addCriteria(Criteria.where("machineId").is(oldMachineId));

        /* Make update */
        Update update = new Update();
        update.set("machineId", machineDO.getMachineId());
        update.set("modelId", machineDO.getModelId());
        update.set("conditions", machineDO.getConditions());
        update.set("bindDevices", machineDO.getBindDevices());
        update.set("description", machineDO.getDescription());
        update.set("updateStrategy", machineDO.getUpdateStrategy());
        update.set("firmwareVersion", machineDO.getFirmwareVersion());
        update.set("userId", machineDO.getUserId());
        /* Update data */
        mongoDBUtils.upsert(query, update, MachineDO.class);
    }

    private boolean isNumeric(String str) {
        if (Objects.isNull(str)) {
            return false;
        }
        boolean result = true;

        // 将字符串转换为BigDecimal以判断字符串是否是数字。
        // 仅针对十进制数据有效，包括整数、浮点数、双精度类型。
        // 支持字符串中包含"+"/"-"以及"e"/"E"
        // "1" : true
        // "-1" : true
        // "+1" : true
        // "++1" : false
        // "1.234" : true
        // "-1.234" : true
        // "+1.234" : true
        // "1.23.4" : false
        // "1.23E2" : true
        // "1.23e2" : true
        // "1 23" : false
        // " 123" : false
        // "123 " : false
        // "1a" : false
        // "0x1a" : false
        // "string" : false
        // "08" : true
        // "0b1101" : false
        try {
            @SuppressWarnings("unused")
            BigDecimal bDec = new BigDecimal(str);
        } catch (Exception e) {
            result = false;
        }
        return result;
    }

    /**
     * Get all machines that keyword-executable
     *
     * @param uri keyword file uri  - Keyword\MFC\EC
     * @return ResultVO
     */
    public ResultVO fuzzyQueryMachineInfo(String uri) {
        ResultVO resultVO;
        if ((uri == null) || StringUtils.isBlank(uri)) {
            return new ResultVO(HttpStatus.BAD_REQUEST);
        }
        String[] splitUris = uri.split("\\\\");
        StringBuilder modelIdBuilder = new StringBuilder();
        for (String splitUri : splitUris) {
            if (Constant.KEYWORD.equalsIgnoreCase(splitUri)) {
                continue;
            }
            modelIdBuilder.append(splitUri);
            modelIdBuilder.append("_");
        }
        // delete the last '_'
        String modelId = modelIdBuilder.deleteCharAt(modelIdBuilder.length() - 1).toString();

        Query query = new Query();
        Pattern pattern = Pattern.compile("^.*" + modelId + ".*$", Pattern.CASE_INSENSITIVE);
        query.addCriteria(Criteria.where(Constant.DB_QUERY_MACHINE_MODEL_ID).regex(pattern));
        List<MachineDO> machineDOList = mongoDBUtils.find(query, MachineDO.class);
        List<String> machineIdList = machineDOList.stream().map(MachineDO::getMachineId).collect(Collectors.toList());

        resultVO = new ResultVO(HttpStatus.OK);
        resultVO.setData(machineIdList);
        return resultVO;

    }

}
