package jp.co.brother.machinemanage.utils;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.lang.Nullable;
import org.springframework.stereotype.Component;

import com.mongodb.client.result.UpdateResult;

@Component
public class MongoDBUtils<T extends Object> {

    @Autowired
    private MongoTemplate mongoTemplate;

    public boolean exists(Query query, Class<T> entityClass) {
        return mongoTemplate.exists(query, entityClass);
    }

    public List<T> find(Query query, Class<T> entityClass) {
        return mongoTemplate.find(query, entityClass);
    }

    @Nullable
    public T findOne(Query query, Class<T> entityClass) {
        return mongoTemplate.findOne(query, entityClass);
    }

    public List<T> findAll(Class<T> entityClass) {
        return mongoTemplate.findAll(entityClass);
    }

    @Nullable
    public T findAndRemove(Query query, Class<T> entityClass) {
        return mongoTemplate.findAndRemove(query, entityClass);
    }

    public List<T> findAllAndRemove(Query query, Class<T> entityClass) {
        return mongoTemplate.findAllAndRemove(query, entityClass);
    }

    public T insert(T objectToSave) {
        return mongoTemplate.insert(objectToSave);
    }

    public T save(T objectToSave) {
        return mongoTemplate.save(objectToSave);
    }

    public UpdateResult upsert(Query query, Update update, Class<T> entityClass) {
        return mongoTemplate.upsert(query, update, entityClass);
    }

    public UpdateResult updateMulti(Query query, Update update, Class<T> entityClass) {
        return mongoTemplate.updateMulti(query, update, entityClass);
    }
}
