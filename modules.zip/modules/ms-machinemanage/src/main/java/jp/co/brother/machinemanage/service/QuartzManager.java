package jp.co.brother.machinemanage.service;

import java.util.Objects;

import javax.annotation.PostConstruct;

import org.quartz.CronScheduleBuilder;
import org.quartz.CronTrigger;
import org.quartz.JobBuilder;
import org.quartz.JobDataMap;
import org.quartz.JobDetail;
import org.quartz.JobKey;
import org.quartz.Scheduler;
import org.quartz.SchedulerException;
import org.quartz.TriggerBuilder;
import org.quartz.impl.StdSchedulerFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.alibaba.fastjson.JSONObject;

import jp.co.brother.machinemanage.quartz.CheckHeartBeatJob;
import jp.co.brother.machinemanage.quartz.CheckMachineLockExpiredJob;
import jp.co.brother.machinemanage.quartz.DesignRelevantJob;
import jp.co.brother.machinemanage.quartz.DeviceRelevantJob;
import jp.co.brother.machinemanage.quartz.MachineRelevantJob;
import jp.co.brother.machinemanage.quartz.ModelRelevantJob;
import jp.co.brother.machinemanage.quartz.ProfileRelevantJob;

@Component
public class QuartzManager {
    @Autowired
    private Scheduler scheduler;

    private JobDetail updateDesignRelevantDataJob = null;
    private JobDetail updateDeviceRelevantDataJob = null;
    private JobDetail updateMachineRelevantDataJob = null;
    private JobDetail updateModelRelevantDataJob = null;
    private JobDetail updateProfileRelevantDataJob = null;

    private static final Logger logger = LoggerFactory.getLogger(QuartzManager.class);

    public QuartzManager() throws SchedulerException {
        scheduler = StdSchedulerFactory.getDefaultScheduler();
    }

    @PostConstruct
    private void init() {
        try {
            logger.info("Initialize all quartz jobs...");

            /* Every 30 second */
            String cronExpression1 = "*/30 * * * * ?";
            /* Every 10 second */
            String cronExpression2 = "0/10 * * * * ? ";
            /****************************/
            /* Initialize scheduled job */
            /****************************/
            /* Create a new job */
            JobDetail scheduledJob1 = JobBuilder.newJob(CheckHeartBeatJob.class).withIdentity("checkHeartBeatJob", "scheduled")
                    .withDescription("Current job is automatically triggered").build();
            /* Create a trigger */
            CronTrigger trigger1 = TriggerBuilder.newTrigger().withIdentity("checkHeartBeatJob", "scheduled")
                    .withSchedule(CronScheduleBuilder.cronSchedule(cronExpression1)).build();
            /* Associate the trigger & the job */
            scheduler.scheduleJob(scheduledJob1, trigger1);

            /* Create a new job */
            JobDetail scheduledJob2 = JobBuilder.newJob(CheckMachineLockExpiredJob.class).withIdentity("checkMachineLockExpiredJob", "scheduled")
                    .withDescription("Current job is automatically triggered").build();
            /* Create a trigger */
            CronTrigger trigger2 = TriggerBuilder.newTrigger().withIdentity("checkMachineLockExpiredJob", "scheduled")
                    .withSchedule(CronScheduleBuilder.cronSchedule(cronExpression2)).build();
            /* Associate the trigger & the job */
            scheduler.scheduleJob(scheduledJob2, trigger2);

            /***************************/
            /* Initialize Run-Once job */
            /***************************/
            /* Create a new job */
            updateDesignRelevantDataJob = JobBuilder.newJob(DesignRelevantJob.class).storeDurably(true)
                    .withIdentity("updateDesignRelevantData", "runOnce")
                    .withDescription("Current job is manually triggered").build();
            /* Save the job */
            scheduler.addJob(updateDesignRelevantDataJob, true);

            /* Create a new job */
            updateDeviceRelevantDataJob = JobBuilder.newJob(DeviceRelevantJob.class).storeDurably(true)
                    .withIdentity("updateDeviceRelevantData", "runOnce")
                    .withDescription("Current job is manually triggered").build();
            /* Save the job */
            scheduler.addJob(updateDeviceRelevantDataJob, true);

            /* Create a new job */
            updateMachineRelevantDataJob = JobBuilder.newJob(MachineRelevantJob.class).storeDurably(true)
                    .withIdentity("updateMachineRelevantData", "runOnce")
                    .withDescription("Current job is manually triggered").build();
            /* Save the job */
            scheduler.addJob(updateMachineRelevantDataJob, true);

            /* Create a new job */
            updateModelRelevantDataJob = JobBuilder.newJob(ModelRelevantJob.class).storeDurably(true)
                    .withIdentity("updateModelRelevantData", "runOnce")
                    .withDescription("Current job is manually triggered").build();
            /* Save the job */
            scheduler.addJob(updateModelRelevantDataJob, true);

            /* Create a new job */
            updateProfileRelevantDataJob = JobBuilder.newJob(ProfileRelevantJob.class).storeDurably(true)
                    .withIdentity("updateProfileRelevantData", "runOnce")
                    .withDescription("Current job is manually triggered").build();
            /* Save the job */
            scheduler.addJob(updateProfileRelevantDataJob, true);

            /* Starts the Scheduler's threads */
            if (!scheduler.isShutdown()) {
                scheduler.start();
            }
        } catch (Exception e) {
            logger.error("error occurred while initialize quartz job");
            e.printStackTrace();
        }
    }

    /**
     * Triggered when design data is changed.
     * 
     * @param designIds The ID of the design that changed
     */
    public void updateDesignRelevantData(String[] designIds) {
        try {
            logger.info("Start updateDesignRelevantData job");
            if (Objects.nonNull(updateDesignRelevantDataJob)) {
                /* Get job key */
                JobKey jobKey = updateDesignRelevantDataJob.getKey();
                /* Set parameter */
                JobDataMap jobDataMap = new JobDataMap();
                jobDataMap.put("designIds", JSONObject.toJSONString(designIds));
                /* Trigger the new job */
                scheduler.triggerJob(jobKey, jobDataMap);
            } else {
                logger.error("The jobKey is invalid");
            }
        } catch (Exception e) {
            logger.error("error occurred while start updateDesignRelevantData job");
            e.printStackTrace();
        }
    }

    /**
     * Triggered when device data is changed.
     * 
     * @param deviceIds The ID of the device that changed
     */
    public void updateDeviceRelevantData(String[] deviceIds) {
        try {
            logger.info("Start updateDeviceRelevantData job");
            if (Objects.nonNull(updateDeviceRelevantDataJob)) {
                /* Get job key */
                JobKey jobKey = updateDeviceRelevantDataJob.getKey();
                /* Set parameter */
                JobDataMap jobDataMap = new JobDataMap();
                jobDataMap.put("deviceIds", JSONObject.toJSONString(deviceIds));
                /* Trigger the new job */
                scheduler.triggerJob(jobKey, jobDataMap);
            } else {
                logger.error("The jobKey is invalid");
            }
        } catch (Exception e) {
            logger.error("error occurred while start updateDeviceRelevantData job");
            e.printStackTrace();
        }
    }

    /**
     * Triggered when machine data is changed.
     * 
     * @param machineIds The ID of the machine that changed
     */
    public void updateMachineRelevantData(String[] machineIds) {
        try {
            logger.info("Start updateMachineRelevantData job");
            if (Objects.nonNull(updateMachineRelevantDataJob)) {
                /* Get job key */
                JobKey jobKey = updateMachineRelevantDataJob.getKey();
                /* Set parameter */
                JobDataMap jobDataMap = new JobDataMap();
                jobDataMap.put("machineIds", JSONObject.toJSONString(machineIds));
                /* Trigger the new job */
                scheduler.triggerJob(jobKey, jobDataMap);
            } else {
                logger.error("The jobKey is invalid");
            }
        } catch (Exception e) {
            logger.error("error occurred while start updateMachineRelevantData job");
            e.printStackTrace();
        }
    }

    /**
     * Triggered when model data is changed.
     * 
     * @param modelIds The ID of the model that changed
     */
    public void updateModelRelevantData(String[] modelIds) {
        try {
            logger.info("Start updateModelRelevantData job");
            if (Objects.nonNull(updateModelRelevantDataJob)) {
                /* Get job key */
                JobKey jobKey = updateModelRelevantDataJob.getKey();
                /* Set parameter */
                JobDataMap jobDataMap = new JobDataMap();
                jobDataMap.put("modelIds", JSONObject.toJSONString(modelIds));
                /* Trigger the new job */
                scheduler.triggerJob(jobKey, jobDataMap);
            } else {
                logger.error("The jobKey is invalid");
            }
        } catch (Exception e) {
            logger.error("error occurred while start updateModelRelevantData job");
            e.printStackTrace();
        }
    }

    /**
     * Triggered when profile data is changed.
     * 
     * @param profileIds The ID of the profile that changed
     */
    public void updateProfileRelevantData(String[] profileIds) {
        try {
            logger.info("Start updateProfileRelevantData job");
            if (Objects.nonNull(updateProfileRelevantDataJob)) {
                /* Get job key */
                JobKey jobKey = updateProfileRelevantDataJob.getKey();
                /* Set parameter */
                JobDataMap jobDataMap = new JobDataMap();
                jobDataMap.put("profileIds", JSONObject.toJSONString(profileIds));
                /* Trigger the new job */
                scheduler.triggerJob(jobKey, jobDataMap);
            } else {
                logger.error("The jobKey is invalid");
            }
        } catch (Exception e) {
            logger.error("error occurred while start updateProfileRelevantData job");
            e.printStackTrace();
        }
    }
}