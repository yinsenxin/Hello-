package jp.co.brother.machinemanage.serviceImpl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Objects;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;
import org.springframework.util.Assert;

import jp.co.brother.machinemanage.constant.Constant;
import jp.co.brother.machinemanage.constant.ProfileType;
import jp.co.brother.machinemanage.domain.GroupDO;
import jp.co.brother.machinemanage.domain.GroupModelDO;
import jp.co.brother.machinemanage.domain.ProfileDO;
import jp.co.brother.machinemanage.exception.DataNotFoundException;
import jp.co.brother.machinemanage.pojo.GroupModelPojo;
import jp.co.brother.machinemanage.pojo.ProfilePojo;
import jp.co.brother.machinemanage.service.GroupModelService;
import jp.co.brother.machinemanage.utils.MongoDBUtils;
import jp.co.brother.machinemanage.vo.ResultVO;



@Component
public class GroupModelServiceImpl implements GroupModelService {

	private static final Logger logger = LoggerFactory.getLogger(GroupModelServiceImpl.class);
	@Autowired
    private MongoDBUtils<GroupModelDO> mongoDBUtils;
	@Autowired
	private MongoDBUtils<GroupDO> mongoDBUtil;
	

	/**
	 * Get all the GroupModel data
	 * @return
	 */
	@Override
	public ResultVO getGroupModelData(String groupModelId) {
		
		ResultVO result = new ResultVO(HttpStatus.OK);
		/*GroupModel is been use*/
		if (groupModelId != null) {
			/*Make search*/
			Query query = new Query();
			query.addCriteria(Criteria.where(Constant.DBQUERY_GROUPMODEL_ID).is(groupModelId));
			List<GroupDO> list = mongoDBUtil.find(query, GroupDO.class);
			if (!list.isEmpty()) {
				result.setMessage("Conflict");
			}
			result.setData(list);
			return result;
		} 
		List<GroupModelPojo> modelPojos = new ArrayList<>();
        /* Get data from mongoDB */
        List<GroupModelDO> groupModelDOs = mongoDBUtils.findAll(GroupModelDO.class);
        /* Convert to POJO */
        for (GroupModelDO groupModelDO : groupModelDOs) {
        	if (Objects.isNull(groupModelDO)) {
        		logger.warn("Invalid document");
        		continue;
        	}
			/* DO => POJO */
        	GroupModelPojo groupModelPojo = domainToPojo(groupModelDO);
        	modelPojos.add(groupModelPojo);
		}
        result.setData(modelPojos);
	
		return result;
	}
	
	/**
	 * Get the specified GroupModel data according the groupModelId
	 * @return
	 */
	@Override
	public ResultVO getGroupModelDataById(String groupModelId) {
		/* Check input parameter, make sure they are not null */
		Assert.notNull(groupModelId, Constant.ASSERT_GROUPMODEL_ID_MESSAGE);
		
		ResultVO result = new ResultVO(HttpStatus.OK);
		/*Make search criteria*/
		Query query = new Query();
		query.addCriteria(Criteria.where(Constant.DBQUERY_GROUPMODEL_ID).is(groupModelId));
		/*Search data*/
		GroupModelDO groupModelDO = mongoDBUtils.findOne(query, GroupModelDO.class);
		if (Objects.nonNull(groupModelDO)) {
			/*DO => POJO*/
			GroupModelPojo groupModelPojo = domainToPojo(groupModelDO);
			result.setData(groupModelPojo);
		} else {
			throw new DataNotFoundException("Target data not found!");
		}
		return result;
	}
	
	/**
	 * Add a groupModel data
	 * @param groupModelPojo
	 * @return
	 */
	@Override
	public ResultVO addGroupModelData(GroupModelPojo groupModelPojo) {
		/* Check input parameter, make sure they are not null */
		Assert.notNull(groupModelPojo, Constant.ASSERT_REQUEST_BODY);
        Assert.hasLength(groupModelPojo.getGroupModelId(), Constant.ASSERT_GROUPMODEL_MESSAGE);
        Assert.notNull(groupModelPojo.getProfileList(), Constant.ASSERT_GROUPMODEL_PROFILE);
        ResultVO resultVO = new ResultVO(HttpStatus.OK);
        /* Convert POJO to DO */
		GroupModelDO modelDO = PojoTodomain(groupModelPojo);
		/* Make search criteria */
		Query query = new Query();
		query.addCriteria(Criteria.where(Constant.DBQUERY_GROUPMODEL_ID).is(modelDO.getGroupModelId()));
		
		if (mongoDBUtils.exists(query, GroupModelDO.class)) {
			resultVO = new ResultVO(HttpStatus.CONFLICT);
			return resultVO;
		} else {
			mongoDBUtils.insert(modelDO);
		}
		
		return resultVO;
	}
	
	/**
	 * Delete the specified groupModel data according to the groupModelIds
	 * @param groupModelIds
	 * @return
	 */
	@Override
	public ResultVO deleteGroupModelData(String [] groupModelIds) {
		Assert.notEmpty(groupModelIds, Constant.ASSERT_GROUPMODEL_ID_MESSAGE);
		ResultVO result = new ResultVO(HttpStatus.OK);
		/*TODO: */
		for(String groupModelId : groupModelIds) {
			Query querys = new Query();
			querys.addCriteria(Criteria.where(Constant.DBQUERY_GROUPMODEL_ID).is(groupModelId));
			if (mongoDBUtil.exists(querys, GroupDO.class)) {
				return new ResultVO(HttpStatus.BAD_REQUEST);
			}
		}
		 
		/* Make search criteria */
		Query query = new Query();
		query.addCriteria(Criteria.where(Constant.DBQUERY_GROUPMODEL_ID).in((Object[]) groupModelIds));
		/*Delete data*/
		List<GroupModelDO> list = mongoDBUtils.findAllAndRemove(query, GroupModelDO.class);
		if (list.isEmpty()) 
			result.setData(false);
		
		result.setData(true);
		return result;
	}
	
	/**
	 * Modify the specified GroupModel data according the groupModelId and GroupModelPoJo
	 * @param groupModelId
	 * @param groupModelPojo
	 * @return
	 */
	@Override
	public ResultVO updateGroupModelData(String groupModelId, GroupModelPojo groupModelPojo){
		/* Check input parameter, make sure they are not null */
        Assert.notNull(groupModelId, Constant.ASSERT_GROUPMODEL_ID_MESSAGE);
        Assert.notNull(groupModelPojo, Constant.ASSERT_REQUEST_BODY);
        Assert.hasLength(groupModelPojo.getGroupModelId(), Constant.ASSERT_GROUPMODEL_MESSAGE);
        Assert.notNull(groupModelPojo.getProfileList(), Constant.ASSERT_GROUPMODEL_PROFILE);

        ResultVO result = new ResultVO(HttpStatus.OK);
        /*Make search criteria */
        Query query = new Query();
        query.addCriteria(Criteria.where(Constant.DBQUERY_GROUPMODEL_ID).is(groupModelId));
        Query querys = new Query();
        querys.addCriteria(Criteria.where(Constant.DBQUERY_GROUPMODEL_ID).is(groupModelId));
        if (mongoDBUtil.exists(querys, GroupDO.class)) {
        	return new ResultVO(HttpStatus.BAD_REQUEST);
        }
        /*Check if the target data exist*/
        if (mongoDBUtils.exists(query, GroupModelDO.class)) {
        	  if (!groupModelId.equals(groupModelPojo.getGroupModelId())) {
                  /* Check if the new groupModelId already exist */
                  Query query1 = new Query();
                  query1.addCriteria(Criteria.where(Constant.DBQUERY_GROUPMODEL_ID).is(groupModelPojo.getGroupModelId()));
                  if (mongoDBUtils.exists(query1, GroupModelDO.class)) {
                      throw new IllegalArgumentException("The \"groupModelId\" is exist!");
                  }
              }
        	  /* Convert POJO to DO */
        	  GroupModelDO modelDO = PojoTodomain(groupModelPojo);
        	  /* Replace old record */
        	  replaceOldRecord(groupModelId, modelDO);
        } else {
        	throw new DataNotFoundException("Target data is not found!");
        }
        
		return result;
	}
	

	
	/**
	 * GroupModel relevant data    
     * DO => POJO 
     * 
     * @param modelDO
     * @return
     * @throws IllegalArgumentException
     */
	private final GroupModelPojo domainToPojo(GroupModelDO modelDO) {
		List<ProfilePojo> list = new ArrayList<>();	
		GroupModelPojo modelPojo = new GroupModelPojo();
        modelPojo.setGroupModelId(modelDO.getGroupModelId());
        modelPojo.setDescription(modelDO.getDescription());
        modelPojo.setConditions(modelDO.getConditions());
        List<ProfileDO> profileList = modelDO.getProfileList();
        
        for (ProfileDO profileDO : profileList) {
			ProfilePojo profilePojo = domainToPojo(profileDO);
			list.add(profilePojo);
        	
		}
        
        modelPojo.setProfileList(list);
        return modelPojo;
    }
	/**
	 * GroupModel relevant data
	 * POJO => DO 
	 * 
	 * @param groupModelPojo
	 * @return
	 * @throws IllegalArgumentException
	 */
	private final GroupModelDO PojoTodomain(GroupModelPojo groupModelPojo) {
		GroupModelDO groupModelDO = new GroupModelDO();
		groupModelDO.setGroupModelId(groupModelPojo.getGroupModelId());
		groupModelDO.setConditions(groupModelPojo.getConditions() == null ? new HashMap<>() : groupModelPojo.getConditions());
		groupModelDO.setDescription(groupModelPojo.getDescription() == null ? "" : groupModelPojo.getDescription());
		List<ProfileDO> list = new ArrayList<>();
		List<ProfilePojo> profileList = groupModelPojo.getProfileList();
		for (ProfilePojo profilePojo : profileList) {
			ProfileDO profileDO = pojoToDomain(profilePojo);
			list.add(profileDO);
		}
		groupModelDO.setProfileList(groupModelPojo.getProfileList() == null ? new ArrayList<>() : list);
		return groupModelDO;
	}
	 /**
	 * Profile relevant data 
     * DO => POJO 
     * 
     * @param profileDO
     * @return
     * @throws IllegalArgumentException
     */
	private final ProfilePojo domainToPojo(ProfileDO profileDO) {
        ProfilePojo profilePojo = new ProfilePojo();
        profilePojo.setProfileId(profileDO.getProfileId());
        profilePojo.setProfileType(profileDO.getProfileType().getValue());
        profilePojo.setServices(profileDO.getServices());

        return profilePojo;
    }

    /**
     * Profile relevant data 
     * POJO => DO
     * 
     * @param profilePojo
     * @return
     * @throws IllegalArgumentException
     */
    private final ProfileDO pojoToDomain(ProfilePojo profilePojo) {
        /* Check if the profile type is legal */
        String profileType = profilePojo.getProfileType();
        if (profileType.equalsIgnoreCase(ProfileType.DEVICE_PROFILE.getValue())
                || profileType.equalsIgnoreCase(ProfileType.MODEL_PROFILE.getValue())) {
            ProfileDO profileDO = new ProfileDO();
            profileDO.setProfileId(profilePojo.getProfileId());
            profileDO.setProfileType(
                    profileType.equalsIgnoreCase(ProfileType.DEVICE_PROFILE.getValue()) ? ProfileType.DEVICE_PROFILE
                            : ProfileType.MODEL_PROFILE);
            profileDO.setServices(profilePojo.getServices());

            return profileDO;
        } else {
            /* Will response 400 error */
            throw new IllegalArgumentException("Illegal profileType. ProfileType should be \"device\" OR \"model\"!");
        }
    }
    
    /**
     * Replace the old data with the new data.(Which means the old data is exist)
     * @param groupModelId
     * @param groupModelDO
     */
    private void replaceOldRecord(String groupModelId, GroupModelDO groupModelDO) {
    	/*Make search criteria*/
    	Query query = new Query();
    	query.addCriteria(Criteria.where(Constant.DBQUERY_GROUPMODEL_ID).is(groupModelId));
    	
    	/*Make update*/
    	Update update = new Update();
    	update.set(Constant.DBQUERY_GROUPMODEL_ID, groupModelDO.getGroupModelId());
    	update.set(Constant.DBQUERY_GROUPMODEL_CONDITION, groupModelDO.getConditions());
    	update.set(Constant.DBQUERY_GROUPMODEL_DESCRIPTION, groupModelDO.getDescription());
    	update.set(Constant.DBQUERY_GROUPMODEL_PROFILE, groupModelDO.getProfileList());
    	/*Update data*/
    	mongoDBUtils.upsert(query, update, GroupModelDO.class);
    }
    
}










