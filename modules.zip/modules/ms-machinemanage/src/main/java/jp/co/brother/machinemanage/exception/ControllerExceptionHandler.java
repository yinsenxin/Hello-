package jp.co.brother.machinemanage.exception;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import jp.co.brother.machinemanage.vo.ResultVO;

@RestController
@ControllerAdvice
public class ControllerExceptionHandler {

    private final Logger logger = LoggerFactory.getLogger(this.getClass());

    @ExceptionHandler(value = IllegalArgumentException.class)
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    public ResultVO illegalArgumentException(HttpServletRequest req, IllegalArgumentException e) {
        logger.error("{} : {}", e.getClass().getName(), e.getMessage());
        ResultVO result = new ResultVO();
        result.setCode(HttpStatus.BAD_REQUEST.value());
        result.setMessage(e.getMessage());
        return result;
    }

    @ExceptionHandler(value = MethodArgumentNotValidException.class)
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    public ResultVO argumentNotValidExceptionHandler(HttpServletRequest req, MethodArgumentNotValidException e) {
        logger.error("{} : {}", e.getClass().getName(), e.getMessage());
        e.printStackTrace();
        ResultVO result = new ResultVO();
        result.setCode(HttpStatus.BAD_REQUEST.value());
        result.setMessage(e.getMessage());
        return result;
    }

    /**
     * In order to avoid FeignException, set the response status code to 200.
     * 
     * @param req
     * @param e
     * @return
     */
    @ExceptionHandler(value = DataIsLockedException.class)
    @ResponseStatus(HttpStatus.OK)
    public ResultVO dataIsLockedExceptionHandler(HttpServletRequest req, DataIsLockedException e) {
        logger.error("{} : {}", e.getClass().getName(), e.getMessage());
        ResultVO result = new ResultVO();
        result.setCode(HttpStatus.FORBIDDEN.value());
        result.setMessage(e.getMessage());
        return result;
    }

    /**
     * In order to avoid FeignException, set the response status code to 200.
     * 
     * @param req
     * @param e
     * @return
     */
    @ExceptionHandler(value = DataNotFoundException.class)
    @ResponseStatus(HttpStatus.OK)
    public ResultVO dataNotFoundExceptionHandler(HttpServletRequest req, DataNotFoundException e) {
        logger.error("{} : {}", e.getClass().getName(), e.getMessage());
        ResultVO result = new ResultVO();
        result.setCode(HttpStatus.NOT_FOUND.value());
        result.setMessage(e.getMessage());
        return result;
    }

    @ExceptionHandler(value = KeyAlreadyExistsException.class)
    @ResponseStatus(HttpStatus.FORBIDDEN)
    public ResultVO keyAlreadyExistsExceptionHandler(HttpServletRequest req, KeyAlreadyExistsException e) {
        logger.error("{} : {}", e.getClass().getName(), e.getMessage());
        e.printStackTrace();
        ResultVO result = new ResultVO();
        result.setCode(HttpStatus.FORBIDDEN.value());
        result.setMessage(e.getMessage());
        return result;
    }

    @ExceptionHandler(Exception.class)
    @ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR)
    public ResultVO othersExceptionHandler(HttpServletRequest req, Exception e) {
        logger.error("{} : {}", e.getClass().getName(), e.getMessage());
        e.printStackTrace();
        ResultVO result = new ResultVO();
        result.setCode(HttpStatus.INTERNAL_SERVER_ERROR.value());
        result.setMessage(e.getMessage());
        return result;
    }
}
