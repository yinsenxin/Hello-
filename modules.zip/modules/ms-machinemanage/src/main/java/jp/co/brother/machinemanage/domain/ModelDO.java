package jp.co.brother.machinemanage.domain;

import java.util.List;
import java.util.Map;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import com.alibaba.fastjson.annotation.JSONField;

import lombok.Data;

@Data
@Document(collection = "Model")
public class ModelDO {

    @Id
    @JSONField(serialize = false)
    private String id;
    /**
     * The unique ID of the model data.
     */
    private String modelId;
    /**
     * The ID of the design image bound by the current model.
     */
    private String designId;
    /**
     * The ID of the profile setting bound by the current model.
     */
    private String profileId;
    /**
     * The screen information of the current model.
     * Example: {"valid": true, "width": 200, "height": 800}
     */
    private Object screenInfo;
    /**
     * The valid conditions of the current model.
     * Example: {"Tray": ["1", "2", "3", "4"], "WI-FI": ["on", "off"], "USB": ["on", "off"]}
     */
    private Map<String, List<Object>> conditions;
    /**
     * The firmware list of the current model
     */
    private Map<String, ModelFirmwareDO> firmwares;
    /**
     * The description of the current model.
     */
    private String description;
}
