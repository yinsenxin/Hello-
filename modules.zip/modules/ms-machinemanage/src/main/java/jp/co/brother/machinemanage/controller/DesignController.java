package jp.co.brother.machinemanage.controller;

import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import jp.co.brother.machinemanage.pojo.DesignPojo;
import jp.co.brother.machinemanage.service.DesignManager;
import jp.co.brother.machinemanage.vo.ResultVO;

@RestController
@RequestMapping("/design")
public class DesignController {

    @Autowired
    private HttpServletResponse response;
    @Autowired
    private DesignManager designManager;

    /**
     * Get all design data with no condition.
     * 
     * @return
     */
    @GetMapping(value = "/designInfo", produces = "application/json;charset=UTF-8")
    public ResultVO getDesignInfo() {
        return designManager.getDesignData();
    }

    /**
     * Get the design data of the specified design.
     * 
     * @param designId ID of the specified design
     * @return
     */
    @GetMapping(value = "/designInfo/{designId}", produces = "application/json;charset=UTF-8")
    public ResultVO getDesignInfoById(@PathVariable(name = "designId", required = true) String designId) {
        return designManager.getDesignData(designId);
    }

    /**
     * Add a new design record.
     * 
     * @param designData design data
     * @return
     */
    @PutMapping(value = "/add", produces = "application/json;charset=UTF-8")
    public ResultVO addDesignInfo(@RequestBody DesignPojo designData) {
        return designManager.addDesignData(designData);
    }

    /**
     * Update the specified design record with the given design data.
     * 
     * @param designId   ID of the specified design
     * @param designData design data
     * @return
     */
    @PutMapping(value = "/update/{designId}", produces = "application/json;charset=UTF-8")
    public ResultVO updateDesignInfo(@PathVariable(name = "designId", required = true) String designId,
            @RequestBody(required = true) DesignPojo designData) {
        return designManager.updateDesignData(designId, designData);
    }

    /**
     * Delete the specified design record with the given designIds.
     * 
     * @param designIds ID of the specified designs
     * @return
     */
    @DeleteMapping(value = "/delete", produces = "application/json;charset=UTF-8")
    public ResultVO deleteDesignInfo(@RequestParam(name = "designIds", required = true) String[] designIds) {
        return designManager.deleteDesignData(designIds);
    }

    /**
     * Download the design data of the specified designs.
     * 
     * @param designIds ID of the specified designs
     * @return
     */
    @GetMapping(value = "/export")
    public ResultVO exportDesignInfo(@RequestParam(name = "designIds", required = true) String[] designIds) {
        return designManager.exportDesignData(response, designIds);
    }

    /**
     * Import design data.
     * 
     * @param file design data
     * @return
     */
    @PostMapping(value = "/import", consumes = "multipart/form-data")
    public ResultVO importDesignInfo(MultipartFile file) {
        return designManager.importDesignData(file);
    }

    /**
     * Get the design image path of the specified design.
     * 
     * @param designId ID of the specified design
     * @return
     */
    @GetMapping(value = "/image/uri", produces = "application/json;charset=UTF-8")
    public ResultVO getDesignImageURI(@RequestParam(name = "designId", required = true) String designId) {
        return designManager.getDesignImageURI(designId);
    }

    /**
     * Get all designs that meet the specified condition
     * 
     * @param designIds ID of the target designs
     * @param datas     The field that needs to be returned
     * @return
     */
    @GetMapping(value = "/query", produces = "application/json;charset=UTF-8")
    public ResultVO queryDesignInfo(@RequestParam(name = "designIds", required = false) String[] designIds,
            @RequestParam(name = "datas", required = false) String[] datas) {
        return designManager.queryDesignData(designIds, datas);
    }
}
