package jp.co.brother.machinemanage.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import jp.co.brother.machinemanage.pojo.DevicePojo;
import jp.co.brother.machinemanage.service.DeviceManager;
import jp.co.brother.machinemanage.vo.ResultVO;

@RestController
@RequestMapping("/device")
public class DeviceController {

    @Autowired
    private DeviceManager deviceManager;

    /**
     * Get all device data with no condition.
     * 
     * @return
     */
    @GetMapping(value = "/status", produces = "application/json;charset=UTF-8")
    public ResultVO getDeviceStatus(@RequestParam(name = "deviceIds", required = false) String[] deviceIds) {
        return deviceManager.getDeviceStatus(deviceIds);
    }

    /**
     * Get all device data with no condition.
     * 
     * @return
     */
    @GetMapping(value = "/deviceInfo", produces = "application/json;charset=UTF-8")
    public ResultVO getDeviceInfo() {
        return deviceManager.getDeviceData();
    }

    /**
     * Get the device data of the specified device.
     * 
     * @param deviceId ID of the specified device
     * @return
     */
    @GetMapping(value = "/deviceInfo/{deviceId}", produces = "application/json;charset=UTF-8")
    public ResultVO getDeviceInfoById(@PathVariable(name = "deviceId", required = true) String deviceId) {
        return deviceManager.getDeviceData(deviceId);
    }

    /**
     * Add a new device record.
     * 
     * @param deviceData device data
     * @return
     */
    @PutMapping(value = "/registration", produces = "application/json;charset=UTF-8")
    public ResultVO addDeviceInfo(@RequestBody DevicePojo deviceData) {
        return deviceManager.addDeviceData(deviceData);
    }

    /**
     * Delete the specified device record with the given deviceIds.
     * 
     * @param deviceIds ID of the specified devices
     * @return
     */
    @DeleteMapping(value = "/deregistration", produces = "application/json;charset=UTF-8")
    public ResultVO deleteDeviceInfo(@RequestParam(name = "deviceIds", required = true) String[] deviceIds) {
        return deviceManager.deleteDeviceData(deviceIds);
    }

    /**
     * Get all devices that meet the specified condition
     * 
     * @param deviceIds       ID of the target devices
     * @param deviceCategorys Category of the target devices
     * @param datas           The field that needs to be returned
     * @return
     */
    @GetMapping(value = "/query", produces = "application/json;charset=UTF-8")
    public ResultVO queryDeviceInfo(@RequestParam(name = "deviceIds", required = false) String[] deviceIds,
            @RequestParam(name = "deviceCategorys", required = false) String[] deviceCategorys,
            @RequestParam(name = "datas", required = false) String[] datas) {
        return deviceManager.queryDeviceData(deviceIds, deviceCategorys, datas);
    }
}
