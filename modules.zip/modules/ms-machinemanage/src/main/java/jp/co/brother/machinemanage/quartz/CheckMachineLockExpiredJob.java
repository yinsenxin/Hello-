package jp.co.brother.machinemanage.quartz;

import java.util.Map;
import java.util.Objects;

import org.joda.time.DateTime;
import org.quartz.DisallowConcurrentExecution;
import org.quartz.Job;
import org.quartz.JobExecutionContext;
import org.quartz.PersistJobDataAfterExecution;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import jp.co.brother.machinemanage.service.MachineManager;
import jp.co.brother.machinemanage.utils.RedisUtils;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Component
@DisallowConcurrentExecution
@PersistJobDataAfterExecution
public class CheckMachineLockExpiredJob implements Job {

    @Autowired
    private RedisUtils redisUtils;
    @Autowired
    private MachineManager machineManager;
    /* Effective time for a single lock operation: 10min */
    private int lockInfoExpiredTime = 10 * 60;

    public CheckMachineLockExpiredJob() {
    }

    @Override
    public void execute(JobExecutionContext context) {
        try {
            Map<String, DateTime> lockInfos = redisUtils.getAllMachineLockInfo();
            for (String machineId : lockInfos.keySet()) {
                DateTime dt = lockInfos.get(machineId);
                if (Objects.nonNull(dt) && dt.plusSeconds(lockInfoExpiredTime).isBeforeNow()) {
                    log.info("Force unlock expired machine lock record by schedule job. machineId: {}", machineId);
                    /* Lock info had expired, force unlock machine */
                    machineManager.forceUnlockMachineData(machineId);
                }
            }
        } catch (Exception e) {
            log.error("{} : {}", e.getClass().getName(), e.getMessage());
            e.printStackTrace();
        }
    }
}
