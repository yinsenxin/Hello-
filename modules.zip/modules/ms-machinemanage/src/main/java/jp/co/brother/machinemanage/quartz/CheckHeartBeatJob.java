package jp.co.brother.machinemanage.quartz;

import java.util.List;

import org.quartz.DisallowConcurrentExecution;
import org.quartz.Job;
import org.quartz.JobExecutionContext;
import org.quartz.PersistJobDataAfterExecution;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import jp.co.brother.machinemanage.service.DeviceManager;
import jp.co.brother.machinemanage.service.MachineManager;

@Component
@DisallowConcurrentExecution
@PersistJobDataAfterExecution
public class CheckHeartBeatJob implements Job {

    @Autowired
    private DeviceManager deviceManager;
    @Autowired
    private MachineManager machineManager;

    private static final Logger logger = LoggerFactory.getLogger(CheckHeartBeatJob.class);

    public CheckHeartBeatJob() {
    }

    @Override
    public void execute(JobExecutionContext context) {
        try {
            /* Check device heartbeat */
            List<String> deviceIds = deviceManager.updateDeviceStatus();
            /* Device status may have changed, update machine status */
            machineManager.updateMachineStatusByDeviceId(deviceIds.toArray(new String[0]));
        } catch (Exception e) {
            logger.error("{} : {}", e.getClass().getName(), e.getMessage());
            e.printStackTrace();
        }
    }
}