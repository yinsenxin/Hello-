package jp.co.brother.machinemanage.proxy;

import java.util.List;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestParam;

import jp.co.brother.machinemanage.vo.ResultVO;

@FeignClient(name = "ServiceRouter")
public interface ServiceRouter {

    @PutMapping(value = "/router/table/file")
    ResultVO doUpdateRouterFile(@RequestParam("modelIds") List<String> modelIDs);

    @PutMapping(value = "/router/table/service")
    ResultVO doUpdateRouterService(@RequestParam("machineIds") List<String> machineIDs);
}
