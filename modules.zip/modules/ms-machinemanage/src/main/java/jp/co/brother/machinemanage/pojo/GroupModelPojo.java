package jp.co.brother.machinemanage.pojo;

import java.util.List;
import java.util.Map;

import lombok.Data;

@Data
public class GroupModelPojo {
	/**
	 * The unique ID of the groupModel data.
	 */
	private String groupModelId;
	/**
	 * The ID of the Profile data;
	 */
	private List<ProfilePojo> profileList;
	/**
	 * This is a conditions;
	 */
	private Map<String, List<String>> conditions;
	/**
	 * This is a description
	 */
	private String description;
}
