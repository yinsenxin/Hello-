package jp.co.brother.machinemanage.pojo;

import java.util.List;
import java.util.Map;

import lombok.Data;

@Data
public class MachinePojo {

    /**
     * The unique ID of the machine data.
     */
    private String machineId;
    /**
     * The ID of the model to which the current machine belongs.
     */
    private String modelId;
    /**
     * The conditions of the current machine.
     */
    private Map<String, Object> conditions;
    /**
     * The devices bound by the current machine.
     */
    private List<String> bindDevices;
    /**
     * The description of the current machine.
     */
    private String description;
    /**
     * The strategy of how to update the machine firmware.
     */
    private String updateStrategy;
    /**
     * The specified firmware version.
     * (This item is valid if and only if the update strategy is "manual")
     */
    private String firmware;
    /**
     * The ID of the user who is currently using the machine.
     */
    private String userId;
}
