package jp.co.brother.machinemanage.controller;

import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import jp.co.brother.machinemanage.pojo.MachinePojo;
import jp.co.brother.machinemanage.service.MachineManager;
import jp.co.brother.machinemanage.vo.ResultVO;

@RestController
@RequestMapping("/machine")
public class MachineController {

    @Autowired
    private HttpServletResponse response;
    @Autowired
    private MachineManager machineManager;

    /**
     * Get the status data of the specified machines.
     * 
     * @param machineIds ID of the specified machines
     * @return
     */
    @GetMapping(value = "/status", produces = "application/json;charset=UTF-8")
    public ResultVO getMachineStatus(@RequestParam(name = "machineIds", required = false) String[] machineIds) {
        return machineManager.getMachineStatus(machineIds);
    }

    /**
     * Get the machines with specified conditions.
     * 
     * @param modelId
     * @param condition
     * @return
     */
    @RequestMapping(value = "/matching", method = RequestMethod.GET)
    public ResultVO matchingMachine(@RequestParam(name = "modelId", required = true) String modelId,
            @RequestParam(name = "condition", required = true) String condition) {
        return machineManager.matchingMachine(modelId, condition);
    }

    /**
     * Get all machine data with no condition.
     * 
     * @return
     */
    @GetMapping(value = "/machineInfo", produces = "application/json;charset=UTF-8")
    public ResultVO getMachineInfo() {
        return machineManager.getMachineData();
    }

    /**
     * Get the machine data of the specified machine.
     * 
     * @param machineId ID of the specified machine
     * @return
     */
    @GetMapping(value = "/machineInfo/{machineId}", produces = "application/json;charset=UTF-8")
    public ResultVO getMachineInfoById(@PathVariable(name = "machineId", required = true) String machineId) {
        return machineManager.getMachineData(machineId);
    }

    /**
     * Add a new machine record.
     * 
     * @param machineData machine data
     * @return
     */
    @PutMapping(value = "/add", produces = "application/json;charset=UTF-8")
    public ResultVO addMachineInfo(@RequestBody MachinePojo machineData) {
        return machineManager.addMachineData(machineData);
    }

    /**
     * Update the specified machine record with the given machine data.
     * 
     * @param machineId   ID of the specified machine
     * @param machineData machine data
     * @return
     */
    @PutMapping(value = "/update/{machineId}", produces = "application/json;charset=UTF-8")
    public ResultVO updateMachineInfo(@PathVariable(name = "machineId", required = true) String machineId,
            @RequestBody(required = true) MachinePojo machineData) {
        return machineManager.updateMachineData(machineId, machineData);
    }

    /**
     * Lock the specified machine record with the specified userId.
     * 
     * @param userId     The ID of the user who wants to lock the machine.
     * @param machineIds target machines
     * @return
     */
    @PostMapping(value = "/lock", produces = "application/json;charset=UTF-8")
    public ResultVO lockMachineInfo(@RequestParam(name = "userId", required = true) String userId,
            @RequestParam(name = "machineIds", required = true) String[] machineIds) {
        return machineManager.lockMachineData(userId, machineIds);
    }

    /**
     * Unlock the machine locked by the specified user.
     * 
     * @param userId     The ID of the user who locked the machine
     * @param machineIds target machines
     * @return
     */
    @PostMapping(value = "/unlock", produces = "application/json;charset=UTF-8")
    public ResultVO unlockMachineInfo(@RequestParam(name = "userId", required = true) String userId,
            @RequestParam(name = "machineIds", required = true) String[] machineIds) {
        return machineManager.unlockMachineData(userId, machineIds);
    }

    /**
     * Unlock the specified machine.
     * 
     * @param machineId target machine
     * @return
     */
    @PostMapping(value = "/forceunlock", produces = "application/json;charset=UTF-8")
    public ResultVO forceUnlockMachineInfo(@RequestParam(name = "machineId", required = true) String machineId) {
        return machineManager.forceUnlockMachineData(machineId);
    }

    /**
     * Delete the specified machine record with the given machineIds.
     * 
     * @param machineIds ID of the specified machines
     * @return
     */
    @DeleteMapping(value = "/delete", produces = "application/json;charset=UTF-8")
    public ResultVO deleteMachineInfo(@RequestParam(name = "machineIds", required = true) String[] machineIds) {
        return machineManager.deleteMachineData(machineIds);
    }

    /**
     * Download the machine data of the specified machines.
     * 
     * @param machineIds ID of the specified machines
     * @return
     */
    @GetMapping(value = "/export")
    public ResultVO exportMachineInfo(@RequestParam(name = "machineIds", required = true) String[] machineIds) {
        return machineManager.exportMachineData(response, machineIds);
    }

    /**
     * Import machine data.
     * 
     * @param file machine data
     * @return
     */
    @PostMapping(value = "/import", consumes = "multipart/form-data")
    public ResultVO importMachineInfo(MultipartFile file) {
        return machineManager.importMachineData(file);
    }

    /**
     * Get all machines that meet the specified condition
     * 
     * @param machineIds ID of the target machines
     * @param modelIds   ModelId of the target machines
     * @param userIds    UserId of the target machines
     * @param datas      The field that needs to be returned
     * @return
     */
    @GetMapping(value = "/query", produces = "application/json;charset=UTF-8")
    public ResultVO queryMachineInfo(@RequestParam(name = "machineIds", required = false) String[] machineIds,
            @RequestParam(name = "modelIds", required = false) String[] modelIds,
            @RequestParam(name = "userIds", required = false) String[] userIds,
            @RequestParam(name = "datas", required = false) String[] datas) {
        return machineManager.queryMachineData(machineIds, modelIds, userIds, datas);
    }

    /**
     * Get all machines that keyword-executable
     * @param uri keyword file uri  - Keyword\MFC\EC
     * @return ResultVO
     */
    @GetMapping(value = "/fuzzyQuery",produces = "application/json;charset=UTF-8")
    public ResultVO fuzzyQueryMachineInfo(@RequestParam(name = "uri") String uri){
        return machineManager.fuzzyQueryMachineInfo(uri);
    }

    /**
     * Check if the firmware version of the machine needs to be updated.
     * 
     * @param machineId ID of the target machine
     * @param firmware  The current firmware version of the specified machine
     * @return
     */
    @GetMapping(value = "/firmware/update", produces = "application/json;charset=UTF-8")
    public ResultVO checkFirmwareUpdate(@RequestParam(name = "machineId", required = true) String machineId,
            @RequestParam(name = "firmware", required = true) String firmware) {
        return machineManager.checkFirmwareUpdate(machineId, firmware);
    }
}
