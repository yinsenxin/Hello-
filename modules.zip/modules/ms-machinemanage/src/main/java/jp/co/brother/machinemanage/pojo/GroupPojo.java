package jp.co.brother.machinemanage.pojo;

import java.util.List;
import java.util.Map;

import jp.co.brother.machinemanage.domain.Subordinate;
import lombok.Data;

@Data
public class GroupPojo {
	/**
	 * The unique ID of the group data.
	 */
	private String groupId;
	/**
	 * The ID of the groupModel data;
	 */
	private String groupModelId;
	/**
	 * The list of the Subordinate data;
	 */
	private List<Subordinate> subordinateList;
	/**
	 * This is a conditions;
	 */
	private Map<String, Object> conditions;
	/**
	 * This is a description
	 */
	private String description;
}
