package jp.co.brother.machinemanage.vo;

import org.springframework.web.multipart.MultipartFile;

import lombok.Data;

@Data
public class UploadedFirmwareVO {

    private MultipartFile file;
    private String name;
    private String version;
    private String description;
}
