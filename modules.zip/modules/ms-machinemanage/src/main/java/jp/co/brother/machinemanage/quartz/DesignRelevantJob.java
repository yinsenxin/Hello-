package jp.co.brother.machinemanage.quartz;

import org.quartz.DisallowConcurrentExecution;
import org.quartz.Job;
import org.quartz.JobDataMap;
import org.quartz.JobExecutionContext;
import org.quartz.PersistJobDataAfterExecution;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;

import jp.co.brother.machinemanage.service.MachineManager;
import jp.co.brother.machinemanage.service.ModelManager;

@Component
@DisallowConcurrentExecution
@PersistJobDataAfterExecution
public class DesignRelevantJob implements Job {

    @Autowired
    private ModelManager modelManager;
    @Autowired
    private MachineManager machineManager;

    private static final Logger logger = LoggerFactory.getLogger(DesignRelevantJob.class);

    public DesignRelevantJob() {
    }

    @Override
    public void execute(JobExecutionContext context) {
        try {
            JobDataMap jobDataMap = context.getTrigger().getJobDataMap();
            JSONArray designIds = JSONObject.parseArray(jobDataMap.getString("designIds"));
            logger.info("Some designs have changed, update the relevant data. designIds: {}", designIds);

            /* Maintain model data */
            modelManager.updateModelStatusByDesignId(designIds.toArray(new String[0]));
            /* Maintain machine Data */
            machineManager.updateMachineStatusByDesignId(designIds.toArray(new String[0]));
        } catch (Exception e) {
            logger.error("{} : {}", e.getClass().getName(), e.getMessage());
            e.printStackTrace();
        }
    }
}