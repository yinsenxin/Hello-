package jp.co.brother.machinemanage.exception;

public class DataNotFoundException extends RuntimeException { // 自定义的类
    /**
     * Automatic generated
     */
    private static final long serialVersionUID = -5511416099620268758L;

    public DataNotFoundException(String s) {
        super(s);
    }
}