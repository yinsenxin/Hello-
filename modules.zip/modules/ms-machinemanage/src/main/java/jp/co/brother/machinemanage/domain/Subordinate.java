package jp.co.brother.machinemanage.domain;

import lombok.Data;

@Data
public class Subordinate {
	/**
	 * This is a profile`id 
	 */
	private String profileId;
	/**
	 * This is a group Subordinate name
	 */
	private String name;
	/**
	 * This is machine`id
	 */
	private String machineId;
}
