package jp.co.brother.machinemanage.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import jp.co.brother.machinemanage.pojo.GroupModelPojo;
import jp.co.brother.machinemanage.service.GroupModelService;
import jp.co.brother.machinemanage.vo.ResultVO;



@RestController
@RequestMapping("/groupModels")
public class GroupModelController {
    @Autowired
    private GroupModelService groupModelService;
    
    /**
     * Get all groupModel data 
     * @return
     */
    @GetMapping(value = "", produces = "application/json;charset=UTF-8")
    public ResultVO getGroupModelInfo(@RequestParam(name = "groupModelId", required = false) String groupModelId) {
        return groupModelService.getGroupModelData(groupModelId);
    }
    
    /**
     * Get the specified GroupModel data according the groupModelId
     * @param groupModelId
     * @return
     */
    @GetMapping(value = "/{groupModelId}", produces = "application/json;charset=UTF-8")
    public ResultVO getGroupModelInfoById(@PathVariable(name = "groupModelId", required = true) String groupModelId) {
    	return groupModelService.getGroupModelDataById(groupModelId);
    }
    
    /**
     *  Add a GroupModel data
     * @param groupModelPojo
     * @return
     */
    @PostMapping(value = "", produces = "application/json;charset=UTF-8")
    public ResultVO addGroupModel(@RequestBody GroupModelPojo groupModelPojo) {
    	return groupModelService.addGroupModelData(groupModelPojo);
    }
    
    /**
     * Delete the specified groupModel data according to the groupModelIds
     * @param groupModelIds
     * @return
     */
    @DeleteMapping(value = "/{groupModelId}", produces = "application/json;charset=UTF-8")
    public ResultVO deleteGroupModel(@PathVariable(name = "groupModelId", required = true)String [] groupModelId) {
    	return groupModelService.deleteGroupModelData(groupModelId);
    }
    
    /**
     * Modify the specified GroupModel data according the groupModelId and GroupModelPoJo
     * @param groupModelId
     * @param groupModelPojo
     * @return
     */
    @PutMapping(value = "/{groupModelId}", produces = "application/json;charset=UTF-8")
    public ResultVO updateGroupModel(@PathVariable(name = "groupModelId", required = true) String groupModelId, 
    		@RequestBody(required = true) GroupModelPojo groupModelPojo) {
    	return groupModelService.updateGroupModelData(groupModelId, groupModelPojo);
    }
    
}
