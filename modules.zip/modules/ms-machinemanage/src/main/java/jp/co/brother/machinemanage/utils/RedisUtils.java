package jp.co.brother.machinemanage.utils;

import java.util.HashMap;
import java.util.Map;
import java.util.Objects;
import java.util.Set;

import org.apache.commons.lang.StringUtils;
import org.joda.time.DateTime;
import org.joda.time.format.DateTimeFormat;
import org.joda.time.format.DateTimeFormatter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.stereotype.Component;

import jp.co.brother.machinemanage.constant.Constant;

@Component
public class RedisUtils {

    @Autowired
    private StringRedisTemplate stringRedisTemplate;
    private static final DateTimeFormatter formatter = DateTimeFormat.forPattern(Constant.DATEFMT_UPDATE_TIME);

    public void upsertMachineLockInfo(String machineId, DateTime time) {
        if (StringUtils.isNotBlank(machineId) && Objects.nonNull(time)) {
            stringRedisTemplate.opsForHash().put(Constant.REDIS_KEY_MACHINELOCKTIME, machineId, time.toString(formatter));
        }
    }

    public Map<String, DateTime> getAllMachineLockInfo() {
        Map<String, DateTime> data = new HashMap<>();
        Set<Object> hashKeys = stringRedisTemplate.opsForHash().keys(Constant.REDIS_KEY_MACHINELOCKTIME);
        for (Object hashKey : hashKeys) {
            Object date = stringRedisTemplate.opsForHash().get(Constant.REDIS_KEY_MACHINELOCKTIME, hashKey);
            data.put(hashKey.toString(), DateTime.parse(date.toString(), formatter));
        }
        return data;
    }

    public void removeMachineLockInfo(Object... machineId) {
        stringRedisTemplate.opsForHash().delete(Constant.REDIS_KEY_MACHINELOCKTIME, machineId);
    }
}
