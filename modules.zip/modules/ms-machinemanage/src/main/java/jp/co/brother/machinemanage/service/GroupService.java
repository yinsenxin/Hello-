package jp.co.brother.machinemanage.service;

import jp.co.brother.machinemanage.pojo.GroupPojo;
import jp.co.brother.machinemanage.vo.ResultVO;

public interface GroupService {
	
	/**
	 * Get all the Group data
	 * @return
	 */
	ResultVO getGroupData(String [] groupModelId);
	
	/**
	 * Get the specified Group data according the groupId
	 * @param groupId
	 * @return
	 */
	ResultVO getGroupDataById(String groupId);
	
	/**
	 * Add a group data
	 * @param groupPojo
	 * @return
	 */
	ResultVO addGroupData(GroupPojo groupPojo);
	
	/**
	 * Modify the specified Group data according the groupId and GroupPoJo
	 * @param groupId
	 * @param groupPojo
	 * @return
	 */
	ResultVO updateGroupData(String groupId, GroupPojo groupPojo);
	
	/**
	 * Delete the specified group data according to the groupIds
	 * @param groupIds
	 * @return
	 */
	ResultVO deleteGroupData(String [] groupIds);
	
	/**
	 * Get Group status 
	 * @param groupId
	 * @return
	 */
	ResultVO getGroupStatus(String [] groupIds);
	
}
