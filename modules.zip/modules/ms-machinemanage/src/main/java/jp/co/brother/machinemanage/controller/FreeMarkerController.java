package jp.co.brother.machinemanage.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@Controller
public class FreeMarkerController {

    @RequestMapping(value = "/design", method = RequestMethod.GET)
    public String getDesign() {
        return "design";
    }

    @RequestMapping(value = "/device", method = RequestMethod.GET)
    public String getDevice() {
        return "device";
    }

    @RequestMapping(value = "/machine", method = RequestMethod.GET)
    public String getMachine() {
        return "machine";
    }

    @RequestMapping(value = "/model", method = RequestMethod.GET)
    public String getModel() {
        return "model";
    }

    @RequestMapping(value = "/profile", method = RequestMethod.GET)
    public String getProfile() {
        return "profile";
    }
    
    @RequestMapping(value = "/group", method = RequestMethod.GET)
    public String getGroup() {
    	return "group";
    }
    
    @RequestMapping(value = "/groupModel", method = RequestMethod.GET)
    public String getGroupModel() {
    	return "groupModel";
    }
}
