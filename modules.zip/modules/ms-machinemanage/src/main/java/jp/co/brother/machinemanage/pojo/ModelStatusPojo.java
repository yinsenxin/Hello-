package jp.co.brother.machinemanage.pojo;

import lombok.Data;

@Data
public class ModelStatusPojo {

    private boolean healthy;
    private String reason;
    private DesignStatusPojo designStatus;
    private ProfileStatusPojo profileStatus;

    public ModelStatusPojo() {
        this.healthy = false;
        this.reason = "";
        this.designStatus = new DesignStatusPojo();
        this.profileStatus = new ProfileStatusPojo();
    }

    public ModelStatusPojo(boolean healthy, String reason) {
        this.healthy = healthy;
        this.reason = reason;
        this.designStatus = new DesignStatusPojo();
        this.profileStatus = new ProfileStatusPojo();
    }
}
