package jp.co.brother.machinemanage.pojo;

import java.util.List;
import java.util.Map;

import lombok.Data;

@Data
public class ModelPojo {

    /**
     * The unique ID of the model data.
     */
    private String modelId;
    /**
     * The ID of the design image bound by the current model.
     */
    private String designId;
    /**
     * The ID of the profile setting bound by the current model.
     */
    private String profileId;
    /**
     * The screen information of the current model.
     * Example: {"valid": true, "width": 200, "height": 800}
     */
    private Object screenInfo;
    /**
     * The valid conditions of the current model.
     * Example: {"Tray": ["1", "2", "3", "4"], "WI-FI": ["on", "off"], "USB": ["on", "off"]}
     */
    private Map<String, List<Object>> conditions;
    /**
     * The description of the current model.
     */
    private String description;
}
