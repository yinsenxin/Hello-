package jp.co.brother.machinemanage.service;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Objects;

import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang.StringUtils;
import org.joda.time.DateTime;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;
import org.springframework.util.Assert;
import org.springframework.web.multipart.MultipartFile;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;

import jp.co.brother.machinemanage.constant.Constant;
import jp.co.brother.machinemanage.constant.ProfileType;
import jp.co.brother.machinemanage.domain.ProfileDO;
import jp.co.brother.machinemanage.exception.DataNotFoundException;
import jp.co.brother.machinemanage.pojo.ProfilePojo;
import jp.co.brother.machinemanage.utils.MongoDBUtils;
import jp.co.brother.machinemanage.vo.ResultVO;

@Component
public class ProfileManager {

    @Autowired
    private MongoDBUtils<ProfileDO> mongoDBUtils;
    @Autowired
    private QuartzManager quartzManager;

    private static final Logger logger = LoggerFactory.getLogger(ProfileManager.class);

    /**
     * Get all profile data with no condition.
     * 
     * @return
     */
    public ResultVO getProfileData() {
        List<ProfilePojo> profilePojos = new ArrayList<>();
        /* Get data from mongoDB */
        List<ProfileDO> profileDOs = mongoDBUtils.findAll(ProfileDO.class);
        /* Convert to POJO */
        for (ProfileDO profileDO : profileDOs) {
            if (Objects.isNull(profileDO)) {
                logger.warn("Invalid document");
                continue;
            }
            /* DO => POJO */
            ProfilePojo profile = domainToPojo(profileDO);
            profilePojos.add(profile);
        }

        ResultVO result = new ResultVO(HttpStatus.OK);
        result.setData(profilePojos);
        return result;
    }

    /**
     * Get the profile data of the specified profile.
     * 
     * @param profileId ID of the specified profile
     * @return
     * @throws IllegalArgumentException
     */
    public ResultVO getProfileData(String profileId) {
        /* Check input parameter, make sure they are not null */
        Assert.notNull(profileId, "ProfileId must not be null!");

        ResultVO result = new ResultVO(HttpStatus.OK);
        /* Make search criteria */
        Query query = new Query();
        query.addCriteria(Criteria.where("profileId").is(profileId));
        /* Search data */
        ProfileDO profileDO = mongoDBUtils.findOne(query, ProfileDO.class);
        if (Objects.nonNull(profileDO)) {
            /* DO => POJO */
            ProfilePojo profile = domainToPojo(profileDO);
            result.setData(profile);
        } else {
            throw new DataNotFoundException("Target data not found!");
        }
        return result;
    }

    /**
     * Add a new profile record.
     * 
     * @param profileData profile data
     * @return
     * @throws IllegalArgumentException
     */
    public ResultVO addProfileData(ProfilePojo profileData) {
        /* Check input parameter, make sure they are not null */
        Assert.notNull(profileData, "Body of this request must not be null!");
        Assert.hasLength(profileData.getProfileId(), "\"profileId\" in the body must not be null or empty!");
        Assert.notNull(profileData.getProfileType(), "\"profileType\" in the body must not be null!");
        Assert.notNull(profileData.getServices(), "\"services\" in the body must not be null!");

        /* Convert POJO to DO */
        ProfileDO profileDO = pojoToDomain(profileData);

        /* Make search criteria */
        Query query = new Query();
        query.addCriteria(Criteria.where("profileId").is(profileDO.getProfileId()));
        /* Check if the target data exist */
        if (mongoDBUtils.exists(query, ProfileDO.class)) {
            /* Replace old record */
            replaceOldRecord(profileDO.getProfileId(), profileDO);
        } else {
            /* Save new data */
            mongoDBUtils.insert(profileDO);
        }

        /* Start a new thread to update the relevant data */
        quartzManager.updateProfileRelevantData(new String[] { profileData.getProfileId() });

        return new ResultVO(HttpStatus.OK);
    }

    /**
     * Update the specified profile record with the given profile data.
     * 
     * @param profileId   ID of the specified profile
     * @param profileData profile data
     * @return
     * @throws IllegalArgumentException
     */
    public ResultVO updateProfileData(String profileId, ProfilePojo profileData) {
        /* Check input parameter, make sure they are not null */
        Assert.notNull(profileId, "ProfileId must not be null!");
        Assert.notNull(profileData, "Body of this request must not be null!");
        Assert.hasLength(profileData.getProfileId(), "\"profileId\" in the body must not be null or empty!");
        Assert.notNull(profileData.getProfileType(), "\"profileType\" in the body must not be null!");
        Assert.notNull(profileData.getServices(), "\"services\" in the body must not be null!");

        ResultVO result = new ResultVO(HttpStatus.OK);
        /* Make search criteria */
        Query query = new Query();
        query.addCriteria(Criteria.where("profileId").is(profileId));
        /* Check if the target data exist */
        if (mongoDBUtils.exists(query, ProfileDO.class)) {
            if (!profileId.equals(profileData.getProfileId())) {
                /* Check if the new profileId already exist */
                Query query1 = new Query();
                query1.addCriteria(Criteria.where("profileId").is(profileData.getProfileId()));
                if (mongoDBUtils.exists(query1, ProfileDO.class)) {
                    throw new IllegalArgumentException("The \"profileId\" in the body has already been used!");
                }
            }

            /* Convert POJO to DO */
            ProfileDO profileDO = pojoToDomain(profileData);
            /* Replace old record */
            replaceOldRecord(profileId, profileDO);
            /* Start a new thread to update the relevant data */
            quartzManager.updateProfileRelevantData(new String[] { profileId, profileData.getProfileId() });

        } else {
            throw new DataNotFoundException("Target data not found!");
        }

        return result;
    }

    /**
     * Delete the specified profile record with the given profileIds.
     * 
     * @param profileIds ID of the specified profiles
     * @return
     * @throws IllegalArgumentException
     */
    public ResultVO deleteProfileData(String[] profileIds) {
        /* Check input parameter, make sure they are not null */
        Assert.notEmpty(profileIds, "ProfileIds must not be empty!");

        ResultVO result = new ResultVO(HttpStatus.OK);
        /* Make search criteria */
        Query query = new Query();
        query.addCriteria(Criteria.where("profileId").in((Object[]) profileIds));
        /* Delete data */
        List<ProfileDO> deletedDatas = new ArrayList<>();
        deletedDatas = mongoDBUtils.findAllAndRemove(query, ProfileDO.class);
        /* Analyze result */
        Map<String, Boolean> hMap = new HashMap<>();
        for (ProfileDO profileDO : deletedDatas) {
            if (Objects.isNull(profileDO)) {
                logger.warn("Invalid document");
                continue;
            }
            hMap.put(profileDO.getProfileId(), true);
        }
        for (String profileId : profileIds) {
            if (!hMap.containsKey(profileId)) {
                hMap.put(profileId, false);
            }
        }
        result.setData(hMap);

        /* Start a new thread to update the relevant data */
        quartzManager.updateProfileRelevantData(profileIds);

        return result;
    }

    /**
     * Download the profile data of the specified profiles.
     * 
     * @param response   response data of current HTTP request
     * @param profileIds ID of the specified profiles
     * @return
     */
    public ResultVO exportProfileData(HttpServletResponse response, String[] profileIds) {
        /* Get all profile data */
        List<ProfileDO> profileDOs = mongoDBUtils.findAll(ProfileDO.class);
        profileDOs.removeAll(Collections.singleton(null));

        /* Get target profile data */
        List<ProfileDO> targetDatas = new ArrayList<>();
        if (Objects.nonNull(profileIds) && profileIds.length > 0) {
            for (ProfileDO profileDO : profileDOs) {
                String profileId = profileDO.getProfileId();
                if (Arrays.asList(profileIds).contains(profileId)) {
                    targetDatas.add(profileDO);
                }
            }
        } else {
            targetDatas.addAll(profileDOs);
        }

        /***********************************************/
        /* Save the target profile data to a JSON file */
        /***********************************************/
        String zipFileName = "ProfileExport_" + DateTime.now().toString(Constant.DATEFMT_FILE_NAME) + ".json";
        try {
            /* Make directory & create JSON file */
            File dbFile = new File(zipFileName);
            dbFile.createNewFile();

            FileWriter dbFileWriter = new FileWriter(dbFile);
            dbFileWriter.write(JSONObject.toJSONString(targetDatas));
            dbFileWriter.flush();
            dbFileWriter.close();

            /* Make response */
            File zipFile = new File(zipFileName);
            if (zipFile.exists()) {
                InputStream fis = new BufferedInputStream(new FileInputStream(zipFile.getAbsolutePath()));
                byte[] buffer = new byte[fis.available()];
                fis.read(buffer);
                fis.close();

                response.reset();
                response.setHeader("Content-Disposition", "attachment;fileName=" + zipFileName);
                response.addHeader("Content-Length", "" + zipFile.length());
                OutputStream toClient = new BufferedOutputStream(response.getOutputStream());
                response.setContentType("application/octet-stream");
                toClient.write(buffer);
                toClient.flush();
                toClient.close();
            }
        } catch (Exception e) {
            logger.info("Error occurred while export profile data");
            logger.error("{}: {}", e.getClass().getName(), e.getMessage());
            e.printStackTrace();
        } finally {
            /* Delete local JSON file */
            File zipFile = new File(zipFileName);
            if (zipFile.exists()) {
                zipFile.delete();
            }
        }

        return null;
    }

    /**
     * Import profile data.
     * 
     * @param file profile data
     * @return
     */
    public ResultVO importProfileData(MultipartFile file) {
        ResultVO result = new ResultVO(HttpStatus.OK);
        JSONObject topContainer = new JSONObject();

        /* If the uploaded file is not empty */
        if (!file.isEmpty()) {
            /* ID of the profile data that was successfully imported */
            List<String> profileIds = new ArrayList<>();

            try {
                /* Read the uploaded JSON file */
                String jsonfileContent = new String(file.getBytes(), StandardCharsets.UTF_8);

                /* Convert JSON string to ProfileDO object */
                List<ProfileDO> profileDOs = JSONObject.parseArray(jsonfileContent, ProfileDO.class);
                if (Objects.nonNull(profileDOs)) {
                    JSONArray detail = new JSONArray();
                    profileDOs.removeAll(Collections.singleton(null));
                    for (ProfileDO profileDO : profileDOs) {
                        JSONObject errorInfo = new JSONObject();
                        /* Check profile ID */
                        String profileId = profileDO.getProfileId();
                        if (StringUtils.isBlank(profileId)) {
                            errorInfo.put("id", profileId);
                            errorInfo.put("reason", "\"profileId\" must not be null/\"\"");
                            detail.add(errorInfo);
                            continue;
                        }
                        /* Check profile type */
                        ProfileType profileType = profileDO.getProfileType();
                        if (Objects.isNull(profileType)) {
                            errorInfo.put("id", profileId);
                            errorInfo.put("reason", "\"profileType\" must be \"MODEL_PROFILE\"/\"DEVICE_PROFILE\"");
                            detail.add(errorInfo);
                            continue;
                        }
                        /* Check if the profileId already exists */
                        Query query = new Query();
                        query.addCriteria(Criteria.where("profileId").is(profileId));
                        if (mongoDBUtils.exists(query, ProfileDO.class)) {
                            errorInfo.put("id", profileId);
                            errorInfo.put("reason", "\"profileId\" already exists in DataBase");
                            detail.add(errorInfo);
                            continue;
                        }

                        /* Save data */
                        mongoDBUtils.insert(profileDO);
                        profileIds.add(profileId);
                    }

                    if (!detail.isEmpty()) {
                        topContainer.put("result", "NG");
                        topContainer.put("detail", detail);
                        result.setData(topContainer);
                    } else {
                        topContainer.put("result", "OK");
                        result.setData(topContainer);
                    }
                } else {
                    topContainer.put("result", "NG");
                    topContainer.put("reason", "No valid profile data");
                    result.setData(topContainer);
                }
            } catch (Exception e) {
                logger.error("Error occurred while import profile data");
                logger.error("{}: {}", e.getClass().getName(), e.getMessage());
                e.printStackTrace();
                topContainer.put("result", "NG");
                topContainer.put("reason", "Internal exception: " + e.getMessage());
                result.setData(topContainer);
            } finally {
                /* Start a new thread to update the relevant data */
                quartzManager.updateProfileRelevantData(profileIds.toArray(new String[0]));
            }
        } else {
            topContainer.put("result", "NG");
            topContainer.put("reason", "Empty file is uploaded.");
            result.setData(topContainer);
        }

        return result;
    }

    /**
     * Get all profiles that meet the specified condition
     * 
     * @param profileIds   ID of the target profiles
     * @param profileTypes Type of the target profiles
     * @param datas        The field that needs to be returned
     * @return
     */
    public ResultVO queryProfileData(String[] profileIds, String[] profileTypes, String[] datas) {
        /* Make response */
        ResultVO result = new ResultVO(HttpStatus.OK);

        /* Convert profile type */
        profileTypes = Objects.isNull(profileTypes) ? new String[0] : profileTypes;
        HashSet<ProfileType> legalProfileTypes = new HashSet<>();
        for (String profileType : profileTypes) {
            if (ProfileType.DEVICE_PROFILE.getValue().equalsIgnoreCase(profileType)) {
                legalProfileTypes.add(ProfileType.DEVICE_PROFILE);
            }
            if (ProfileType.MODEL_PROFILE.getValue().equalsIgnoreCase(profileType)) {
                legalProfileTypes.add(ProfileType.MODEL_PROFILE);
            }
        }
        /* Query data */
        List<ProfilePojo> profilePojos = queryProfileDataByContent(profileIds,
                legalProfileTypes.toArray(new ProfileType[0]), datas);
        /* Make response data */
        if (Objects.nonNull(datas)) {
            List<Map<String, Object>> responseDatas = new ArrayList<>();
            List<String> names = Arrays.asList(datas);
            for (ProfilePojo profilePojo : profilePojos) {
                Map<String, Object> map = new HashMap<>();
                if (names.contains("profileId")) {
                    map.put("profileId", profilePojo.getProfileId());
                }
                if (names.contains("profileType")) {
                    map.put("profileType", profilePojo.getProfileType());
                }
                if (names.contains("services")) {
                    map.put("services", profilePojo.getServices());
                }
                responseDatas.add(map);
            }
            result.setData(responseDatas);
        } else {
            result.setData(profilePojos);
        }

        return result;
    }

    /**
     * Search profile data with specified content.
     * 
     * @param profileIds
     * @param profileTypes
     * @param datas
     * @return
     */
    public List<ProfilePojo> queryProfileDataByContent(String[] profileIds, ProfileType[] profileTypes,
            String[] datas) {
        List<ProfilePojo> profilePojos = new ArrayList<>();
        /* Make search criteria */
        Query query = new Query();
        if (Objects.nonNull(profileIds) && profileIds.length > 0) {
            query.addCriteria(Criteria.where("profileId").in((Object[]) profileIds));
        }
        if (Objects.nonNull(profileTypes) && profileTypes.length > 0) {
            query.addCriteria(Criteria.where("profileType").in((Object[]) profileTypes));
        }

        datas = Objects.isNull(datas) ? new String[] { "profileId", "profileType", "services" } : datas;
        List<String> items = Arrays.asList(datas);
        List<ProfileDO> profileDOs = mongoDBUtils.find(query, ProfileDO.class);
        for (ProfileDO profileDO : profileDOs) {
            ProfilePojo profilePojo = new ProfilePojo();
            if (items.contains("profileId")) {
                profilePojo.setProfileId(profileDO.getProfileId());
            }
            if (items.contains("profileType")) {
                profilePojo.setProfileType(profileDO.getProfileType().getValue());
            }
            if (items.contains("services")) {
                profilePojo.setServices(profileDO.getServices());
            }

            profilePojos.add(profilePojo);
        }
        return profilePojos;
    }

    /**
     * DO => POJO
     * 
     * @param profileDO
     * @return
     */
    private final ProfilePojo domainToPojo(ProfileDO profileDO) {
        ProfilePojo profilePojo = new ProfilePojo();
        profilePojo.setProfileId(profileDO.getProfileId());
        profilePojo.setProfileType(profileDO.getProfileType().getValue());
        profilePojo.setServices(profileDO.getServices());

        return profilePojo;
    }

    /**
     * POJO => DO
     * 
     * @param profilePojo
     * @return
     * @throws IllegalArgumentException
     */
    private final ProfileDO pojoToDomain(ProfilePojo profilePojo) {
        /* Check if the profile type is legal */
        String profileType = profilePojo.getProfileType();
        if (profileType.equalsIgnoreCase(ProfileType.DEVICE_PROFILE.getValue())
                || profileType.equalsIgnoreCase(ProfileType.MODEL_PROFILE.getValue())) {
            ProfileDO profileDO = new ProfileDO();
            profileDO.setProfileId(profilePojo.getProfileId());
            profileDO.setProfileType(
                    profileType.equalsIgnoreCase(ProfileType.DEVICE_PROFILE.getValue()) ? ProfileType.DEVICE_PROFILE
                            : ProfileType.MODEL_PROFILE);
            profileDO.setServices(profilePojo.getServices());

            return profileDO;
        } else {
            /* Will response 400 error */
            throw new IllegalArgumentException("Illegal profileType. ProfileType should be \"device\" OR \"model\"!");
        }
    }

    /**
     * Replace the old data with the new data.(Which means the old data is exist)
     * 
     * @param oldProfileId ID of the old profile data
     * @param profileDO    New profile data
     */
    private void replaceOldRecord(String oldProfileId, ProfileDO profileDO) {
        /* Make search criteria */
        Query query = new Query();
        query.addCriteria(Criteria.where("profileId").is(oldProfileId));

        /* Make update */
        Update update = new Update();
        update.set("profileId", profileDO.getProfileId());
        update.set("profileType", profileDO.getProfileType());
        update.set("services", profileDO.getServices());
        /* Update data */
        mongoDBUtils.upsert(query, update, ProfileDO.class);
    }
}
