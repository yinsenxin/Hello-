package jp.co.brother.machinemanage.pojo;

import lombok.Data;

@Data
public class DesignPojo {

    /**
     * The unique ID of the design data
     */
    private String designId;
    /**
     * The base64 data of the Design image. Example:
     * "data:image/bmp;base64,Qk02CxcAAAAAADYAAAAoAAAAq..."
     */
    private String imageData;
    /**
     * The collection of key position information on the Design image. Example:
     * {"key_1":{"x":1028,"y":59,"w":74,"h":46}}
     */
    private Object keys;
    /**
     * The screen position information on the Design image. Example:
     * {"x":493,"y":52,"w":366,"h":214}
     */
    private Object screen;
    /**
     * The touch panel position information on the Design image. Example:
     * {"x":493,"y":52,"w":366,"h":214}
     */
    private Object touchPanel;
    /**
     * The time when this data was last modified
     */
    private String lastModifyTime;
}
