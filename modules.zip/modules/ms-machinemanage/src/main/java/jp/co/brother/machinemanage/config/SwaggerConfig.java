package jp.co.brother.machinemanage.config;

import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.List;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;

import jp.co.brother.machinemanage.controller.FreeMarkerController;
import jp.co.brother.machinemanage.utils.GetRequestMappingValue;
import springfox.documentation.builders.ApiInfoBuilder;
import springfox.documentation.builders.PathSelectors;
import springfox.documentation.builders.RequestHandlerSelectors;
import springfox.documentation.service.ApiInfo;
import springfox.documentation.spi.DocumentationType;
import springfox.documentation.spring.web.plugins.Docket;
import springfox.documentation.swagger2.annotations.EnableSwagger2;

@Configuration
@EnableSwagger2
@PropertySource(value = "classpath:application.properties")
public class SwaggerConfig {

    @Value("${server.port}")
    private String port;

    @Bean
    public Docket createRestApi() {
        return new Docket(DocumentationType.SWAGGER_2).apiInfo(apiInfo()).select()
                .apis(RequestHandlerSelectors.basePackage("jp.co.brother.machinemanage.controller"))
                .paths(PathSelectors.any()).build();
    }

    private ApiInfo apiInfo() {
        ApiInfoBuilder apiInfoBuilder = new ApiInfoBuilder();
        // HTMLè°ƒæ•´api
        List<String> listValue = GetRequestMappingValue.getValue(FreeMarkerController.class);
        apiInfoBuilder.title("微服务");
        int len = listValue.size();

        StringBuffer buffer = new StringBuffer();
        /* get current IP */
        String ip = null;
        try {
            InetAddress inetAddress = InetAddress.getLocalHost();
            ip = inetAddress.getHostName();
        } catch (UnknownHostException e) {
            ip = "apbsh0898";
            e.printStackTrace();
        }
        for (int i = 0; i < len; i++) {
            buffer.append("http://" + ip + ":" + port + listValue.get(i) + "\n");
        }
        apiInfoBuilder.description("微服务系统页面列表:" + "\n" + buffer);
        apiInfoBuilder.version("1.0");
        return apiInfoBuilder.build();
    }
}
