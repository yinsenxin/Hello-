package jp.co.brother.machinemanage.controller;

import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import jp.co.brother.machinemanage.pojo.ProfilePojo;
import jp.co.brother.machinemanage.service.ProfileManager;
import jp.co.brother.machinemanage.vo.ResultVO;

@RestController
@RequestMapping("/profile")
public class ProfileController {

    @Autowired
    private HttpServletResponse response;
    @Autowired
    private ProfileManager profileManager;

    /**
     * Get all profile data with no condition.
     * 
     * @return
     */
    @GetMapping(value = "/profileInfo", produces = "application/json;charset=UTF-8")
    public ResultVO getProfileInfo() {
        return profileManager.getProfileData();
    }

    /**
     * Get the profile data of the specified profile.
     * 
     * @param profileId ID of the specified profile
     * @return
     */
    @GetMapping(value = "/profileInfo/{profileId}", produces = "application/json;charset=UTF-8")
    public ResultVO getProfileInfoById(@PathVariable(name = "profileId", required = true) String profileId) {
        return profileManager.getProfileData(profileId);
    }

    /**
     * Add a new profile record.
     * 
     * @param profileData profile data
     * @return
     */
    @PutMapping(value = "/add", produces = "application/json;charset=UTF-8")
    public ResultVO addProfileInfo(@RequestBody ProfilePojo profileData) {
        return profileManager.addProfileData(profileData);
    }

    /**
     * Update the specified profile record with the given profile data.
     * 
     * @param profileId   ID of the specified profile
     * @param profileData profile data
     * @return
     */
    @PutMapping(value = "/update/{profileId}", produces = "application/json;charset=UTF-8")
    public ResultVO updateProfileInfo(@PathVariable(name = "profileId", required = true) String profileId,
            @RequestBody(required = true) ProfilePojo profileData) {
        return profileManager.updateProfileData(profileId, profileData);
    }

    /**
     * Delete the specified profile record with the given profileIds.
     * 
     * @param profileIds ID of the specified profiles
     * @return
     */
    @DeleteMapping(value = "/delete", produces = "application/json;charset=UTF-8")
    public ResultVO deleteProfileInfo(@RequestParam(name = "profileIds", required = true) String[] profileIds) {
        return profileManager.deleteProfileData(profileIds);
    }

    /**
     * Download the profile data of the specified profiles.
     * 
     * @param profileIds ID of the specified profiles
     * @return
     */
    @GetMapping(value = "/export")
    public ResultVO exportProfileInfo(@RequestParam(name = "profileIds", required = true) String[] profileIds) {
        return profileManager.exportProfileData(response, profileIds);
    }

    /**
     * Import profile data.
     * 
     * @param file profile data
     * @return
     */
    @PostMapping(value = "/import", consumes = "multipart/form-data")
    public ResultVO importProfileInfo(MultipartFile file) {
        return profileManager.importProfileData(file);
    }

    /**
     * Get all profiles that meet the specified condition
     * 
     * @param profileIds   ID of the target profiles
     * @param profileTypes Type of the target profiles
     * @param datas        The field that needs to be returned
     * @return
     */
    @GetMapping(value = "/query", produces = "application/json;charset=UTF-8")
    public ResultVO queryProfileInfo(@RequestParam(name = "profileIds", required = false) String[] profileIds,
            @RequestParam(name = "profileTypes", required = false) String[] profileTypes,
            @RequestParam(name = "datas", required = false) String[] datas) {
        return profileManager.queryProfileData(profileIds, profileTypes, datas);
    }
}
