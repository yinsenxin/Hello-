package jp.co.brother.machinemanage.pojo;

import lombok.Data;

@Data
public class ProfileStatusPojo {

    private boolean healthy;
    private String reason;

    public ProfileStatusPojo() {
        this.healthy = false;
        this.reason = "";
    }
}