package jp.co.brother.machinemanage.quartz;

import org.quartz.DisallowConcurrentExecution;
import org.quartz.Job;
import org.quartz.JobDataMap;
import org.quartz.JobExecutionContext;
import org.quartz.PersistJobDataAfterExecution;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;

import jp.co.brother.machinemanage.service.MachineManager;

@Component
@DisallowConcurrentExecution
@PersistJobDataAfterExecution
public class MachineRelevantJob implements Job {

    @Autowired
    private MachineManager machineManager;

    private static final Logger logger = LoggerFactory.getLogger(MachineRelevantJob.class);

    public MachineRelevantJob() {
    }

    @Override
    public void execute(JobExecutionContext context) {
        try {
            JobDataMap jobDataMap = context.getTrigger().getJobDataMap();
            JSONArray machineIds = JSONObject.parseArray(jobDataMap.getString("machineIds"));
            logger.info("Some machine have changed, update the relevant data. machineIds: {}", machineIds);

            /* Maintain machine status */
            machineManager.updateMachineStatusByMachineId(machineIds.toArray(new String[0]));
        } catch (Exception e) {
            logger.error("{} : {}", e.getClass().getName(), e.getMessage());
            e.printStackTrace();
        }
    }
}