package jp.co.brother.machinemanage.utils;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;

import org.springframework.web.bind.annotation.RequestMapping;

public class GetRequestMappingValue {

    /**
     * Get the value of the RequestMapping of a specific controller class
     * 
     * @param controllerClassName The class name of the specific controller class
     * @return value of the RequestMapping
     */
    public static List<String> getValue(Class<?> controllerClassName) {
        List<String> result = new ArrayList<>();
        /* Get all declared methods */
        Class<?> clazz = controllerClassName;
        Method[] methods = clazz.getDeclaredMethods();
        /* Check each method */
        for (Method method : methods) {
            /**
             * Whether the current method has annotations.
             * Example: "@RequestMapping(value="/route",method=RequestMethod.GET)"
             */
            boolean present = method.isAnnotationPresent(RequestMapping.class);
            if (present) {
                RequestMapping annotation = method.getAnnotation(RequestMapping.class);
                String[] value = annotation.value();
                for (String str : value) {
                    result.add(str);
                }
            }
        }
        return result;
    }
}
