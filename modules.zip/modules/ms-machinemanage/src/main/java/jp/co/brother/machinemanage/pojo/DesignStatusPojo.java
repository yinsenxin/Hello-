package jp.co.brother.machinemanage.pojo;

import lombok.Data;

@Data
public class DesignStatusPojo {

    private boolean healthy;
    private String reason;

    public DesignStatusPojo() {
        this.healthy = false;
        this.reason = "";
    }
}