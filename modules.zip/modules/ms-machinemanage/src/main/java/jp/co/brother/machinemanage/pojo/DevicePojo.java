package jp.co.brother.machinemanage.pojo;

import java.util.Map;

import lombok.Data;

@Data
public class DevicePojo {

    /**
     * The unique ID of the device data
     */
    private String deviceId;
    /**
     * The address of the device configuration page. Example:
     * "http://127.0.0.1:5201/cameraConfig.html"
     */
    private String configurePage;
    /**
     * The category of the current device.
     */
    private String deviceCategory;
    /**
     * The heart-beat detection address of the current device. Example:
     * "http://127.0.0.1:5201/heartBeat"
     */
    private String heartBeat;
    /**
     * The description of the current device. Should be a JSON object
     */
    private Object description;
    /**
     * The services provided by the current device. Should be a JSON object
     */
    private Map<String, Object> services;
}
