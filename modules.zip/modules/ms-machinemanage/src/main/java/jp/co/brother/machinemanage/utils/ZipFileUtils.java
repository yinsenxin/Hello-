package jp.co.brother.machinemanage.utils;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.Charset;
import java.util.Enumeration;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;
import java.util.zip.ZipOutputStream;

import org.apache.commons.io.FileUtils;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;



@Component
public class ZipFileUtils {

    private static final Logger logger = LoggerFactory.getLogger(ZipFileUtils.class);

    /**
     * Compress the specify file that contains sub-folders and store them to a ZIP
     * file
     * 
     * @param srcFiles the file will be compressed
     * @param zipPath  the location which stores the ZIP file
     */
    public void zipFileWithTier(String srcFiles, String zipPath) {
        try {
            FileOutputStream zipFile = new FileOutputStream(zipPath);
            BufferedOutputStream buffer = new BufferedOutputStream(zipFile);
            ZipOutputStream out = new ZipOutputStream(buffer);
            zipFiles(srcFiles, out, "");
            out.close();
        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }

    /**
     * Recursive the specify file also contains the folder which may don't include
     * any file.
     * 
     * @param filePath compress file
     * @param out      the zipfile's outputStream.
     * @param prefix   the prefix indicates the parent folder name of the file that
     *                 makes the tier relation
     * @throws IOException
     */
    public void zipFiles(String filePath, ZipOutputStream out, String prefix) throws IOException {
        File file = new File(filePath);
        if (file.isDirectory()) {
            if (file.listFiles().length == 0) {
                ZipEntry zipEntry = new ZipEntry(prefix + file.getName() + "/");
                out.putNextEntry(zipEntry);
                out.closeEntry();
            } else {
                prefix += file.getName() + File.separator;
                for (File f : file.listFiles())
                    zipFiles(f.getAbsolutePath(), out, prefix);
            }
        } else {
            FileInputStream in = new FileInputStream(file);
            ZipEntry zipEntry = new ZipEntry(prefix + file.getName());
            out.putNextEntry(zipEntry);
            byte[] buf = new byte[1024];
            int len;
            while ((len = in.read(buf)) > 0) {
                out.write(buf, 0, len);
            }
            out.closeEntry();
            in.close();
        }

    }

    /**
     * Extract the specified ZIP file to the specified directory
     * 
     * @param srcFile Path of the ZIP file
     * @param destDir Destination directory
     * @return
     * @throws IOException
     */
    public boolean unZipFile(String srcFile, String destDir) throws IOException {
        boolean result = false;

        /* check parameter */
        if (StringUtils.isNotBlank(srcFile) && StringUtils.isNotBlank(destDir)) {
            /* check input file */
            File zipFile = new File(srcFile);
            if (!zipFile.exists()) {
                logger.info("Input srcFile does not exist, do nothing");
                return false;
            }

            /* check whether the file is a directory */
            if (zipFile.isDirectory() == true) {
                logger.info("Input srcFile is a folder, do nothing");
                return false;
            }

            /* check destination directory */
            File dir = new File(destDir);
            /* check whether the file instance is a normal file */
            if (dir.isFile() == true) {
                logger.warn("Input folder name is a file, do nothing");
                return false;
            }

            /* if specified out path exists */
            if (dir.exists() == true) {
                /* delete directory */
                FileUtils.deleteDirectory(dir);
            }
            /* recreate */
            dir.mkdirs();

            /* Extract file */
            ZipFile zip = new ZipFile(zipFile, Charset.forName("utf-8"));
            /* get each element */
            for (Enumeration<?> entries = zip.entries(); entries.hasMoreElements();) {
                /* get signal element */
                ZipEntry entry = (ZipEntry) entries.nextElement();

                /* get element name */
                String zipEntryName = entry.getName();
                /* get element data */
                InputStream in = zip.getInputStream(entry);

                /* get element output path */
                String outPath = (destDir + "/" + zipEntryName).replace("/", File.separator);
                /* check output folder exists */
                File file = new File(outPath.substring(0, outPath.lastIndexOf(File.separator)));
                if (file.exists() == false) {
                    file.mkdirs();
                }
                /* check whether the file instance is a directory */
                if (new File(outPath).isDirectory()) {
                    continue;
                }

                /* save data to local file */
                OutputStream out = new FileOutputStream(outPath);
                byte[] buf1 = new byte[2048];
                int len;
                while ((len = in.read(buf1)) > 0) {
                    out.write(buf1, 0, len);
                }
                in.close();
                out.close();
            }
            zip.close();

            /* if no exception happened, return true */
            result = true;
        } else {
            logger.warn("Illegal input parameters detected");
        }

        return result;
    }
}
