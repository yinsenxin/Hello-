package jp.co.brother.machinemanage.pojo;

import lombok.Data;

@Data
public class ModelFirmwarePojo {

    /**
     * The name of the firmware
     */
    private String name;
    /**
     * The version of the firmware
     */
    private String version;
    /**
     * The description of the firmware
     */
    private String description;
    /**
     * The network path of the firmware
     */
    private String url;
    /**
     * The upload date of the firmware
     */
    private String uploadDate;
}
