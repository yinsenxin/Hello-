package jp.co.brother.machinemanage.quartz;

import org.quartz.DisallowConcurrentExecution;
import org.quartz.Job;
import org.quartz.JobDataMap;
import org.quartz.JobExecutionContext;
import org.quartz.PersistJobDataAfterExecution;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;

import jp.co.brother.machinemanage.service.DeviceManager;
import jp.co.brother.machinemanage.service.MachineManager;
import jp.co.brother.machinemanage.service.ModelManager;

@Component
@DisallowConcurrentExecution
@PersistJobDataAfterExecution
public class ProfileRelevantJob implements Job {

    @Autowired
    private ModelManager modelManager;
    @Autowired
    private DeviceManager deviceManager;
    @Autowired
    private MachineManager machineManager;

    private static final Logger logger = LoggerFactory.getLogger(ProfileRelevantJob.class);

    public ProfileRelevantJob() {
    }

    @Override
    public void execute(JobExecutionContext context) {
        try {
            JobDataMap jobDataMap = context.getTrigger().getJobDataMap();
            JSONArray profileIds = JSONObject.parseArray(jobDataMap.getString("profileIds"));
            logger.info("Some profiles have changed, update the relevant data. profileIds: {}", profileIds);

            /* Maintain model data */
            modelManager.updateModelStatusByProfileId(profileIds.toArray(new String[0]));
            /* Maintain device data */
            deviceManager.updateDeviceStatusByProfileId(profileIds.toArray(new String[0]));
            /* Maintain machine Data */
            machineManager.updateMachineStatusByProfileId(profileIds.toArray(new String[0]));
        } catch (Exception e) {
            logger.error("{} : {}", e.getClass().getName(), e.getMessage());
            e.printStackTrace();
        }
    }
}