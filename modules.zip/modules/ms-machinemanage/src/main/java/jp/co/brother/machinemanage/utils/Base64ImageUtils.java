package jp.co.brother.machinemanage.utils;

import java.awt.image.BufferedImage;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Base64;
import java.util.Base64.Decoder;
import java.util.Base64.Encoder;

import javax.imageio.ImageIO;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

@Component
public class Base64ImageUtils {

    private static final Logger logger = LoggerFactory.getLogger(Base64ImageUtils.class);

    /**
     * Get the base64 encoding of the specified image data.
     * 
     * @param path path of the source image.(relative path)
     * @return base64 data.(include "data:image/png;base64,")
     * @throws Exception
     */
    public String encodeImageToBase64(String path) throws Exception {
        logger.info("encode image to base64. path: {}", path);
        String result = null;
        /* check parameter */
        if (StringUtils.isNotBlank(path)) {
            /* get encoder */
            Encoder encoder = Base64.getEncoder();

            /* get file */
            File imageFile = new File(path);
            /* check file */
            if (imageFile.exists() && imageFile.isFile()) {
                /* get imageType */
                // String imageType = path.substring(path.lastIndexOf(".") + 1);
                String imageType = "png"; /* TODO: Default is PNG */
                /* get image data */
                ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
                BufferedImage bufferedImage = ImageIO.read(imageFile);
                ImageIO.write(bufferedImage, imageType, outputStream);

                /* get base64 data */
                result = encoder.encodeToString(outputStream.toByteArray());
                /* add header */
                result = String.format("data:image/%s;base64,%s", imageType, result);
            }
        } else {
            logger.warn("illegal input parameters detected");
        }
        return result;
    }

    /**
     * Save base64 data as a image with specified path and image name.
     * 
     * @param base64    base64 data(include "data:image/png;base64,").
     * @param path      path of the target image.
     * @param imageName name of the target image.
     * @return file name or null
     */
    public String decodeBase64ToImage(String base64, String path, String imageName) throws IOException {
        logger.info("decode base64 to image. path: {}, imageName: {}", path, imageName);
        String result = null;
        /* check parameter */
        if (StringUtils.isNotBlank(base64) && StringUtils.isNotBlank(path) && StringUtils.isNotBlank(imageName)) {
            /* get decoder */
            Decoder decoder = Base64.getDecoder();

            /* parse base64 data */
            String imageType = base64.split(",")[0].split("/")[1].split(";")[0];
            String imageData = base64.split(",")[1];

            /* generate path name */
            String pathName = path.replace("/", File.separator);
            if (!pathName.endsWith(File.separator)) {
                pathName = pathName + File.separator;
            }

            /* check image extension */
            int length = imageName.split("\\.").length;
            if (length == 1) {
                /* if no extension is specified, use the actual file type */
                imageName = imageName + "." + imageType;
            }

            /* get file name */
            String fileName = pathName + imageName;

            /* decode base64 data */
            byte[] decoderBytes = decoder.decode(imageData);

            /* create out stream */
            File imageFile = new File(fileName);
            if (!imageFile.exists()) {
                /* create a directory */
                if (createDir(pathName) == true) {
                    imageFile.createNewFile();
                }
            }
            /* write out stream */
            FileOutputStream outStream = new FileOutputStream(imageFile);
            outStream.write(decoderBytes);
            outStream.close();

            /* operation succeed */
            result = fileName;
        } else {
            logger.warn("illegal input parameters detected");
        }
        return result;
    }

    /**
     * Create a directory with specified directory name.
     * 
     * @param dirName name of the target directory.
     * @return true : operation succeed false : operation failed
     */
    private boolean createDir(String dirName) {
        logger.info("create folder. folderPath: {}", dirName);
        boolean result = false;
        /* check parameter */
        if ((dirName != null) && (!dirName.equals(""))) {
            /* create file instance of specified filename */
            File dir = new File(dirName);

            /* check whether the file instance is a normal file */
            if (dir.isFile() == true) {
                logger.warn("input folder name is a file");
                return false;
            }

            /* if specified path does not exists */
            if (dir.exists() == false) {
                /* check path format */
                if (!dirName.endsWith(File.separator)) {
                    dirName = dirName + File.separator;
                }

                /* create folder & sub folder */
                result = dir.mkdirs();
            } else {
                result = true;
            }
        } else {
            logger.warn("illegal input parameters detected");
        }
        return result;
    }
}
