package jp.co.brother.keywordmanageplus.dto;

import lombok.Data;

@Data
public class ParamList {
	/**
	 * The name of the ParamList data;
	 */
	private String name;
	/**
	 * The type of the ParamList data;
	 */
	private String type;
	/**
	 * The description of the ParamList data;
	 */
	private String description;
}
