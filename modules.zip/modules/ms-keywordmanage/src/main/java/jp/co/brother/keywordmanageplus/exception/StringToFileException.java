package jp.co.brother.keywordmanageplus.exception;

public class StringToFileException extends RuntimeException{

	/**
	 * Automatic generation
	 */
	private static final long serialVersionUID = -1972273835837496599L;
	
	public StringToFileException() {}
	
	/* Call Throwable for exception handling */
	public StringToFileException(String message) {
		super(message);
	}
}
