package jp.co.brother.keywordmanageplus.serviceimpl;

import jp.co.brother.keywordmanageplus.config.FilePathConfig;
import jp.co.brother.keywordmanageplus.constant.Constant;
import jp.co.brother.keywordmanageplus.domain.KeywordDependencyDO;
import jp.co.brother.keywordmanageplus.dto.FileList;
import jp.co.brother.keywordmanageplus.dto.KeywordDependencyDTO;
import jp.co.brother.keywordmanageplus.exception.AlreadyExistsException;
import jp.co.brother.keywordmanageplus.exception.DataNotFoundException;
import jp.co.brother.keywordmanageplus.exception.FileDeleteFailedException;
import jp.co.brother.keywordmanageplus.exception.OperationDBException;
import jp.co.brother.keywordmanageplus.service.KeywordDependencyService;
import jp.co.brother.keywordmanageplus.utils.FileOperationUtils;
import jp.co.brother.keywordmanageplus.utils.MongodbUtils;
import jp.co.brother.keywordmanageplus.vo.KeywordDependencyVO;
import jp.co.brother.keywordmanageplus.vo.ResultVO;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.util.Assert;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Objects;


@Service
@Slf4j
public class KeywordDependencyServiceImpl implements KeywordDependencyService {

    @Autowired
    private MongodbUtils<KeywordDependencyDO> mongodbUtil;

    @Autowired
    private FilePathConfig filePathConfig;

    /**
     * get all dependencies from database
     *
     * @return ResultVO
     */
    @Override
    public ResultVO getAllKeywordDependency() {
        ResultVO resultVO = new ResultVO(HttpStatus.OK);
        List<KeywordDependencyDTO> keywordDTOList = new ArrayList<>();
        List<KeywordDependencyDO> dependencyDOList = mongodbUtil.findAll(KeywordDependencyDO.class);
        if (dependencyDOList == null || dependencyDOList.isEmpty()) {
            resultVO.setData(new ArrayList<>());
            return resultVO;
        }
        for (KeywordDependencyDO dependencyDO : dependencyDOList) {
            if (Objects.isNull(dependencyDO)) {
                log.warn(Constant.DATA_DOCUMENT_INVALID + KeywordDependencyDO.class.getName());
                continue;
            }
            KeywordDependencyDTO dependencyDTO = new KeywordDependencyDTO();
            BeanUtils.copyProperties(dependencyDO, dependencyDTO);
            dependencyDTO.getFileList().forEach(file -> file.setContent(null));
            keywordDTOList.add(dependencyDTO);
        }
        resultVO.setData(keywordDTOList);
        return resultVO;
    }

    /**
     * get one dependency from database by id
     *
     * @param keywordDependencyId 唯一id索引
     * @return ResultVO
     */
    @Override
    public ResultVO getKeywordDependencyById(String keywordDependencyId) {
        /* Check input parameter, make sure they are not null */
        Assert.notNull(keywordDependencyId, Constant.ASSERT_REQUEST_KEYWORD_DEPENDENCY_ID);

        // query database
        Query query = new Query();
        query.addCriteria(Criteria.where(Constant.KEYWORD_ID).is(keywordDependencyId));
        KeywordDependencyDO dependencyDO = mongodbUtil.findOne(query, KeywordDependencyDO.class);

        if (Objects.isNull(dependencyDO)) {
            log.error(Constant.DATA_NOTFOUND_EXCEPTION + KeywordDependencyDO.class.getName());
            throw new DataNotFoundException(Constant.DATA_NOTFOUND_EXCEPTION);
        }
        ResultVO resultVO = new ResultVO(HttpStatus.OK);

        KeywordDependencyDTO dependencyDTO = new KeywordDependencyDTO();
        BeanUtils.copyProperties(dependencyDO, dependencyDTO);
        resultVO.setData(dependencyDTO);
        return resultVO;
    }

    /**
     * add new keywordDependency data
     *
     * @param keywordDependencyVO VO
     * @return ResultVO
     */
    @Override
    public ResultVO insertKeywordDependency(KeywordDependencyVO keywordDependencyVO) {
        /* Check input parameter, make sure they are not null */
        Assert.notNull(keywordDependencyVO.getName(), Constant.ASSERT_REQUEST_BODY_KEYWORD_DEPENDENCY_NAME);
        Assert.notNull(keywordDependencyVO.getVersion(), Constant.ASSERT_REQUEST_BODY_KEYWORD_DEPENDENCY_VERSION);
        Assert.notNull(keywordDependencyVO.getUri(), Constant.ASSERT_REQUEST_BODY_KEYWORD_DEPENDENCY_URI);
        Assert.notNull(keywordDependencyVO.getFile(), Constant.ASSERT_REQUEST_BODY_KEYWORD_DEPENDENCY_FILE_LIST);

        ResultVO resultVO;
        // check fileList is empty
        if (keywordDependencyVO.getFile().isEmpty()) {
            log.warn(Constant.FILE_EMPTY_FAIED);
            resultVO = new ResultVO(HttpStatus.INTERNAL_SERVER_ERROR);
            resultVO.setMessage(Constant.FILE_EMPTY_FAIED);
            return resultVO;
        }

        // check if file exist
        if (isExistsByNameAndUri(keywordDependencyVO)) {
            resultVO = new ResultVO(HttpStatus.CONFLICT);
            resultVO.setMessage(Constant.ALREADY_EXISTS_EXCEPTION);
            return resultVO;
        }

        //If the folder does not exist, created
        String prefix = filePathConfig.getPath();
        String uri = keywordDependencyVO.getUri();
        File folder = new File(prefix + uri);
        FileOperationUtils.checkFolder(folder);

        // Verify file
        List<String> oldFile = FileOperationUtils.listFiles(folder);
        List<String> newFile = new ArrayList<>();
        for (MultipartFile files : keywordDependencyVO.getFile()) {
            newFile.add(files.getOriginalFilename());
        }
        if (!Collections.disjoint(oldFile, newFile)) {
            log.warn(Constant.FILE_ALREADY_EXISTS);
            resultVO = new ResultVO(HttpStatus.CONFLICT);
            resultVO.setMessage(Constant.FILE_ALREADY_EXISTS);
            return resultVO;
        }

        //Get the specific file information, save to the specified directory
        List<FileList> fileLists = new ArrayList<>();
        for (MultipartFile multipartFile : keywordDependencyVO.getFile()) {
            String fileName = multipartFile.getOriginalFilename();
            File file = new File(prefix + uri + File.separator + fileName);
            try {
                multipartFile.transferTo(file);
                fileLists.add(FileOperationUtils.getFileListContent(fileName, file));
            } catch (IllegalStateException | IOException e) {
                // When a file exception is written, delete it
                for (String needDeleteFile : newFile) {
                    FileOperationUtils.deleteFileOrDirectory(needDeleteFile, prefix + uri);
                }
                log.warn(Constant.INSERT_DATABASE_FILE_FAIED, e.getMessage());
                resultVO = new ResultVO(HttpStatus.INTERNAL_SERVER_ERROR);
                resultVO.setMessage(Constant.FILE_WRITE_FAIED);
                return resultVO;
            }
        }

        //Inserts data into the database
        KeywordDependencyDTO dependencyDTO = new KeywordDependencyDTO();
        BeanUtils.copyProperties(keywordDependencyVO, dependencyDTO);
        dependencyDTO.setFileList(fileLists);
        KeywordDependencyDO dependencyDO = new KeywordDependencyDO();
        BeanUtils.copyProperties(dependencyDTO, dependencyDO);
        try {
            mongodbUtil.insert(dependencyDO);
        } catch (Exception e) {
            /* If the database insert fails, delete the uploaded file */
            log.warn(Constant.INSERT_DATABASE_FAILED, e.getMessage());
            for (String needDeleteFile : newFile) {
                FileOperationUtils.deleteFileOrDirectory(needDeleteFile, prefix + uri);
            }
        }
        return new ResultVO(HttpStatus.OK);
    }

    /**
     * update one dependency by id
     *
     * @param keywordDependencyId 唯一id索引
     * @param keywordDependencyDTO DTO
     * @return ResultVO
     */
    @Override
    public ResultVO updateKeywordDependencyById(String keywordDependencyId, KeywordDependencyDTO keywordDependencyDTO) {
        /* Check input parameter, make sure they are not null */
        Assert.notNull(keywordDependencyId, Constant.ASSERT_REQUEST_KEYWORD_DEPENDENCY_ID);
        Assert.notNull(keywordDependencyDTO.getName(), Constant.ASSERT_REQUEST_BODY_KEYWORD_DEPENDENCY_NAME);
        Assert.notNull(keywordDependencyDTO.getVersion(), Constant.ASSERT_REQUEST_BODY_KEYWORD_DEPENDENCY_VERSION);
        Assert.notNull(keywordDependencyDTO.getUri(), Constant.ASSERT_REQUEST_BODY_KEYWORD_DEPENDENCY_URI);
        Assert.notNull(keywordDependencyDTO.getFileList(), Constant.ASSERT_REQUEST_BODY_KEYWORD_DEPENDENCY_FILE_LIST);

        ResultVO resultVO;

        // check fileList is empty
        if (keywordDependencyDTO.getFileList().isEmpty()) {
            log.warn(Constant.FILE_EMPTY_FAIED);
            resultVO = new ResultVO(HttpStatus.INTERNAL_SERVER_ERROR);
            resultVO.setMessage(Constant.FILE_EMPTY_FAIED);
            return resultVO;
        }

        // check data
        Query query = new Query();
        query.addCriteria(Criteria.where(Constant.KEYWORD_ID).is(keywordDependencyId));
        KeywordDependencyDO oldDependencyDO = mongodbUtil.findOne(query, KeywordDependencyDO.class);
        if (oldDependencyDO == null) {
            log.error(Constant.DATA_NOTFOUND_EXCEPTION + keywordDependencyId);
            throw new DataNotFoundException(Constant.DATA_NOTFOUND_EXCEPTION);
        }

        // save file
        KeywordDependencyDO newDependencyDO = new KeywordDependencyDO();
        BeanUtils.copyProperties(keywordDependencyDTO, newDependencyDO);
        List<File> fileList = replaceFileData(newDependencyDO, oldDependencyDO);

        // update database
        Update update = new Update();
        update.set(Constant.KEYWORD_NAME, keywordDependencyDTO.getName());
        update.set(Constant.KEYWORD_VERSION, keywordDependencyDTO.getVersion());
        update.set(Constant.KEYWORD_URI, keywordDependencyDTO.getUri());
        update.set(Constant.KEYWORD_DESCRIPTION, keywordDependencyDTO.getDescription());
        update.set(Constant.KEYWORD_FILELIST, keywordDependencyDTO.getFileList());
        try {
            mongodbUtil.upsert(query, update, KeywordDependencyDO.class);
        } catch (Exception e) {
            log.warn(Constant.UPDATE_DATABASE_FAILED, e.getMessage());
            try {
                for (File file2 : fileList) {
                    Files.delete(file2.toPath());
                }
            } catch (IOException e1) {
                log.warn(Constant.DELETE_FILE_FAIED, e1.getMessage());
                throw new FileDeleteFailedException(Constant.DELETE_FILE_FAIED);
            }
        }

        return new ResultVO(HttpStatus.OK);
    }

    /**
     * Delete the keywordDependency data by keywordDependencyIds
     *
     * @param keywordDependencyId 唯一id索引
     * @return ResultVO
     */
    @Override
    public ResultVO deleteKeywordDependencyById(String[] keywordDependencyId) {
        /* Check input parameter, make sure they are not null */
        Assert.notEmpty(keywordDependencyId, Constant.ASSERT_REQUEST_KEYWORDID);

        ResultVO resultVO;
        List<KeywordDependencyDTO> keywordDependencyDTOList = getKeywordDependency(keywordDependencyId);
        /* Make search criteria */
        Query query = new Query();
        query.addCriteria(Criteria.where(Constant.KEYWORD_ID).in((Object[]) keywordDependencyId));
        /* Delete specified data */
        /* If the database deletion fails, the file will not be deleted */
        try {
            mongodbUtil.findAllAndRemove(query, KeywordDependencyDO.class);
        } catch (Exception e) {
            log.warn(Constant.DELETE_DATABASE_FAIED, e.getMessage());
            resultVO = new ResultVO(HttpStatus.INTERNAL_SERVER_ERROR);
            resultVO.setMessage(Constant.DELETE_DATABASE_FAIED);
            return resultVO;
        }

        String prefix = filePathConfig.getPath();
        for (KeywordDependencyDTO dependencyDTO : keywordDependencyDTOList) {
            List<FileList> fileList = dependencyDTO.getFileList();
            String uri = dependencyDTO.getUri();

            for (FileList file : fileList) {
                String fileName = file.getName();

                File needDeleteFile = new File(prefix + uri + File.separator + fileName);
                try {
                    if (needDeleteFile.exists()) {
                        Files.delete(needDeleteFile.toPath());
                    }
                } catch (Exception e) {
                    log.warn(Constant.DELETE_DATABASE_FILE_FAIED, e.getMessage());
                    resultVO = new ResultVO(HttpStatus.INTERNAL_SERVER_ERROR);
                    resultVO.setMessage(Constant.FILE_DELETE_FAIED);
                    return resultVO;
                }
            }
        }

        return new ResultVO(HttpStatus.OK);
    }

    private List<KeywordDependencyDTO> getKeywordDependency(String[] keywordDependencyId) {
        Query query = new Query();
        query.addCriteria(Criteria.where(Constant.KEYWORD_ID).in((Object[]) keywordDependencyId));
        List<KeywordDependencyDO> find = mongodbUtil.find(query, KeywordDependencyDO.class);
        List<KeywordDependencyDTO> dependencyDTOList = new ArrayList<>();
        for (KeywordDependencyDO dependencyDO : find) {
            if (Objects.nonNull(dependencyDO)) {
                KeywordDependencyDTO dependencyDTO = new KeywordDependencyDTO();
                BeanUtils.copyProperties(dependencyDO, dependencyDTO);
                dependencyDTOList.add(dependencyDTO);
            }
        }
        return dependencyDTOList;
    }

    /**
     * check data is exists
     *
     * @param dependencyVO VO
     * @return boolean
     */
    private boolean isExistsByNameAndUri(KeywordDependencyVO dependencyVO) {
        Query query = new Query();
        query.addCriteria(Criteria.where(Constant.KEYWORD_NAME).is(dependencyVO.getName()).and(Constant.KEYWORD_URI).is(dependencyVO.getUri()));
        return mongodbUtil.exists(query, KeywordDependencyDO.class);
    }

    /**
     * replace file data
     *
     * @param newDependency newFileDate
     * @param oldDependency oldFileData
     * @return List<File>
     */
    private List<File> replaceFileData(KeywordDependencyDO newDependency, KeywordDependencyDO oldDependency) {
        // Gets KeywordOldDTO data, delete it
        String uri = oldDependency.getUri();
        List<FileList> fileList = oldDependency.getFileList();
        for (FileList files : fileList) {
            String name = files.getName();
            File file = new File(filePathConfig.getPath() + uri + File.separator + name);
            try {
                if (file.exists()) {
                    Files.delete(file.toPath());
                }
            } catch (Exception e) {
                log.warn(Constant.UPDATE_DATABASE_FILE_FAIED, e.getMessage());
                throw new OperationDBException(Constant.UPDATE_DATABASE_KEYWORD);
            }
        }
        // get new file
        String uri2 = newDependency.getUri();
        List<FileList> fileList2 = newDependency.getFileList();
        // old file path
        File files = new File(filePathConfig.getPath() + uri2);
        List<String> oldFile = FileOperationUtils.listFiles(files);
        List<String> newFile = new ArrayList<>();

        // Store the modified file
        List<File> newFileList = new ArrayList<>();
        List<String> contentList = new ArrayList<>();
        for (FileList fileList3 : fileList2) {
            String name = fileList3.getName();
            String content = fileList3.getContent();
            File file = new File(filePathConfig.getPath() + uri2 + File.separator + name);
            newFile.add(name);
            newFileList.add(file);
            contentList.add(content);
        }
        // Determine if the file exists
        if (!Collections.disjoint(oldFile, newFile)) {
            log.warn(Constant.FILE_ALREADY_EXISTS);
            throw new AlreadyExistsException(Constant.FILE_ALREADY_EXISTS);
        }

        for (int i = 0; i < newFileList.size(); i++) {
            FileOperationUtils.string2File(contentList.get(i), newFileList.get(i));
        }
        return newFileList;
    }

}
