package jp.co.brother.keywordmanageplus.dto;


import lombok.Data;

/**
 * @Description 
 * @author yinse
 *
 */
@Data
public class KeywordEnvironmentDTO {
	
	/**
     * The unique ID of the KeywordEnvironmentPojo data.
     */
	private String id;
	/**
	 * The keyWordEnviroId of the KeyWordEnviroPojo data;
	 */
	private String name;
	/**
	 * The version of the KeyWordEnviroPojo data;
	 */
	private String version;
	/**
	 * The uri of the KeyWordEnviroPojo data;
	 */
	private String uri;
	/**
	 * The fileEnviroList of the KeyWordEnviroPojo data;
	 */
	private KeywordEnvironmentFileList keywordEnvironmentFileList;
	/**
	 * The description of the KeyWordEnviroPojo data;
	 */
	private String description;
}
