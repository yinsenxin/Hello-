package jp.co.brother.keywordmanageplus.controller;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

import jp.co.brother.keywordmanageplus.constant.Constant;
import jp.co.brother.keywordmanageplus.utils.EurekaServiceIpUtils;

/**
 * @author yinse
 */
@Controller
public class FreeMarkerController {

    @Autowired
    private EurekaServiceIpUtils eurekaServiceIpUtils;

    @GetMapping(value = "/keywordEnvironment")
    public String getKeywordEnvironment() {
        return "keywordEnvironment";
    }

    @GetMapping(value = "/keyword")
    public String getKeyword(Map<String, String> map) {
        String machineManagerUrl = eurekaServiceIpUtils.getHostPort(Constant.MACHINE_MANAGER_SERVICE_NAME);
        map.put("machineManagerUrl", machineManagerUrl);
        return "Keyword";
    }

    @GetMapping(value = "/keywordDependency")
    public String getKeywordDependency() {
        return "KeywordDependency";
    }

    @GetMapping(value = "/keywordResources")
    public String getKeywordResources() {
        return "KeywordResources";
    }
}
