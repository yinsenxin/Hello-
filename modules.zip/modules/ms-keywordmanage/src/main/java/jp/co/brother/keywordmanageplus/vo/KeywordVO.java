package jp.co.brother.keywordmanageplus.vo;


import java.util.List;

import org.springframework.web.multipart.MultipartFile;

import jp.co.brother.keywordmanageplus.dto.ParamList;
import lombok.Data;

/**
 * 
 * @author yinse
 * 
 */
@Data
public class KeywordVO {
	
	/**
	 * The Keyword name obtained by the front end;
	 */
	private String name;
	/**
	 * The Keyword type obtained by the front end;
	 */
	private String type;
	/**
	 * The Keyword version obtained by the front end;
	 */
	private String version;
	/**
	 * The Keyword uri obtained by the front end;
	 */
	private String uri;
	/**
	 * The Keyword status obtained by the front end;
	 */
	private String status;
	/**
	 * The Keyword description obtained by the front end;
	 */
	private String description;
	/**
	 * The Keyword file obtained by the front end;
	 */
	private List<MultipartFile> file;
	/**
	 * The Keyword param obtained by the front end;
	 */
	private List<ParamList> param;
	
	
	
}
