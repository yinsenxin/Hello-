package jp.co.brother.keywordmanageplus.constant;

public class Constant {
	
	private Constant() {
		
		    throw new IllegalStateException("Utility class");
	  }

    /**
     * http前缀
     */
    public static final String HTTP_PREFIX="http://";
    public static final String MACHINE_MANAGER_SERVICE_NAME = "MACHINEMANAGER";


    /* Date format*/
	public static final String DATEFORMAT = "yyyy-MM-dd HH:mm:ss";
	public static final String FILE_LAST_INDEXOF = ".";
	public static final String FILE_SUFFIX = "py";
	public static final String ZIP_FILE_SUFFIX = "zip";
	public static final String FILETYPE = "python";
	public static final String ROBOT_FILE_TYPE = "robot";
	public static final String FILE_ENCODER = "UTF-8";
	public static final String ONE_SPACE = " ";

    /* KeywordEnviro related  database parameter */
    public static final String KEYWORD_ENVIRONMENT_ID = "_id";
    public static final String KEYWORD_ENVIRONMENT_NAME = "name";
    public static final String KEYWORD_ENVIRONMENT_VERSION ="version";
    public static final String KEYWORD_ENVIRONMENT_URI ="uri";
    public static final String KEYWORD_ENVIRONMENT_FILEENVIRONMENTLIST ="file";
    public static final String KEYWORD_ENVIRONMENT_DESCRIPTION ="description";
    
    /* KeywordEnvironment related parameter confirmation */
    public static final String ASSERT_REQUEST_KEYWORDENVIRONMENTID = "\"keywordEnvironmentId\" must not be null!";
    public static final String ASSERT_REQUEST_BODY = "Body of this request must not be null!";
    public static final String ASSERT_REQUEST_BODY_KEYWORDENVIRONMENTID = "\"keywordEnvironmentId\" in the body must not be null or empty!";
    public static final String ASSERT_REQUEST_BODY_NAME = "name in the body must not be null";
    public static final String ASSERT_REQUEST_BODY_VERSION = "version in the body must not be null";
    public static final String ASSERT_REQUEST_BODY_URI = "uri in the body must not be null";
    public static final String ASSERT_REQUEST_BODY_KEYWORDENVIRONMENTFILE = "file in the body must not be null";
    
    /* Keyword related  database parameter */
    public static final String KEYWORD_ID = "_id";
    public static final String KEYWORD_NAME = "name";
    public static final String KEYWORD_VERSION = "version";
    public static final String KEYWORD_TYPE = "type";
    public static final String KEYWORD_STATUS = "status";
    public static final String KEYWORD_URI = "uri";
    public static final String KEYWORD_FILELIST = "file_list";
    public static final String KEYWORD_PARAMLIST = "param_list";
    public static final String KEYWORD_DESCRIPTION = "description";

    /* KeywordDependency related parameter confirmation */
    public static final String ASSERT_REQUEST_KEYWORD_DEPENDENCY_ID = "\"keywordDependencyId\" must not be null!";
    public static final String ASSERT_REQUEST_BODY_KEYWORD_DEPENDENCY_NAME = "name in the body must not be null or empty!";
    public static final String ASSERT_REQUEST_BODY_KEYWORD_DEPENDENCY_VERSION = "version in the body must not be null";
    public static final String ASSERT_REQUEST_BODY_KEYWORD_DEPENDENCY_URI = "uri in the body must not be null";
    public static final String ASSERT_REQUEST_BODY_KEYWORD_DEPENDENCY_FILE_LIST = "fileList in the body must not be null";

    /* Keyword related parameter confirmation */
    public static final String ASSERT_REQUEST_KEYWORDID = "\"keywordId\" must not be null!";
    public static final String ASSERT_REQUEST_BODY_KEYWORDID = "\"keywordId\" in the body must not be null or empty!"; 
    public static final String ASSERT_REQUEST_BODY_KEYWORDNAME = "name in the body must not be null or empty!"; 
    public static final String ASSERT_REQUEST_BODY_KEYWORDVERSION = "version in the body must not be null";
    public static final String ASSERT_REQUEST_BODY_KEYWORDTYPE = "type in the body must not be null";
    public static final String ASSERT_REQUEST_BODY_KEYWORDSTATUS = "status in the body must not be null";
    public static final String ASSERT_REQUEST_BODY_KEYWORDURI = "uri in the body must not be null";
    public static final String ASSERT_REQUEST_BODY_KEYWORDFILELIST = "fileList in the body must not be null";
    public static final String ASSERT_REQUEST_BODY_KEYWORDPARAMLIST = "paramList in the body must not be null";
    
    /* Exception information */
    public static final String DATA_NOTFOUND_EXCEPTION = "Target data not found!";
    public static final String MACHINE_NOT_FOUND_EXCEPTION = "Machine data not found!";
    public static final String KEYWORD_NOT_FOUND_EXCEPTION = "Get keyword failed ! check the param.";
    public static final String MODEL_NOT_FOUND_EXCEPTION = "Get model by machineId failed, model not found!";
    public static final String ALREADY_EXISTS_EXCEPTION = "Name and URI is already exists!";
    public static final String EXCEPTION_LOG_RECORD = "{} : {}";
    public static final String BADREQUEST_UPDATE_KEYWORDNAME = "The Name must be not update!";
    public static final String KEYWORD_EXECUTE_FAILED = "Keyword execute failed !";
    
    /* Log information logging */
    public static final String INSERT_DATABASE_FAILED = "The insertion of data into the database failed= {}";
    public static final String DELETE_DATABASE_FAIED = "Deleting data to database failed= {}";
    public static final String DELETE_FILE_FAIED = "Deleting the file failed= {}";
    public static final String DELETE_DATABASE_FILE_FAIED = "Failed to delete the file while deleting the database record= {}";
    public static final String UPDATE_DATABASE_FILE_FAIED = "Failed to delete the file while update the database record= {}";
    public static final String UPDATE_DATABASE_FAILED = "Update data to database failed= {}";
    public static final String INSERT_DATABASE_FILE_FAIED = "Failed to upload file while inserting database record= {}";
    public static final String DATA_DOCUMENT_INVALID = "Invalid document ";
    public static final String STRING_TO_FILE = "An exception occurred when writing a string to a file";
    public static final String FILE_TO_STRING = "An error occurred while converting a file to a string";
    public static final String UPDATE_DATABASE_KEYWORD = "An error occurred while modifying the database";
    /* ResultVO about Message */
    public static final String FILE_WRITE_FAIED = "File writing to disk failed";
    public static final String FILE_ALREADY_EXISTS = "The file already exists";
    public static final String FILE_EMPTY_FAIED = "The uploaded file is empty";
    public static final String FILE_DELETE_FAIED = "File deletion failed";
    public static final String FILE_ZIP_FAILED = "failed to zip file !";

    public static final String KEYWORD_FILE_PATH = "Keyword";
    public static final String KEYWORD_ENVIRONMENT_FILE_PATH = "Environment";
}











