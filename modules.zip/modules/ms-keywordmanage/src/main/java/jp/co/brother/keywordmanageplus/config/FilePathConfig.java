package jp.co.brother.keywordmanageplus.config;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

import lombok.Data;

@Component
@ConfigurationProperties(prefix = "file")
@Data
public class FilePathConfig {
	
	private String path;
	private String description;
}
