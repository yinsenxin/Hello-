package jp.co.brother.keywordmanageplus.serviceimpl;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;

import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import jp.co.brother.keywordmanageplus.config.FilePathConfig;
import jp.co.brother.keywordmanageplus.constant.Constant;
import jp.co.brother.keywordmanageplus.domain.KeywordDO;
import jp.co.brother.keywordmanageplus.domain.KeywordDependencyDO;
import jp.co.brother.keywordmanageplus.domain.KeywordEnvironmentDO;
import jp.co.brother.keywordmanageplus.dto.FileList;
import jp.co.brother.keywordmanageplus.exception.ZipFileFailedException;
import jp.co.brother.keywordmanageplus.service.KeywordResourcesService;
import jp.co.brother.keywordmanageplus.utils.FileOperationUtils;
import jp.co.brother.keywordmanageplus.utils.MongodbUtils;
import jp.co.brother.keywordmanageplus.vo.KeywordResourcesVO;
import jp.co.brother.keywordmanageplus.vo.ResultVO;

@Service
public class KeywordResourcesServiceImpl implements KeywordResourcesService {

    @Autowired
    private MongodbUtils<KeywordDO> keywordDOMongodbUtils;

    @Autowired
    private MongodbUtils<KeywordEnvironmentDO> keywordEnvironmentDOMongodbUtils;

    @Autowired
    private MongodbUtils<KeywordDependencyDO> dependencyDOMongodbUtils;

    @Autowired
    private FilePathConfig filePathConfig;

    @Override
    public ResultVO getAllKeywordResources() {
        HashSet<String> keywordUris = new HashSet<>();
        HashSet<String> keywordEnvUris = new HashSet<>();

        // get all keyword uri
        List<KeywordDO> keywordDOS = keywordDOMongodbUtils.findAll(KeywordDO.class);
        for (KeywordDO keywordDO : keywordDOS) {
            keywordUris.add(keywordDO.getUri().split("\\\\", 2)[1]);
        }

        // get all env uri
        List<KeywordEnvironmentDO> environmentDOS = keywordEnvironmentDOMongodbUtils.findAll(KeywordEnvironmentDO.class);
        for (KeywordEnvironmentDO environmentDO : environmentDOS) {
            keywordEnvUris.add(environmentDO.getUri().split("\\\\", 2)[1]);
        }

        // å�–å¹¶é›† å¾—åˆ°å�¯ä¸‹è½½çš„keyword uris
        List<String> uris = keywordUris.stream().filter(keywordEnvUris::contains).collect(Collectors.toList());
        ResultVO resultVO = new ResultVO(HttpStatus.OK);
        List<KeywordResourcesVO> result = new ArrayList<>();
        for (String uri : uris) {
            KeywordResourcesVO keywordResourcesVO = new KeywordResourcesVO();
            keywordResourcesVO.setName(uri.replace('\\', '_'));
            keywordResourcesVO.setUri(uri);
            result.add(keywordResourcesVO);
        }
        resultVO.setData(result);
        return resultVO;
    }

    @Override
    public ResultVO downloadKeywordResources(HttpServletResponse response, String[] keywordResourceNames) {
        if (keywordResourceNames==null || keywordResourceNames.length==0){
            return new ResultVO(HttpStatus.BAD_REQUEST);
        }
        List<String> srcDirs = new ArrayList<>();

        // add keyword and environment
        for (String resourceName : keywordResourceNames) {
            srcDirs.add(filePathConfig.getPath() + Constant.KEYWORD_FILE_PATH + File.separator + resourceName);
            srcDirs.add(filePathConfig.getPath() + Constant.KEYWORD_ENVIRONMENT_FILE_PATH + File.separator + resourceName);
        }

        // add dependency
        List<KeywordDependencyDO> dependencyDOS = dependencyDOMongodbUtils.findAll(KeywordDependencyDO.class);
        for (KeywordDependencyDO dependencyDO : dependencyDOS) {
            List<String> dependencyList = dependencyDO.getFileList().stream().map(FileList::getName).collect(Collectors.toList());
            for (String dependency : dependencyList) {
                srcDirs.add(filePathConfig.getPath() + dependency);
            }
        }

        String zipFileName = UUID.randomUUID().toString() + Constant.FILE_LAST_INDEXOF + Constant.ZIP_FILE_SUFFIX;
        String zipPath = filePathConfig.getPath() + zipFileName;

        try {
            FileOperationUtils.zipFile(srcDirs, zipPath);
        } catch (IOException e) {
            throw new ZipFileFailedException(Constant.FILE_ZIP_FAILED);
        }

        File file = new File(zipPath);
        response.setContentType("application/force-download");
        response.setHeader("Content-Disposition", "attachment;fileName=" + zipFileName);
        try {
            // ä»¥æµ�çš„å½¢å¼�ä¸‹è½½æ–‡ä»¶ã€‚
            byte[] buffer;
            try (InputStream fis = new BufferedInputStream(new FileInputStream(zipPath))) {
                buffer = new byte[fis.available()];
                fis.read(buffer);
            }
            // æ¸…ç©ºresponse
            response.reset();
            // è®¾ç½®responseçš„Header
            response.addHeader("Content-Disposition", "attachment;filename=" + new String(zipFileName.getBytes()));
            response.addHeader("Content-Length", "" + file.length());
            OutputStream toClient = new BufferedOutputStream(response.getOutputStream());
            response.setContentType("application/octet-stream");
            toClient.write(buffer);
            toClient.flush();
            toClient.close();
            return null;
        } catch (IOException e) {
            throw new ZipFileFailedException(Constant.FILE_ZIP_FAILED);
        } finally {
            FileOperationUtils.deleteFileOrDirectory(zipFileName, filePathConfig.getPath());
        }
    }

}
