package jp.co.brother.keywordmanageplus.service;

import jp.co.brother.keywordmanageplus.vo.KeywordDependencyVO;
import jp.co.brother.keywordmanageplus.vo.ResultVO;
import jp.co.brother.keywordmanageplus.dto.KeywordDependencyDTO;

public interface KeywordDependencyService {

    ResultVO getAllKeywordDependency();

    ResultVO getKeywordDependencyById(String keywordDependencyId);

    ResultVO insertKeywordDependency(KeywordDependencyVO keywordDependencyVO);

    ResultVO updateKeywordDependencyById(String keywordDependencyId, KeywordDependencyDTO keywordDependencyVO);

    ResultVO deleteKeywordDependencyById(String[] keywordDependencyId);

}
