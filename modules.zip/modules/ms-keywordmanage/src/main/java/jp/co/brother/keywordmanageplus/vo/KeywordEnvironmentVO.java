package jp.co.brother.keywordmanageplus.vo;


import org.springframework.web.multipart.MultipartFile;

import lombok.Data;

/**
 * 
 * @author yinse
 * 
 */
@Data
public class KeywordEnvironmentVO {
	
	/**
	 * The KeywordEnvironment version obtained by the front end;
	 */
	private String version;
	
	/**
	 * The KeywordEnvironment uri obtained by the front end;
	 */
	private String uri;
	
	/**
	 * The KeywordEnvironment file name obtained by the front end
	 */
	private String name;
	
	/**
	 * Front-end upload of the specific KeywordEnvironment file
	 */
	private MultipartFile file;
	
	/**
	 * KeywordEnvironment Description obtained by the front end
	 */
	private String description;
	
}
