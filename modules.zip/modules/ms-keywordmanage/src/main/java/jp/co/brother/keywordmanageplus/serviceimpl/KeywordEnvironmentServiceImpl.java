package jp.co.brother.keywordmanageplus.serviceimpl;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Objects;

import jp.co.brother.keywordmanageplus.utils.FileOperationUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.util.Assert;

import jp.co.brother.keywordmanageplus.config.FilePathConfig;
import jp.co.brother.keywordmanageplus.constant.Constant;
import jp.co.brother.keywordmanageplus.domain.KeywordEnvironmentDO;
import jp.co.brother.keywordmanageplus.dto.KeywordEnvironmentDTO;
import jp.co.brother.keywordmanageplus.dto.KeywordEnvironmentFileList;
import jp.co.brother.keywordmanageplus.exception.DataNotFoundException;
import jp.co.brother.keywordmanageplus.exception.FileDeleteFailedException;
import jp.co.brother.keywordmanageplus.service.KeywordEnvironmentService;
import jp.co.brother.keywordmanageplus.utils.MongodbUtils;
import jp.co.brother.keywordmanageplus.vo.KeywordEnvironmentVO;
import jp.co.brother.keywordmanageplus.vo.ResultVO;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class KeywordEnvironmentServiceImpl implements KeywordEnvironmentService {

    @Autowired
    private MongodbUtils<KeywordEnvironmentDO> mongodbUtils;

    @Autowired
    private FilePathConfig filePathConfig;

    /**
     * Gets KeywordEnvironmentData all data
     */
    @Override
    public ResultVO getKeywordEnvironmentData() {
        // Query data from the database
        List<KeywordEnvironmentDO> keywordEnvironmentDatas = mongodbUtils.findAll(KeywordEnvironmentDO.class);
        List<KeywordEnvironmentDTO> list = new ArrayList<>();

        for (KeywordEnvironmentDO keywordEnvironmentDO : keywordEnvironmentDatas) {
            if (keywordEnvironmentDO == null) {
                log.warn(Constant.DATA_DOCUMENT_INVALID);
                continue;
            }
            /* DO => POJO */
            KeywordEnvironmentDTO keywordEnviroDTO = doToDTO(keywordEnvironmentDO);
            list.add(keywordEnviroDTO);
        }
        ResultVO resultVO = new ResultVO(HttpStatus.OK);
        resultVO.setData(list);
        return resultVO;
    }

    /**
     * Get specified KeywordEnvironmentData data
     */
    @Override
    public ResultVO getKeywordEnvironmentDataById(String keywordEnvironmentId) {
        /* Check input parameter, make sure they are not null */
        Assert.notNull(keywordEnvironmentId, Constant.ASSERT_REQUEST_KEYWORDENVIRONMENTID);

        Query query = new Query();
        query.addCriteria(Criteria.where(Constant.KEYWORD_ENVIRONMENT_ID).is(keywordEnvironmentId));
        KeywordEnvironmentDO keywordEnvironmentDO = mongodbUtils.findOne(query, KeywordEnvironmentDO.class);
        ResultVO resultVO = new ResultVO(HttpStatus.OK);

        if (Objects.nonNull(keywordEnvironmentDO)) {
            KeywordEnvironmentDTO keywordEnvironmentDTO = doToDTO(keywordEnvironmentDO);

            resultVO.setData(keywordEnvironmentDTO);
        } else {
            throw new DataNotFoundException(Constant.DATA_NOTFOUND_EXCEPTION);
        }
        return resultVO;
    }

    /**
     * insert specified KeywordEnvironmentData data
     */
    @Override
    public ResultVO insertKeywordEnvironmentData(KeywordEnvironmentVO keywordEnvironmentVo) {
        /* Check input parameter, make sure they are not null */
        Assert.notNull(keywordEnvironmentVo, Constant.ASSERT_REQUEST_BODY);
        Assert.notNull(keywordEnvironmentVo.getName(), Constant.ASSERT_REQUEST_BODY_NAME);
        Assert.notNull(keywordEnvironmentVo.getVersion(), Constant.ASSERT_REQUEST_BODY_VERSION);
        Assert.notNull(keywordEnvironmentVo.getUri(), Constant.ASSERT_REQUEST_BODY_URI);
        Assert.notNull(keywordEnvironmentVo.getFile(), Constant.ASSERT_REQUEST_BODY_KEYWORDENVIRONMENTFILE);

        ResultVO resultVO = null;
        // Verify that the keyword environment has the same data(Name + URI)
        if (checkKeywordEnvironmentData(keywordEnvironmentVo)) {
            resultVO = new ResultVO(HttpStatus.CONFLICT);
            resultVO.setMessage(Constant.ALREADY_EXISTS_EXCEPTION);
            return resultVO;
        }
        if (keywordEnvironmentVo.getFile() != null) {
            // Get information about the file
            String prefix = filePathConfig.getPath();
            String uri = keywordEnvironmentVo.getUri();
            String fileName = keywordEnvironmentVo.getFile().getOriginalFilename();
            File files = new File(prefix + uri + File.separator + fileName);
            if (!files.getParentFile().exists()) {
                files.getParentFile().mkdirs();
            }

            // Determine whether the file exists
            if (!files.exists()) {
                List<String> subFiles = new ArrayList<>();
                try {
                    keywordEnvironmentVo.getFile().transferTo(files);
                    // 解压前获取子文件列表
                    subFiles = FileOperationUtils.getZipSubFiles(prefix + uri + File.separator + fileName);
                    // 解压
                    FileOperationUtils.unZipFile(prefix + uri + File.separator + fileName, prefix + uri);
                    // 删除zip 只留解压后的文件
                    FileOperationUtils.deleteFileOrDirectory(fileName, prefix + uri);
                } catch (IllegalStateException | IOException e) {
                    for (String deleteFile : subFiles) {
                        FileOperationUtils.deleteFileOrDirectory(deleteFile, prefix + uri);
                    }
                    log.warn(Constant.INSERT_DATABASE_FILE_FAIED, e.getMessage());
                    resultVO = new ResultVO(HttpStatus.INTERNAL_SERVER_ERROR);
                    resultVO.setMessage(Constant.FILE_WRITE_FAIED);
                    return resultVO;
                }
                addKeywordEnvironmentDO(keywordEnvironmentVo, files, subFiles);
                return new ResultVO(HttpStatus.OK);
            } else {
                log.warn(Constant.FILE_ALREADY_EXISTS);
                resultVO = new ResultVO(HttpStatus.CONFLICT);
                resultVO.setMessage(Constant.FILE_ALREADY_EXISTS);
                return resultVO;
            }

        } else {
            log.warn(Constant.FILE_EMPTY_FAIED);
            resultVO = new ResultVO(HttpStatus.INTERNAL_SERVER_ERROR);
            resultVO.setMessage(Constant.FILE_EMPTY_FAIED);
        }
        return resultVO;
    }

    /**
     * delete specified KeywordEnvironmentData data
     */
    @Override
    public ResultVO deleteKeywordEnvironmentData(String[] keywordEnvironmentIds) {
        /* Check input parameter, make sure they are not null */
        Assert.notEmpty(keywordEnvironmentIds, Constant.ASSERT_REQUEST_KEYWORDENVIRONMENTID);

        ResultVO resultVO = new ResultVO(HttpStatus.OK);
        List<KeywordEnvironmentDO> keywordEnvironment = getKeywordEnvironment(keywordEnvironmentIds);

        /* Make search criteria */
        Query query = new Query();
        query.addCriteria(Criteria.where(Constant.KEYWORD_ENVIRONMENT_ID).in((Object[]) keywordEnvironmentIds));
        /* Delete specified data */
        /* If the database deletion fails, the file will not be deleted */
        try {
            mongodbUtils.findAllAndRemove(query, KeywordEnvironmentDO.class);
        } catch (Exception e) {
            log.warn(Constant.DELETE_DATABASE_FAIED, e);
            resultVO = new ResultVO(HttpStatus.INTERNAL_SERVER_ERROR);
            resultVO.setMessage(Constant.DELETE_DATABASE_FAIED);
            return resultVO;
        }

        String prefix = filePathConfig.getPath();
        for (KeywordEnvironmentDO keywordEnvironmentDO : keywordEnvironment) {
            String uri = keywordEnvironmentDO.getUri();
            List<String> subFiles = keywordEnvironmentDO.getKeywordEnvironmentFileList().getSubFiles();
            for (String fileName : subFiles) {
                FileOperationUtils.deleteFileOrDirectory(fileName, prefix + uri);
            }
        }

        return resultVO;

    }

    /**
     * DO ==> DTO
     *
     * @param keywordEnvironmentDO
     * @return
     */
    public KeywordEnvironmentDTO doToDTO(KeywordEnvironmentDO keywordEnvironmentDO) {
        KeywordEnvironmentDTO keywordEnvironmentDTO = new KeywordEnvironmentDTO();
        keywordEnvironmentDTO.setId(keywordEnvironmentDO.getId());
        keywordEnvironmentDTO.setName(keywordEnvironmentDO.getName());
        keywordEnvironmentDTO.setUri(keywordEnvironmentDO.getUri());
        keywordEnvironmentDTO.setVersion(keywordEnvironmentDO.getVersion());
        keywordEnvironmentDTO.setDescription(keywordEnvironmentDO.getDescription());
        keywordEnvironmentDTO.setKeywordEnvironmentFileList(
                keywordEnvironmentDO.getKeywordEnvironmentFileList() == null ?
                        new KeywordEnvironmentFileList() : keywordEnvironmentDO.getKeywordEnvironmentFileList());

        return keywordEnvironmentDTO;
    }

    /**
     * DTO ==> DO
     *
     * @param keywordEnvironmentDTO
     * @return
     */
    public KeywordEnvironmentDO dtoToDo(KeywordEnvironmentDTO keywordEnvironmentDTO) {
        KeywordEnvironmentDO keywordEnvironmentDO = new KeywordEnvironmentDO();
        keywordEnvironmentDO.setName(keywordEnvironmentDTO.getName());
        keywordEnvironmentDO.setUri(keywordEnvironmentDTO.getUri());
        keywordEnvironmentDO.setVersion(keywordEnvironmentDTO.getVersion());
        keywordEnvironmentDO.setDescription(keywordEnvironmentDTO.getDescription());
        keywordEnvironmentDO.setKeywordEnvironmentFileList(
                keywordEnvironmentDTO.getKeywordEnvironmentFileList() == null ?
                        new KeywordEnvironmentFileList() : keywordEnvironmentDTO.getKeywordEnvironmentFileList());

        return keywordEnvironmentDO;
    }

    /**
     * Gets the data for the specified KeywordEnvironment
     *
     * @param keywordEnvironmentIds
     * @return
     */
    private List<KeywordEnvironmentDO> getKeywordEnvironment(String[] keywordEnvironmentIds) {
        Query query = new Query();
        query.addCriteria(Criteria.where(Constant.KEYWORD_ENVIRONMENT_ID).in((Object[]) keywordEnvironmentIds));
        return mongodbUtils.find(query, KeywordEnvironmentDO.class);
    }

    /**
     * Verify that the keyword environment has the same data(Name + URI)
     *
     * @param keywordEnvironmentVo
     * @return
     */
    private boolean checkKeywordEnvironmentData(KeywordEnvironmentVO keywordEnvironmentVo) {
        Query query = new Query();
        query.addCriteria(Criteria.where(Constant.KEYWORD_ENVIRONMENT_NAME).is(keywordEnvironmentVo.getName()).
                and(Constant.KEYWORD_ENVIRONMENT_URI).is(keywordEnvironmentVo.getUri()));
        return mongodbUtils.exists(query, KeywordEnvironmentDO.class);
    }

    /**
     * Add KeywordEnvironment data to database
     *
     * @param keywordEnvironmentVo
     */
    private void addKeywordEnvironmentDO(KeywordEnvironmentVO keywordEnvironmentVo, File file, List<String> subFiles) {

        // Get the front-end data to encapsulate to DTO
        KeywordEnvironmentDTO keywordEnvironmentDTO = new KeywordEnvironmentDTO();
        KeywordEnvironmentFileList keywordEnvironmentFileList = new KeywordEnvironmentFileList();
        String fileName = keywordEnvironmentVo.getFile().getOriginalFilename();
        String suffix = fileName.substring(fileName.lastIndexOf(Constant.FILE_LAST_INDEXOF) + 1);
        keywordEnvironmentFileList.setName(fileName);
        keywordEnvironmentFileList.setType(suffix);
        keywordEnvironmentFileList.setSubFiles(subFiles);
        Date now = new Date();
        SimpleDateFormat dateFormat = new SimpleDateFormat(Constant.DATEFORMAT);
        keywordEnvironmentFileList.setCreateDate(dateFormat.format(now));
        // Update the data to the database
        keywordEnvironmentDTO.setDescription(keywordEnvironmentVo.getDescription());
        keywordEnvironmentDTO.setName(keywordEnvironmentVo.getName());
        keywordEnvironmentDTO.setVersion(keywordEnvironmentVo.getVersion());
        keywordEnvironmentDTO.setUri(keywordEnvironmentVo.getUri());
        keywordEnvironmentDTO.setKeywordEnvironmentFileList(keywordEnvironmentFileList);

        try {
            /* If the database insert fails, delete the uploaded file */
            mongodbUtils.insert(dtoToDo(keywordEnvironmentDTO));
        } catch (Exception e) {
            log.warn(Constant.INSERT_DATABASE_FAILED, e);
            try {
                Files.delete(file.toPath());
            } catch (IOException e1) {
                log.warn(Constant.DELETE_FILE_FAIED, e1);
                throw new FileDeleteFailedException(Constant.DELETE_FILE_FAIED);
            }
        }
    }
}








