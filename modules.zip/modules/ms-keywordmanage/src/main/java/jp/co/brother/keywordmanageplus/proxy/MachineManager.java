package jp.co.brother.keywordmanageplus.proxy;

import jp.co.brother.keywordmanageplus.vo.ResultVO;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

@FeignClient(name = "MachineManager")
public interface MachineManager {
    @GetMapping(value = "/machine/machineInfo/{machineId}", produces = "application/json;charset=UTF-8")
    ResultVO getMachineInfoById(@PathVariable(name = "machineId") String machineId);
}
