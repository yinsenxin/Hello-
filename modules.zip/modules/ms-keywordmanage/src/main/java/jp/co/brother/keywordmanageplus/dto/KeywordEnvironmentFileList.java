package jp.co.brother.keywordmanageplus.dto;

import java.util.List;

import lombok.Data;

/**
 * 
 * @author yinse
 *
 */
@Data
public class KeywordEnvironmentFileList {
	/**
	 * The name of the KeywordEnvironmentFileList data;
	 */
	private String name;
	/**
	 * The fileList of the KeywordEnvironmentFileList data;
	 */
	private List<String> directoryList;
	/**
	 * The createDate of the KeywordEnvironmentFileList data;
	 */
	private String createDate;
	/**
	 * The description of the KeywordEnvironmentFileList data;
	 */
	private String description;
	/**
	 * The type of the KeywordEnvironmentFileList data;
	 */
	private String type;
	/**
	 * The description of the KeyWordEnvironmentDO data;
	 */
	private List<String> subFiles;
	
}






