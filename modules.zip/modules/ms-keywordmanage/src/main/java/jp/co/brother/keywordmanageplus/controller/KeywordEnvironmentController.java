package jp.co.brother.keywordmanageplus.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import jp.co.brother.keywordmanageplus.service.KeywordEnvironmentService;
import jp.co.brother.keywordmanageplus.vo.KeywordEnvironmentVO;
import jp.co.brother.keywordmanageplus.vo.ResultVO;

@RestController
@RequestMapping("/keywordEnvironments")
public class KeywordEnvironmentController {
	
	
	@Autowired
	private KeywordEnvironmentService keywordEnviroManagerService;
	
	
	@GetMapping(value = "", produces = "application/json;charset=UTF-8")
	public ResultVO getAllKeywordEnviroData() {
		
		return keywordEnviroManagerService.getKeywordEnvironmentData();
	}
	
	@GetMapping(value = "/{keywordEnvironemntId}", produces = "application/json;charset=UTF-8")
	public ResultVO getKeywordEnviroDataById(@PathVariable(required = true, name = "keywordEnvironemntId") String keywordEnvironemntId) {
		return keywordEnviroManagerService.getKeywordEnvironmentDataById(keywordEnvironemntId);
	}
	
	@PostMapping(value = "")
	public ResultVO addKeywordEnviroData(KeywordEnvironmentVO keywordEnviro) {
		return keywordEnviroManagerService.insertKeywordEnvironmentData(keywordEnviro);
	}
	
	@DeleteMapping(value = "/{keywordEnvironemntId}", produces = "application/json;charset=UTF-8")
	public ResultVO deleteKeywordEnvironmentData(@PathVariable(required = true, name = "keywordEnvironemntId") String [] keywordEnviroIds) {
		return keywordEnviroManagerService.deleteKeywordEnvironmentData(keywordEnviroIds);
	}
	
	
	
}
