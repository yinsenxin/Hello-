package jp.co.brother.keywordmanageplus.serviceimpl;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Objects;
import java.util.UUID;
import java.util.stream.Collectors;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.util.Assert;
import org.springframework.web.multipart.MultipartFile;

import com.alibaba.fastjson.JSON;

import jp.co.brother.keywordmanageplus.config.FilePathConfig;
import jp.co.brother.keywordmanageplus.constant.Constant;
import jp.co.brother.keywordmanageplus.domain.KeywordDO;
import jp.co.brother.keywordmanageplus.domain.MachineDO;
import jp.co.brother.keywordmanageplus.dto.FileList;
import jp.co.brother.keywordmanageplus.dto.KeywordDTO;
import jp.co.brother.keywordmanageplus.dto.ParamList;
import jp.co.brother.keywordmanageplus.exception.AlreadyExistsException;
import jp.co.brother.keywordmanageplus.exception.DataNotFoundException;
import jp.co.brother.keywordmanageplus.exception.FileDeleteFailedException;
import jp.co.brother.keywordmanageplus.exception.KeywordExecuteException;
import jp.co.brother.keywordmanageplus.exception.OperationDBException;
import jp.co.brother.keywordmanageplus.proxy.MachineManager;
import jp.co.brother.keywordmanageplus.service.KeywordResourcesService;
import jp.co.brother.keywordmanageplus.service.KeywordService;
import jp.co.brother.keywordmanageplus.utils.CommandUtil;
import jp.co.brother.keywordmanageplus.utils.FileOperationUtils;
import jp.co.brother.keywordmanageplus.utils.MongodbUtils;
import jp.co.brother.keywordmanageplus.vo.KeywordExecuteVO;
import jp.co.brother.keywordmanageplus.vo.KeywordResourcesVO;
import jp.co.brother.keywordmanageplus.vo.KeywordVO;
import jp.co.brother.keywordmanageplus.vo.ResultVO;
import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class KeywordServiceImpl implements KeywordService {

    @Autowired
    private MongodbUtils<KeywordDO> mongodbUtils;

    @Autowired
    private FilePathConfig filePath;

    @Autowired
    private KeywordResourcesService keywordResourcesService;

    @Autowired
    private MachineManager machineManager;

    /**
     * Gets all the data for the keyword
     */
    @Override
    public ResultVO getAllKeywordData(String modelId) {
        ResultVO resultVO;
        List<KeywordDTO> list = new ArrayList<>();
        //Gets all keyword Data
        List<KeywordDO> keywordDatas;
        if (StringUtils.isNotBlank(modelId)) {
            String modelUri = getModelUriByModelId(modelId);
            if (modelUri == null) {
                return new ResultVO(HttpStatus.BAD_REQUEST);
            }
            Query query = new Query();
            query.addCriteria(Criteria.where(Constant.KEYWORD_URI).is(Constant.KEYWORD_FILE_PATH + File.separator + modelUri));
            keywordDatas = mongodbUtils.find(query, KeywordDO.class);
        } else {
            keywordDatas = mongodbUtils.findAll(KeywordDO.class);
        }

        for (KeywordDO keywordDO : keywordDatas) {
            if (Objects.isNull(keywordDO)) {
                log.info(Constant.DATA_DOCUMENT_INVALID);
                continue;
            }
            /* DO => POJO */
            KeywordDTO keywordDTO = doToDTO(keywordDO);
            List<FileList> fileList = keywordDTO.getFileList();
            for (FileList files : fileList) {
                files.setContent(null);
            }
            keywordDTO.setFileList(fileList);
            list.add(keywordDTO);
        }
        resultVO = new ResultVO(HttpStatus.OK);
        resultVO.setData(list);
        return resultVO;
    }

    /**
     * Gets the specified keyword  by keywordId
     */
    @Override
    public ResultVO getKeywordDataById(String keywordId) {
        /* Check input parameter, make sure they are not null */
        Assert.notNull(keywordId, Constant.ASSERT_REQUEST_KEYWORDID);

        ResultVO resultVO = new ResultVO(HttpStatus.OK);
        /* Make search criteria */
        Query query = new Query();
        query.addCriteria(Criteria.where(Constant.KEYWORD_ID).is(keywordId));
        //Query data from the database
        KeywordDO keywordDo = mongodbUtils.findOne(query, KeywordDO.class);
        if (Objects.nonNull(keywordDo)) {
            //DO --> POJO
            KeywordDTO keywordDTO = doToDTO(keywordDo);
            resultVO.setData(keywordDTO);
        } else {
            throw new DataNotFoundException(Constant.DATA_NOTFOUND_EXCEPTION);
        }
        return resultVO;
    }

    /**
     * Add new keyword data
     */
    @Override
    public ResultVO insertKeywordData(KeywordVO keywordVo) {
        /* Check input parameter, make sure they are not null */
        Assert.notNull(keywordVo, Constant.ASSERT_REQUEST_BODY);
        Assert.notNull(keywordVo.getName(), Constant.ASSERT_REQUEST_BODY_KEYWORDNAME);
        Assert.notNull(keywordVo.getType(), Constant.ASSERT_REQUEST_BODY_KEYWORDTYPE);
        Assert.notNull(keywordVo.getVersion(), Constant.ASSERT_REQUEST_BODY_KEYWORDVERSION);
        Assert.notNull(keywordVo.getStatus(), Constant.ASSERT_REQUEST_BODY_KEYWORDSTATUS);
        Assert.notNull(keywordVo.getUri(), Constant.ASSERT_REQUEST_BODY_KEYWORDURI);
        Assert.notNull(keywordVo.getFile(), Constant.ASSERT_REQUEST_BODY_KEYWORDFILELIST);

        ResultVO resultVO = null;
        // Verify that the keyword has the same data
        if (checkKeywordData(keywordVo)) {
            resultVO = new ResultVO(HttpStatus.CONFLICT);
            resultVO.setMessage(Constant.ALREADY_EXISTS_EXCEPTION);
            return resultVO;
        }
        // Gets MultipartFile  Data
        List<MultipartFile> fileList = keywordVo.getFile();
        List<FileList> lists = new ArrayList<>();
        if (fileList != null) {
            String prefix = filePath.getPath();
            String uri = keywordVo.getUri();
            List<File> list = new ArrayList<>();
            File file = new File(prefix + uri);
            //If the folder does not exist, it is created
            if (!file.exists()) {
                file.mkdirs();
            }
            List<String> oldFile = getFileName(file);
            List<String> newFile = new ArrayList<>();
            // Determine if the file exists
            for (MultipartFile files : fileList) {
                newFile.add(files.getOriginalFilename());
            }

            // Verify that you have the same file
            if (!Collections.disjoint(oldFile, newFile)) {
                log.warn(Constant.FILE_ALREADY_EXISTS);
                resultVO = new ResultVO(HttpStatus.CONFLICT);
                resultVO.setMessage(Constant.FILE_ALREADY_EXISTS);
                return resultVO;
            }

            //Get the specific file information, save to the specified directory
            for (MultipartFile multipartFile : fileList) {
                String fileName = multipartFile.getOriginalFilename();
                File files = new File(prefix + uri + File.separator + fileName);
                try {
                    multipartFile.transferTo(files);
                    getFileListContent(fileName, lists, files);
                    list.add(files);
                } catch (IllegalStateException | IOException e) {
                    // When a file exception is written, delete it
                    deleteWriterFailedFile(newFile, prefix + uri);
                    log.warn(Constant.INSERT_DATABASE_FILE_FAIED, e.getMessage());
                    resultVO = new ResultVO(HttpStatus.INTERNAL_SERVER_ERROR);
                    resultVO.setMessage(Constant.FILE_WRITE_FAIED);
                    return resultVO;
                }
            }
            //Inserts data into the database
            addKeywordData(keywordVo, list, lists);
            return new ResultVO(HttpStatus.OK);
        } else {
            log.warn(Constant.FILE_EMPTY_FAIED);
            resultVO = new ResultVO(HttpStatus.INTERNAL_SERVER_ERROR);
            resultVO.setMessage(Constant.FILE_EMPTY_FAIED);
        }
        return resultVO;

    }

    /**
     * Gets the specified keyword  by keywordId
     */
    @Override
    public KeywordDTO getKeywordDTODataByKeywordId(String keywordId) {
        /* Check input parameter, make sure they are not null */
        Assert.notNull(keywordId, Constant.ASSERT_REQUEST_KEYWORDID);
        KeywordDTO keywordDTO = null;
        /* Make search criteria */
        Query query = new Query();
        query.addCriteria(Criteria.where(Constant.KEYWORD_ID).is(keywordId));
        //Query data from the database
        KeywordDO keywordDo = mongodbUtils.findOne(query, KeywordDO.class);
        if (Objects.nonNull(keywordDo)) {
            //DO --> POJO
            keywordDTO = doToDTO(keywordDo);
        } else {
            throw new DataNotFoundException(Constant.DATA_NOTFOUND_EXCEPTION);
        }
        return keywordDTO;
    }

    @Override
    public ResultVO executeKeyword(KeywordExecuteVO keywordExecuteVO) {

        // check the machineId
        if (keywordExecuteVO == null || StringUtils.isBlank(keywordExecuteVO.getMachineId()) ||
                (StringUtils.isBlank(keywordExecuteVO.getKeywordName()) && StringUtils.isBlank(keywordExecuteVO.getKeywordId()))) {
            return new ResultVO(HttpStatus.BAD_REQUEST);
        }

        ResultVO machineInfo;
        try {
            machineInfo = machineManager.getMachineInfoById(keywordExecuteVO.getMachineId());
            if (machineInfo.getCode() != HttpStatus.OK.value()) {
                throw new DataNotFoundException();
            }
        } catch (Exception e) {
            throw new DataNotFoundException(Constant.MACHINE_NOT_FOUND_EXCEPTION);
        }

        ResultVO resultVO = new ResultVO(HttpStatus.OK);

        KeywordDO keywordDo = getKeywordDO(keywordExecuteVO, machineInfo);
        if (Objects.isNull(keywordDo)) {
            throw new DataNotFoundException(Constant.KEYWORD_NOT_FOUND_EXCEPTION);
        }

        // execute
        List<FileList> pyFile = keywordDo.getFileList().stream().filter(fileList -> fileList.getName().endsWith((Constant.FILE_SUFFIX))).collect(Collectors.toList());
        if (pyFile.isEmpty()) {
            throw new DataNotFoundException(Constant.DATA_NOTFOUND_EXCEPTION);
        }
        StringBuilder command = new StringBuilder(Constant.FILETYPE + Constant.ONE_SPACE);
        command.append(filePath.getPath()).append(keywordDo.getUri()).append(File.separator).append(pyFile.get(0).getName());
        command.append(Constant.ONE_SPACE).append(keywordExecuteVO.getMachineId());
        if (keywordExecuteVO.getParamList() != null && !keywordExecuteVO.getParamList().isEmpty()) {
            for (String param : keywordExecuteVO.getParamList()) {
                command.append(Constant.ONE_SPACE).append(param);
            }
        }
        try {
            CommandUtil.ExecuteResult result = CommandUtil.executeCommand(command.toString().replace('/', '\\'));
            resultVO.setData(result);
            return resultVO;
        } catch (Exception e) {
            throw new KeywordExecuteException(Constant.KEYWORD_EXECUTE_FAILED);
        }
    }

    private KeywordDO getKeywordDO(KeywordExecuteVO keywordExecuteVO, ResultVO machineInfo) {
        if (StringUtils.isNotBlank(keywordExecuteVO.getKeywordId())) {
            //Query data from the database
            Query query = new Query();
            query.addCriteria(Criteria.where(Constant.KEYWORD_ID).is(keywordExecuteVO.getKeywordId()));
            return mongodbUtils.findOne(query, KeywordDO.class);
        } else if (StringUtils.isNotBlank(keywordExecuteVO.getKeywordName())) {
            if (StringUtils.isNotBlank(keywordExecuteVO.getUri())) {
                // get by uri and name
                Query query = new Query();
                query.addCriteria(Criteria.where(Constant.KEYWORD_URI).is(keywordExecuteVO.getUri()));
                query.addCriteria(Criteria.where(Constant.KEYWORD_NAME).is(keywordExecuteVO.getKeywordName()));
                return mongodbUtils.findOne(query, KeywordDO.class);
            } else {
                // get by machineId and name
                // get model
                String modelId = JSON.parseObject(JSON.toJSONString(machineInfo.getData()), MachineDO.class).getModelId();
                if (StringUtils.isBlank(modelId)) {
                    throw new DataNotFoundException(Constant.MODEL_NOT_FOUND_EXCEPTION);
                }
                // get uri
                String modelUri = getModelUriByModelId(modelId);
                // get keyword
                Query query = new Query();
                query.addCriteria(Criteria.where(Constant.KEYWORD_URI).is(Constant.KEYWORD_FILE_PATH + File.separator + modelUri));
                query.addCriteria(Criteria.where(Constant.KEYWORD_NAME).is(keywordExecuteVO.getKeywordName()));
                return mongodbUtils.findOne(query, KeywordDO.class);
            }
        } else {
            return null;
        }
    }

    /**
     * Update the keyword data
     */
    @Override
    public ResultVO updateKeywordData(String keywordId, KeywordDTO keywordNewDTO, KeywordDTO keywordOldDTO) {
        /* Check input parameter, make sure they are not null */
        Assert.notNull(keywordNewDTO, Constant.ASSERT_REQUEST_BODY);
        Assert.notNull(keywordId, Constant.ASSERT_REQUEST_KEYWORDID);
        Assert.notNull(keywordNewDTO.getName(), Constant.ASSERT_REQUEST_BODY_KEYWORDNAME);
        Assert.notNull(keywordNewDTO.getType(), Constant.ASSERT_REQUEST_BODY_KEYWORDTYPE);
        Assert.notNull(keywordNewDTO.getVersion(), Constant.ASSERT_REQUEST_BODY_KEYWORDVERSION);
        Assert.notNull(keywordNewDTO.getStatus(), Constant.ASSERT_REQUEST_BODY_KEYWORDSTATUS);
        Assert.notNull(keywordNewDTO.getUri(), Constant.ASSERT_REQUEST_BODY_KEYWORDURI);
        Assert.notNull(keywordNewDTO.getFileList(), Constant.ASSERT_REQUEST_BODY_KEYWORDFILELIST);

        Query query = new Query();
        query.addCriteria(Criteria.where(Constant.KEYWORD_ID).is(keywordId));

        KeywordDO keyword = dtoToDo(keywordNewDTO);
        if (mongodbUtils.exists(query, KeywordDO.class)) {
            Query query2 = new Query();
            query2.addCriteria(Criteria.where(Constant.KEYWORD_NAME).is(keywordNewDTO.getName()).and(Constant.KEYWORD_ID).is(keywordId));
            if (!mongodbUtils.exists(query2, KeywordDO.class)) {
                throw new DataNotFoundException(Constant.BADREQUEST_UPDATE_KEYWORDNAME);
            }
            List<File> files = replaceKeywordData(keywordNewDTO, keywordOldDTO);
            replaceOldRecord(keywordId, keyword, files);
            return new ResultVO(HttpStatus.OK);
        } else {
            throw new DataNotFoundException(Constant.DATA_NOTFOUND_EXCEPTION);
        }

    }

    /**
     * Delete the specified keyword data by keywordIds
     */
    @Override
    public ResultVO deleteKeywordData(String[] keywordIds) {
        /* Check input parameter, make sure they are not null */
        Assert.notEmpty(keywordIds, Constant.ASSERT_REQUEST_KEYWORDID);

        ResultVO resultVO = null;
        List<KeywordDTO> keywordDTO = getKeyword(keywordIds);
        /* Make search criteria */
        Query query = new Query();
        query.addCriteria(Criteria.where(Constant.KEYWORD_ID).in((Object[]) keywordIds));
        /* Delete specified data */
        /* If the database deletion fails, the file will not be deleted */
        try {
            mongodbUtils.findAllAndRemove(query, KeywordDO.class);
        } catch (Exception e) {
            log.warn(Constant.DELETE_DATABASE_FAIED, e);
            resultVO = new ResultVO(HttpStatus.INTERNAL_SERVER_ERROR);
            resultVO.setMessage(Constant.DELETE_DATABASE_FAIED);
            return resultVO;
        }

        String prefix = filePath.getPath();
        for (KeywordDTO keyword : keywordDTO) {
            List<FileList> fileList = keyword.getFileList();
            String uri = keyword.getUri();

            for (FileList file : fileList) {
                String fileName = file.getName();

                File file2 = new File(prefix + uri + File.separator + fileName);
                try {
                    if (file2.exists()) {
                        Files.delete(file2.toPath());
                    }
                } catch (Exception e) {
                    log.warn(Constant.DELETE_DATABASE_FILE_FAIED, e);
                    resultVO = new ResultVO(HttpStatus.INTERNAL_SERVER_ERROR);
                    resultVO.setMessage(Constant.FILE_DELETE_FAIED);
                    return resultVO;
                }
            }
        }

        return new ResultVO(HttpStatus.OK);
    }

    /**
     * Delete writer failed file
     *
     * @param list
     * @param path
     */
    private void deleteWriterFailedFile(List<String> list, String path) {
        for (String fileName : list) {
            File file = new File(path + File.separator + fileName);
            try {
                Files.delete(file.toPath());
            } catch (IOException e) {
                throw new FileDeleteFailedException(Constant.FILE_DELETE_FAIED);
            }
        }
    }

    /**
     * Gets specified File name
     *
     * @param uri
     * @return
     */
    private List<String> getFileName(File file) {
        List<String> list = new ArrayList<>();
        // get the folder list
        File[] array = file.listFiles();

        for (int i = 0; i < array.length; i++) {
            if (array[i].isFile()) {
                list.add(array[i].getName());
            }
        }
        return list;
    }

    /**
     * Gets file content --> fileList
     *
     * @param fileName
     * @param list
     * @param files
     */
    private void getFileListContent(String fileName, List<FileList> list, File files) {
        // Date format
        Date now = new Date();
        SimpleDateFormat dateFormat = new SimpleDateFormat(Constant.DATEFORMAT);
        // Get file content
        String string = FileOperationUtils.file2String(files, Constant.FILE_ENCODER);
        FileList fileList = new FileList();
        fileList.setId(UUID.randomUUID().toString());
        fileList.setCreateDate(dateFormat.format(now));
        fileList.setLastModifyDate(dateFormat.format(now));
        fileList.setName(fileName);
        String suffix = fileName.
                substring(fileName.lastIndexOf(Constant.FILE_LAST_INDEXOF) + 1);
        fileList.setType(suffix);
        if (suffix.equals(Constant.FILE_SUFFIX)) {
            fileList.setType(Constant.FILETYPE);
        }
        fileList.setContent(string);
        list.add(fileList);

    }

    /**
     * @param keywordDTOS
     * @param resultVO
     * @return
     */
    private List<File> replaceKeywordData(KeywordDTO keywordNewDTO, KeywordDTO keywordOldDTO) {

        // Gets KeywordOldDTO data, delete it
        String uri = keywordOldDTO.getUri();
        List<FileList> fileList = keywordOldDTO.getFileList();
        for (FileList files : fileList) {
            String name = files.getName();
            File file = new File(filePath.getPath() + uri + File.separator + name);
            try {
                if (file.exists()) {
                    Files.delete(file.toPath());
                }
            } catch (Exception e) {
                log.warn(Constant.UPDATE_DATABASE_FILE_FAIED, e);
                throw new OperationDBException(Constant.UPDATE_DATABASE_KEYWORD);
            }
        }
        // get new file
        String uri2 = keywordNewDTO.getUri();
        List<FileList> fileList2 = keywordNewDTO.getFileList();
        // old file path 
        File files = new File(filePath.getPath() + uri2);
        List<String> oldFile = getFileName(files);
        List<String> newFile = new ArrayList<>();

        // Store the modified file
        List<File> newFileList = new ArrayList<>();
        List<String> contentList = new ArrayList<>();
        for (FileList fileList3 : fileList2) {
            String name = fileList3.getName();
            String content = fileList3.getContent();
            File file = new File(filePath.getPath() + uri2 + File.separator + name);
            newFile.add(name);
            newFileList.add(file);
            contentList.add(content);
        }
        // Determine if the file exists
        if (!Collections.disjoint(oldFile, newFile)) {
            log.warn(Constant.FILE_ALREADY_EXISTS);
            throw new AlreadyExistsException(Constant.FILE_ALREADY_EXISTS);
        }

        for (int i = 0; i < newFileList.size(); i++) {
            FileOperationUtils.string2File(contentList.get(i), newFileList.get(i));
        }
        return newFileList;

    }

    /**
     * DTO --> DO
     *
     * @param keywordDTO
     * @return
     */
    private KeywordDO dtoToDo(KeywordDTO keywordDTO) {

        KeywordDO keywordDO = new KeywordDO();
        keywordDO.setName(keywordDTO.getName());
        keywordDO.setType(keywordDTO.getType());
        keywordDO.setStatus(keywordDTO.getStatus());
        keywordDO.setVersion(keywordDTO.getVersion());
        keywordDO.setDescription(keywordDTO.getDescription());
        keywordDO.setUri(keywordDTO.getUri());
        keywordDO.setFileList(keywordDTO.getFileList() == null ? new ArrayList<>() : keywordDTO.getFileList());
        keywordDO.setParamList(keywordDTO.getParamList() == null ? new ArrayList<>() : keywordDTO.getParamList());
        return keywordDO;
    }


    /**
     * DO --> DTO
     *
     * @param keywordDO
     * @return
     */
    private KeywordDTO doToDTO(KeywordDO keywordDO) {

        KeywordDTO keywordDTO = new KeywordDTO();
        keywordDTO.setId(keywordDO.getId());
        keywordDTO.setName(keywordDO.getName());
        keywordDTO.setType(keywordDO.getType());
        keywordDTO.setStatus(keywordDO.getStatus());
        keywordDTO.setVersion(keywordDO.getVersion());
        keywordDTO.setDescription(keywordDO.getDescription());
        keywordDTO.setUri(keywordDO.getUri());
        keywordDTO.setFileList(keywordDO.getFileList() == null ? new ArrayList<>() : keywordDO.getFileList());
        keywordDTO.setParamList(keywordDO.getParamList() == null ? new ArrayList<>() : keywordDO.getParamList());
        return keywordDTO;
    }

    /**
     * Replace the old data with the new data.(Which means the old data is exist)
     *
     * @param oldKeywordId
     * @param keyword
     */
    private void replaceOldRecord(String oldKeywordId, KeywordDO keyword, List<File> files) {
        Query query = new Query();
        query.addCriteria(Criteria.where(Constant.KEYWORD_ID).is(oldKeywordId));
        Update update = new Update();
        update.set(Constant.KEYWORD_NAME, keyword.getName());
        update.set(Constant.KEYWORD_TYPE, keyword.getType());
        update.set(Constant.KEYWORD_STATUS, keyword.getStatus());
        update.set(Constant.KEYWORD_VERSION, keyword.getVersion());
        update.set(Constant.KEYWORD_URI, keyword.getUri());
        update.set(Constant.KEYWORD_DESCRIPTION, keyword.getDescription());
        update.set(Constant.KEYWORD_PARAMLIST, keyword.getParamList());
        update.set(Constant.KEYWORD_FILELIST, keyword.getFileList());
        try {
            mongodbUtils.upsert(query, update, KeywordDO.class);
        } catch (Exception e) {
            log.warn(Constant.UPDATE_DATABASE_FAILED);
            try {
                for (File file2 : files) {
                    Files.delete(file2.toPath());
                }
            } catch (IOException e1) {
                log.warn(Constant.DELETE_FILE_FAIED, e1);
                throw new FileDeleteFailedException(Constant.DELETE_FILE_FAIED);
            }
        }
    }

    /**
     * Gets the data for the specified Keyword
     *
     * @param keywordIds
     * @return
     */
    private List<KeywordDTO> getKeyword(String[] keywordIds) {
        Query query = new Query();
        query.addCriteria(Criteria.where(Constant.KEYWORD_ID).in((Object[]) keywordIds));

        List<KeywordDO> find = mongodbUtils.find(query, KeywordDO.class);
        List<KeywordDTO> list = new ArrayList<>();
        for (KeywordDO keywordDO : find) {
            if (Objects.nonNull(keywordDO)) {
                KeywordDTO keywordDTO = doToDTO(keywordDO);
                list.add(keywordDTO);
            }
        }
        return list;
    }

    /**
     * Verify that the keyword has the same data
     *
     * @param keywordEnvironmentVo
     * @return
     */
    private boolean checkKeywordData(KeywordVO keywordVO) {
        Query query = new Query();
        query.addCriteria(Criteria.where(Constant.KEYWORD_NAME).is(keywordVO.getName()).and(Constant.KEYWORD_URI).is(keywordVO.getUri()));
        return mongodbUtils.exists(query, KeywordDO.class);
    }

    /**
     * Add Keyword data to database
     *
     * @param keywordVo
     */
    private void addKeywordData(KeywordVO keywordVo, List<File> files, List<FileList> list) {
        //Get keywordVo data
        String name = keywordVo.getName();
        String type = keywordVo.getType();
        String status = keywordVo.getStatus();
        String uri = keywordVo.getUri();
        String version = keywordVo.getVersion();
        List<ParamList> param = keywordVo.getParam();
        String description = keywordVo.getDescription();

        //Set keywordVO data to keywordDTO  
        KeywordDTO keywordDTO = new KeywordDTO();
        keywordDTO.setName(name);
        keywordDTO.setType(type);
        keywordDTO.setStatus(status);
        keywordDTO.setUri(uri);
        keywordDTO.setVersion(version);
        keywordDTO.setDescription(description);
        keywordDTO.setParamList(param);
        keywordDTO.setFileList(list);

        try {
            /* insert keywordDO data to database */
            mongodbUtils.insert(dtoToDo(keywordDTO));
            /* If the database insert fails, delete the uploaded file */
        } catch (Exception e) {
            log.warn(Constant.INSERT_DATABASE_FAILED, e);
            try {
                for (File file2 : files) {
                    Files.delete(file2.toPath());
                }
            } catch (IOException e1) {
                log.warn(Constant.DELETE_FILE_FAIED, e1);
                throw new FileDeleteFailedException(Constant.DELETE_FILE_FAIED);
            }
        }
    }


    @SuppressWarnings("unchecked")
    private String getModelUriByModelId(String modelId) {
        List<KeywordResourcesVO> resourcesVOList = (List<KeywordResourcesVO>) keywordResourcesService.getAllKeywordResources().getData();
        for (KeywordResourcesVO resources : resourcesVOList) {
            if (modelId.startsWith(resources.getName())) {
                return resources.getUri();
            }
        }
        return null;
    }

}
