package jp.co.brother.keywordmanageplus.domain;


import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.Field;

import jp.co.brother.keywordmanageplus.dto.KeywordEnvironmentFileList;
import lombok.Data;

@Data
@Document(collection = "keyword_environment")
public class KeywordEnvironmentDO {
	
	/**
     * The unique ID of the KeywordEnvironmentDO data.
     */
	@Id
	private String id;
	/**
	 * The keyWordEnviroId of the KeyWordEnvironmentDO data;
	 */
	@Field("name")
	private String name;
	/**
	 * The version of the KeyWordEnvironmentDO data;
	 */
	@Field("version")
	private String version;
	/**
	 * The uri of the KeyWordEnvironmentDO data;
	 */
	@Field("uri")
	private String uri;
	/**
	 * The fileEnviro of the KeywordEnvironmentDO data;
	 */
	@Field("file")
	private KeywordEnvironmentFileList keywordEnvironmentFileList;
	/**
	 * The description of the KeyWordEnvironmentDO data;
	 */
	@Field("description")
	private String description;
}
