package jp.co.brother.keywordmanageplus.controller;

import jp.co.brother.keywordmanageplus.vo.KeywordExecuteVO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import jp.co.brother.keywordmanageplus.dto.KeywordDTO;
import jp.co.brother.keywordmanageplus.service.KeywordService;
import jp.co.brother.keywordmanageplus.vo.KeywordVO;
import jp.co.brother.keywordmanageplus.vo.ResultVO;

@RestController
@RequestMapping("/keywords")
public class KeywordController {

    @Autowired
    private KeywordService keywordService;

    @GetMapping(value = "", produces = "application/json;charset=UTF-8")
    public ResultVO getKeywordDatas(@RequestParam(name = "modelId", required = false) String modelId) {

        return keywordService.getAllKeywordData(modelId);
    }

    @GetMapping(value = "/{keywordId}", produces = "application/json;charset=UTF-8")
    public ResultVO getKeywordDataById(@PathVariable(name = "keywordId", required = true) String keywordId) {

        return keywordService.getKeywordDataById(keywordId);
    }

    @PostMapping(value = "")
    public ResultVO insertKeywordData(KeywordVO keywordVo) {
        return keywordService.insertKeywordData(keywordVo);

    }

    @PutMapping(value = "/{keywordId}", produces = "application/json;charset=UTF-8")
    public ResultVO updateKeywordData(@PathVariable(name = "keywordId", required = true) String keywordId,
                                      @RequestBody KeywordDTO keywordNewDTO) {
        KeywordDTO keywordOldDTO = keywordService.getKeywordDTODataByKeywordId(keywordId);
        return keywordService.updateKeywordData(keywordId, keywordNewDTO, keywordOldDTO);
    }

    @DeleteMapping(value = "/{keywordId}", produces = "application/json;charset=UTF-8")
    public ResultVO deleteKeywordData(@PathVariable(name = "keywordId", required = true) String[] keywordIds) {

        return keywordService.deleteKeywordData(keywordIds);
    }

    @PostMapping(value = "/execute", produces = "application/json;charset=UTF-8")
    public ResultVO executeKeyword(@RequestBody KeywordExecuteVO keywordExecuteVO) {
        return keywordService.executeKeyword(keywordExecuteVO);
    }

}
