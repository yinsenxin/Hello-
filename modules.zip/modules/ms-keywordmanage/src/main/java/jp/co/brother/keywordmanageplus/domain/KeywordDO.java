package jp.co.brother.keywordmanageplus.domain;

import java.util.List;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import org.springframework.data.mongodb.core.mapping.Field;

import jp.co.brother.keywordmanageplus.dto.FileList;
import jp.co.brother.keywordmanageplus.dto.ParamList;
import lombok.Data;

@Data
@Document(collection = "keyword")
public class KeywordDO {
	
	/**
	 * The unique ID of the group data.
	 */
	@Id
	private String id;
	/**
	 * The name of the KeyWordDO data;
	 */
	@Field("name")
	private String name;
	/**
	 * The type of the KeyWordDO data;
	 */
	@Field("type")
	private String type;
	/**
	 * The version of the KeyWordDO data;
	 */
	@Field("version")
	private String version;
	/**
	 * The uri of the KeyWordDO data;
	 */
	@Field("uri")
	private String uri;
	/**
	 * The status of the KeyWordDO data;
	 */
	@Field("status")
	private String status;
	/**
	 * The fileList of the KeyWordDO data;
	 */
	@Field("file_list")
	private List<FileList> fileList;
	/**
	 * The paramList of the KeyWordDO data;
	 */
	@Field("param_list")
	private List<ParamList> paramList;
	/**
	 * The description of the KeyWordDO data;
	 */
	@Field("description")
	private String description;
}
