package jp.co.brother.keywordmanageplus.utils;

import java.io.*;
import java.util.ArrayList;
import java.util.List;
import java.util.zip.ZipEntry;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.UUID;
import java.util.zip.ZipInputStream;
import java.util.zip.ZipOutputStream;

import org.apache.commons.io.FileUtils;

import jp.co.brother.keywordmanageplus.dto.FileList;
import jp.co.brother.keywordmanageplus.exception.FileDeleteFailedException;
import jp.co.brother.keywordmanageplus.exception.UnZipFileFailedException;
import org.springframework.stereotype.Component;

import jp.co.brother.keywordmanageplus.constant.Constant;
import jp.co.brother.keywordmanageplus.exception.FileToStringException;
import jp.co.brother.keywordmanageplus.exception.StringToFileException;
import lombok.extern.slf4j.Slf4j;

/**
 * @author yinse
 */
@Component
@Slf4j
public class FileOperationUtils {

    private FileOperationUtils() {
    }

    private static final int BUFFER_SIZE = 2 * 1024;

    /**
     * Deletes an empty folder in the specified directory
     *
     * @param file
     */
    public static void clear(File file) {

        File[] listFiles = file.listFiles();
        for (File file2 : listFiles) {

            if (file2.isDirectory()) {
                clear(file2);
            }
        }
        try {
            Files.delete(file.toPath());
            if (file.getParentFile().isDirectory() && file.getParentFile().listFiles().length <= 0) {
                Files.delete(file.getParentFile().toPath());
            }
        } catch (IOException e) {
            log.warn(Constant.DELETE_FILE_FAIED, e);
        }
    }

    /**
     * Read the file as a memory string, keeping the file's original newline format
     *
     * @param file
     * @param charset
     * @return
     */
    public static String file2String(File file, String charset) {
        StringBuilder sb = new StringBuilder();

        try (LineNumberReader reader = new LineNumberReader(
                new BufferedReader(new InputStreamReader(new FileInputStream(file), charset)))) {
            String line;
            while ((line = reader.readLine()) != null) {
                sb.append(line).append(System.getProperty("line.separator"));
            }

        } catch (IOException e) {
            log.warn(Constant.FILE_TO_STRING, e);
            throw new FileToStringException(Constant.FILE_TO_STRING);
        }

        return sb.toString();
    }


    /**
     * Stores a string as a file, automatically creates the file when it doesn't exist,
     * overwrites the file when it already exists, and, in certain cases, relates to operating system permissions.
     *
     * @param text     String
     * @param distFile The stored target file
     * @return Returns true when the storage is correct, or false otherwise
     */
    public static boolean string2File(String text, File distFile) {
        if (!distFile.getParentFile().exists())
            distFile.getParentFile().mkdirs();
        boolean flag = true;
        try {
            FileUtils.writeStringToFile(distFile, text, StandardCharsets.UTF_8);
        } catch (IOException e) {
            flag = false;
            log.warn(Constant.STRING_TO_FILE, e);
            throw new StringToFileException(Constant.STRING_TO_FILE);
        }
        return flag;
    }

    public static List<String> listFiles(File file) {
        List<String> list = new ArrayList<>();
        File[] array = file.listFiles();
        if (array == null || array.length == 0) {
            return list;
        }
        for (File value : array) {
            if (value.isFile()) {
                list.add(value.getName());
            }
        }
        return list;
    }

    public static List<String> listFileAndDirectory(File file) {
        List<String> list = new ArrayList<>();
        File[] array = file.listFiles();
        if (array == null || array.length == 0) {
            return list;
        }
        for (File value : array) {
            if (value.isFile() || value.isDirectory()) {
                list.add(value.getName());
            }
        }
        return list;
    }

    /**
     * check the folder , if not exists , create it
     *
     * @param folder 文件夹
     */
    public static void checkFolder(File folder) {
        if (!folder.exists()) {
            folder.mkdirs();
        }
    }

    /**
     * 获取FileList对象
     *
     * @param fileName 文件名
     * @param file     文件
     * @return FileList
     */
    public static FileList getFileListContent(String fileName, File file) {
        Date now = new Date();
        SimpleDateFormat dateFormat = new SimpleDateFormat(Constant.DATEFORMAT);
        // Get file content
        String string = file2String(file, Constant.FILE_ENCODER);
        FileList fileList = new FileList();
        fileList.setId(UUID.randomUUID().toString());
        fileList.setCreateDate(dateFormat.format(now));
        fileList.setLastModifyDate(dateFormat.format(now));
        fileList.setName(fileName);
        String suffix = fileName.substring(fileName.lastIndexOf(Constant.FILE_LAST_INDEXOF) + 1);
        fileList.setType(suffix);
        if (suffix.equals(Constant.FILE_SUFFIX)) {
            fileList.setType(Constant.FILETYPE);
        }
        fileList.setContent(string);
        return fileList;
    }

    /**
     * delete file
     *
     * @param fileName fileName
     * @param path     path
     */
    public static void deleteFileOrDirectory(String fileName, String path) {
        String filePath = path + File.separator + fileName;
        File file = new File(filePath);
        try {
            if (file.isFile()) {
                Files.delete(file.toPath());
            } else if (file.isDirectory()) {
                List<String> fileList = listFileAndDirectory(file);
                for (String innerFileName : fileList) {
                    deleteFileOrDirectory(innerFileName, filePath);
                }
                file.delete();
            }
        } catch (IOException e) {
            throw new FileDeleteFailedException(Constant.FILE_DELETE_FAIED);
        }
    }

    /**
     * 解压zip文件
     *
     * @param zipPath zip文件路径 D:\test\a.zip
     * @param outDir  解压到哪个文件夹路径 D:\test
     */
    public static void unZipFile(String zipPath, String outDir) {
        try (ZipInputStream zipInputStream = new ZipInputStream(new FileInputStream(zipPath), StandardCharsets.UTF_8)) {
            BufferedInputStream bufferedInputStream = new BufferedInputStream(zipInputStream);
            File file;
            ZipEntry entry;

            while ((entry = zipInputStream.getNextEntry()) != null && !entry.isDirectory()) {
                file = new File(outDir, entry.getName());
                if (!file.exists()) {
                    (new File(file.getParent())).mkdirs();
                }
                try (FileOutputStream out = new FileOutputStream(file)) {
                    BufferedOutputStream bufferedOutputStream = new BufferedOutputStream(out);
                    int b;
                    while ((b = bufferedInputStream.read()) != -1) {
                        bufferedOutputStream.write(b);
                    }
                    bufferedOutputStream.close();
                }
            }
            bufferedInputStream.close();
        } catch (IOException e) {
            throw new UnZipFileFailedException();
        }
    }

    /**
     * 获取zip文件内的文件及文件夹名
     *
     * @param path 路径
     * @return List<String> 子文件名list
     * @throws IOException IOException
     */
    public static List<String> getZipSubFiles(String path) throws IOException {
        ZipEntry zipEntry = null;
        File file = new File(path);
        List<String> zipSubFiles = new ArrayList<>();
        if (file.exists()) {
            try (ZipInputStream zipInputStream = new ZipInputStream(new FileInputStream(path), StandardCharsets.UTF_8)) {
                while ((zipEntry = zipInputStream.getNextEntry()) != null) {
                    if (zipEntry.getName().contains("/")) {
                        String directoryName = zipEntry.getName().split("/")[0];
                        if (!zipSubFiles.contains(directoryName))
                            zipSubFiles.add(directoryName);
                    } else {
                        zipSubFiles.add(zipEntry.getName());
                    }
                }
            }
        }
        return zipSubFiles;
    }


    /**
     * 压缩文件为zip
     *
     * @param srcDirs 压缩文件来源 ["path\\Desktop\\java",
     *                "path\\Desktop\\java2",
     *                "path\\Desktop\\test.txt"]
     * @param zipPath 压缩文件 "path\\Desktop\\aaa.zip"
     * @throws IOException IOException
     */
    public static void zipFile(List<String> srcDirs, String zipPath) throws IOException {
        OutputStream out = new FileOutputStream(new File(zipPath));

        try (ZipOutputStream zos = new ZipOutputStream(out, StandardCharsets.UTF_8)) {
            List<File> sourceFileList = new ArrayList<>();
            for (String dir : srcDirs) {
                File sourceFile = new File(dir);
                sourceFileList.add(sourceFile);
            }
            compress(sourceFileList, zos);
        }
    }

    private static void compress(List<File> sourceFileList, ZipOutputStream zos) throws IOException {
        byte[] buf = new byte[BUFFER_SIZE];
        for (File sourceFile : sourceFileList) {
            String name = sourceFile.getPath().split("\\\\", 2)[1];
            if (sourceFile.isFile()) {
                zos.putNextEntry(new ZipEntry(name));
                int len;
                try (FileInputStream in = new FileInputStream(sourceFile)) {
                    while ((len = in.read(buf)) != -1) {
                        zos.write(buf, 0, len);
                    }
                    zos.closeEntry();
                }
            } else {
                File[] listFiles = sourceFile.listFiles();
                if (listFiles == null || listFiles.length == 0) {
                    zos.putNextEntry(new ZipEntry(name + "/"));
                    zos.closeEntry();
                } else {
                    for (File file : listFiles) {
                        compress(file, zos, name + "/" + file.getName());
                    }
                }
            }
        }
    }

    private static void compress(File sourceFile, ZipOutputStream zos,
                                 String name) throws IOException {
        byte[] buf = new byte[BUFFER_SIZE];
        if (sourceFile.isFile()) {
            zos.putNextEntry(new ZipEntry(name));
            int len;
            try (FileInputStream in = new FileInputStream(sourceFile)) {
                while ((len = in.read(buf)) != -1) {
                    zos.write(buf, 0, len);
                }
                zos.closeEntry();
            }
        } else {
            File[] listFiles = sourceFile.listFiles();
            if (listFiles == null || listFiles.length == 0) {
                zos.putNextEntry(new ZipEntry(name + "/"));
                zos.closeEntry();
            } else {
                for (File file : listFiles) {
                    compress(file, zos, name + "/" + file.getName());
                }
            }
        }
    }

}
