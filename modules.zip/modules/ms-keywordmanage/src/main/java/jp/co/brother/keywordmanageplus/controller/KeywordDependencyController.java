package jp.co.brother.keywordmanageplus.controller;

import jp.co.brother.keywordmanageplus.dto.KeywordDependencyDTO;
import jp.co.brother.keywordmanageplus.service.KeywordDependencyService;
import jp.co.brother.keywordmanageplus.vo.KeywordDependencyVO;
import jp.co.brother.keywordmanageplus.vo.ResultVO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.DeleteMapping;

@RestController
@RequestMapping("/keywordDependency")
public class KeywordDependencyController {

    @Autowired
    private KeywordDependencyService dependencyService;

    @GetMapping(produces = "application/json;charset=UTF-8")
    public ResultVO getAllKeywordDependency() {
        return dependencyService.getAllKeywordDependency();
    }

    @GetMapping(value = "/{keywordDependencyId}", produces = "application/json;charset=UTF-8")
    public ResultVO getKeywordDependencyById(@PathVariable(required = true, name = "keywordDependencyId") String keywordDependencyId) {
        return dependencyService.getKeywordDependencyById(keywordDependencyId);
    }

    @PostMapping
    public ResultVO insertKeywordDependency(KeywordDependencyVO keywordDependencyVO) {
        return dependencyService.insertKeywordDependency(keywordDependencyVO);
    }

    @PutMapping(value = "/{keywordDependencyId}", produces = "application/json;charset=UTF-8")
    public ResultVO updateKeywordDependencyById(@PathVariable(required = true, name = "keywordDependencyId") String keywordDependencyId,
                                                @RequestBody KeywordDependencyDTO keywordDependencyDTO) {
        return dependencyService.updateKeywordDependencyById(keywordDependencyId, keywordDependencyDTO);
    }

    @DeleteMapping(value = "/{keywordDependencyId}", produces = "application/json;charset=UTF-8")
    public ResultVO deleteKeywordDependencyById(@PathVariable(name = "keywordDependencyId", required = true) String[] keywordDependencyId) {
        return dependencyService.deleteKeywordDependencyById(keywordDependencyId);
    }
}
