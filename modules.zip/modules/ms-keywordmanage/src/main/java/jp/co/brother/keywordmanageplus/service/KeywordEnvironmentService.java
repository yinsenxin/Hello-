package jp.co.brother.keywordmanageplus.service;


import jp.co.brother.keywordmanageplus.vo.KeywordEnvironmentVO;
import jp.co.brother.keywordmanageplus.vo.ResultVO;

public interface KeywordEnvironmentService {
	/**
	 * Gets KeyWordEnviroData all data
	 * @return
	 */
 	ResultVO getKeywordEnvironmentData();
 	/**
 	 * Get specified KeyWordEnviroData data By keyWordEnviroId
 	 * @param keyWordEnviroId
 	 * @return
 	 */
    ResultVO getKeywordEnvironmentDataById(String keyWordEnvironemntId);
    /**
     * Insert specified KeyWordEnviroData data By keyWordEnviroPojo
     * @param keyWordEnviro
     * @return
     */
    ResultVO insertKeywordEnvironmentData (KeywordEnvironmentVO keyWordEnvironmentVo);
    /**
     * Delete specified KeyWordEnviroData data By keyWordEnviroIds
     * @param keyWordEnviroIds
     * @return
     */
    ResultVO deleteKeywordEnvironmentData(String []keyWordEnvironmentIds);
	     
}
