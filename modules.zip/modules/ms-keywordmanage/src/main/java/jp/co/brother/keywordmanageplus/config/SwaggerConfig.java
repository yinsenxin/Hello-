package jp.co.brother.keywordmanageplus.config;


import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.List;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import jp.co.brother.keywordmanageplus.controller.FreeMarkerController;
import jp.co.brother.keywordmanageplus.utils.GetRequestMappingValue;
import lombok.extern.slf4j.Slf4j;
import springfox.documentation.builders.ApiInfoBuilder;
import springfox.documentation.builders.PathSelectors;
import springfox.documentation.builders.RequestHandlerSelectors;
import springfox.documentation.service.ApiInfo;
import springfox.documentation.spi.DocumentationType;
import springfox.documentation.spring.web.plugins.Docket;
import springfox.documentation.swagger2.annotations.EnableSwagger2;

@Configuration
@EnableSwagger2
@Slf4j
public class SwaggerConfig {

	@Value("${server.port}")
	String port;

	@Bean
	public Docket createRestApi() {
		return new Docket(DocumentationType.SWAGGER_2)
				.apiInfo(apiInfo())
				// .apiInfo((ApiInfo) apiInfo())
				.select().apis(RequestHandlerSelectors.basePackage("jp.co.brother.keywordmanageplus.controller"))
				.paths(PathSelectors.any()).build();
	}

	private ApiInfo apiInfo() {
		ApiInfoBuilder apiInfoBuilder = new ApiInfoBuilder();
		//HTMLè°ƒæ•´api
		List<String> listValue = GetRequestMappingValue.getVlue(FreeMarkerController.class);
		apiInfoBuilder.title("微服务");
		int len = listValue.size();

		StringBuilder builder = new StringBuilder();
		//Gets the current service ip
		String ip=null;
		try {
			InetAddress inetAddress = InetAddress.getLocalHost();
			ip=inetAddress.getHostName();
		} catch (UnknownHostException e) {
			ip="apbsh0898";
			log.warn("The method not get Host {}",e);
		}
		for (int i = 0; i < len; i++) {
			builder.append("http://"+ip+":" + port + listValue.get(i) + "\n");
		}
		apiInfoBuilder.description("微服务系统页面列表:" + "\n" + builder);
		apiInfoBuilder.version("1.0");
		return apiInfoBuilder.build();
	}

}