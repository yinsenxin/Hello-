package jp.co.brother.keywordmanageplus.utils;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.springframework.web.bind.annotation.GetMapping;

/**
 * 
 * @author yinse
 *
 */
public class GetRequestMappingValue {
	
	private GetRequestMappingValue() {}
	/* 
	 * 通过反射得到GetMapping的value值 
	 * 获取特定ontrolle类的RequestMapping的value
	 * controllerClassName 实例：FreeMarkerController.class
	 */
	public static List<String> getVlue(Class<?> controllerClassName) {
		List<String> result = new ArrayList<>();
		// 得到字节码文件 【只需要更改controller类名】
		Class<?> clazz = controllerClassName;
		// 得到方法
		Method[] methods = clazz.getDeclaredMethods();
		for (Method method : methods) {
			// 判断是否存在GetMapping注解
			boolean present = method.isAnnotationPresent(GetMapping.class);
			if (present) {
				// 得到GetMapping注解
				GetMapping annotation = method.getAnnotation(GetMapping.class);
				// 得到value数组
				String[] value = annotation.value();
				List<String> list = Arrays.asList(value);
				result.addAll(list);
			}
		}
		return result;
	}
}