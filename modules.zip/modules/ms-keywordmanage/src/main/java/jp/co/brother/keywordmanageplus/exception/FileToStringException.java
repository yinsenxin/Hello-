package jp.co.brother.keywordmanageplus.exception;

public class FileToStringException extends RuntimeException {

	/**
	 * Automatic generation
	 */
	private static final long serialVersionUID = 697187344370591460L;
	
	public FileToStringException() {}
	
	/* Call Throwable for exception handling */
	public FileToStringException(String message) {
		super(message);
	}
}
