package jp.co.brother.keywordmanageplus.service;

import jp.co.brother.keywordmanageplus.dto.KeywordDTO;
import jp.co.brother.keywordmanageplus.vo.KeywordExecuteVO;
import jp.co.brother.keywordmanageplus.vo.KeywordVO;
import jp.co.brother.keywordmanageplus.vo.ResultVO;

public interface KeywordService {

    /**
     * Gets all the data for the keyword
     *
     * @return
     */
    ResultVO getAllKeywordData(String modelId);

    /**
     * Gets the specified keyword  by keywordId
     *
     * @param keywordId
     * @return
     */
    ResultVO getKeywordDataById(String keywordId);

    /**
     * Add new keyword data
     *
     * @param keywordPojo
     */
    ResultVO insertKeywordData(KeywordVO keywordVo);

    /**
     * Update the keyword data
     *
     * @param keywordId
     * @param keywordDTOS
     */
    ResultVO updateKeywordData(String keywordId, KeywordDTO keywordNewDTO, KeywordDTO keywordOldDTO);

    /**
     * Delete the specified keyword data by keywordIds
     *
     * @param keywordIds
     */
    ResultVO deleteKeywordData(String[] keywordIds);


    KeywordDTO getKeywordDTODataByKeywordId(String keywordId);

    /**
     * execute Keyword
     *
     * @param keywordExecuteVO keywordExecuteVO
     * @return ResultVO
     */
    ResultVO executeKeyword(KeywordExecuteVO keywordExecuteVO);
}
