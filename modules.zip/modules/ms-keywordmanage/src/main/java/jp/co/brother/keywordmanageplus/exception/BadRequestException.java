package jp.co.brother.keywordmanageplus.exception;

public class BadRequestException extends RuntimeException {

	/**
	 * Automatic generation
	 */
	private static final long serialVersionUID = -6519816045987333392L;
	
	public BadRequestException() {}
	
	/* Call Throwable for exception handling */
	public BadRequestException(String message) {
		super(message);
	}
	
}
