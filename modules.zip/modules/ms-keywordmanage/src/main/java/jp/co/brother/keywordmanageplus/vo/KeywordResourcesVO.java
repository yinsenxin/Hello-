package jp.co.brother.keywordmanageplus.vo;

import lombok.Data;

@Data
public class KeywordResourcesVO {
    private String name;
    private String uri;
}
