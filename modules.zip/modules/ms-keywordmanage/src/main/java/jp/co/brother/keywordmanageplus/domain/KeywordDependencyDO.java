package jp.co.brother.keywordmanageplus.domain;

import jp.co.brother.keywordmanageplus.dto.FileList;
import lombok.Data;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.Field;

import java.util.List;

@Data
@Document(collection = "Keyword_dependency")
public class KeywordDependencyDO {
    /**
     * The unique ID of the group data.
     */
    @Id
    private String id;
    /**
     * The name of the KeyWordDO data;
     */
    @Field("name")
    private String name;
    /**
     * The version of the KeyWordDO data;
     */
    @Field("version")
    private String version;
    /**
     * The uri of the KeyWordDO data;
     */
    @Field("uri")
    private String uri;
    /**
     * The fileList of the KeyWordDO data;
     */
    @Field("file_list")
    private List<FileList> fileList;
    /**
     * The description of the KeyWordDO data;
     */
    @Field("description")
    private String description;
}
