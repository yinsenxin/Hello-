package jp.co.brother.keywordmanageplus.vo;

import lombok.Data;

import java.util.List;

@Data
public class KeywordExecuteVO {

    private String keywordId;
    private String machineId;
    private String uri;
    private String keywordName;
    private List<String> paramList;

}
