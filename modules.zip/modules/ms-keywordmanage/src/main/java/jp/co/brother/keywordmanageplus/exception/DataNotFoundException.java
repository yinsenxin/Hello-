package jp.co.brother.keywordmanageplus.exception;

public class DataNotFoundException extends RuntimeException {

	/**
	 * Automatic generation
	 */
	private static final long serialVersionUID = 652131145043354543L;
	
	public DataNotFoundException() {}
	
	/* Call Throwable for exception handling */
	public DataNotFoundException (String message) {
		super(message);
	}
	
}
