package jp.co.brother.keywordmanageplus.exception;

public class OperationDBException extends RuntimeException{

	/**
	 * Automatic generation
	 */
	private static final long serialVersionUID = 2612507906503155435L;
	
	public OperationDBException() {}
	
	/* Call Throwable for exception handling */
	public OperationDBException (String message) {
		super(message);
	}

}
