package jp.co.brother.keywordmanageplus.service;

import jp.co.brother.keywordmanageplus.vo.ResultVO;

import javax.servlet.http.HttpServletResponse;

public interface KeywordResourcesService {
    /**
     * get all keyword resources
     *
     * @return ResultVO
     */
    ResultVO getAllKeywordResources();

    /**
     * download select resources
     *
     * @return ResultVO
     */
    ResultVO downloadKeywordResources(HttpServletResponse response, String[] keywordResourceNames);
}
