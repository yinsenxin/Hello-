package jp.co.brother.keywordmanageplus.dto;

import java.util.List;

import lombok.Data;

@Data
public class KeywordDTO {
	/**
	 * The unique ID of the KeywordDTO data.
	 */
	private String id;
	/**
	 * The name of the KeywordDTO data;
	 */
	private String name;
	/**
	 * The type of the KeywordDTO data;
	 */
	private String type;
	/**
	 * The version of the KeywordDTO data;
	 */
	private String version;
	/**
	 * The uri of the KeywordDTO data;
	 */
	private String uri;
	/**
	 * The status of the KeywordDTO data;
	 */
	private String status;
	/**
	 * The fileList of the KeywordDTO data;
	 */
	private List<FileList> fileList;
	/**
	 * The paramList of the KeywordDTO data;
	 */
	private List<ParamList> paramList;
	/**
	 * The description of the KeywordDTO data;
	 */
	private String description;
	
	
}
