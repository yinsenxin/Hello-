package jp.co.brother.keywordmanageplus.exception;

public class UnZipFileFailedException extends RuntimeException {

    private static final long serialVersionUID = 8958141669330042165L;

    public UnZipFileFailedException() {
    }

    public UnZipFileFailedException(String message) {
        super(message);
    }
}
