package jp.co.brother.keywordmanageplus.utils;

import lombok.Data;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.io.InputStreamReader;
import java.io.LineNumberReader;

@Component
public class CommandUtil {

    private CommandUtil() {

    }

    @Data
    public static class ExecuteResult {
        private Integer resultCode;
        private String message;
    }

    /**
     * execute the given command
     *
     * @param command command
     * @return ExecuteResult
     * @throws IOException          runtime execute exception
     * @throws InterruptedException process waitFor exception
     */
    public static ExecuteResult executeCommand(String command) throws IOException, InterruptedException {
        ExecuteResult result = new ExecuteResult();
        Runtime runtime = Runtime.getRuntime();
        Process process = runtime.exec(command);
        result.setResultCode(process.waitFor());
        LineNumberReader br = new LineNumberReader(new InputStreamReader(process.getInputStream()));
        String line;
        StringBuilder logsBuilder = new StringBuilder();
        while ((line = br.readLine()) != null) {
            logsBuilder.append(line).append("\n");
        }
        result.setMessage(logsBuilder.toString());
        return result;
    }
}
