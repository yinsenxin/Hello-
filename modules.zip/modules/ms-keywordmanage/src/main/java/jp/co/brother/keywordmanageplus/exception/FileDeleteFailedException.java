package jp.co.brother.keywordmanageplus.exception;

public class FileDeleteFailedException extends RuntimeException{

	/**
	 * Automatic generation
	 */
	private static final long serialVersionUID = -1628867665648578948L;
	
	public FileDeleteFailedException() {}
	
	/* Call Throwable for exception handling */
	public FileDeleteFailedException(String message) {
		super(message);
	}

}
