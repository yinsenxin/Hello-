package jp.co.brother.keywordmanageplus.vo;

import lombok.Data;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;

@Data
public class KeywordDependencyVO {
    /**
     * The name obtained by the front end;
     */
    private String name;
    /**
     * The version obtained by the front end;
     */
    private String version;
    /**
     * The uri obtained by the front end;
     */
    private String uri;
    /**
     * The description obtained by the front end;
     */
    private String description;
    /**
     * The file obtained by the front end;
     */
    private List<MultipartFile> file;

}
