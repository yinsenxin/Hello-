package jp.co.brother.keywordmanageplus.domain;

import lombok.Data;

import java.util.HashMap;

@Data
public class MachineDO {
    private String machineId;
    private String modelId;
    private HashMap<String, Object> conditions;
    private String userId;

}
