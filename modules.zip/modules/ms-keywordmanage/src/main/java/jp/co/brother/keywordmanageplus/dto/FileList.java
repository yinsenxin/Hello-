package jp.co.brother.keywordmanageplus.dto;


import lombok.Data;

@Data
public class FileList {
	
	/**
	 * The id of the FileList data;
	 */
	private String id;
	/**
	 * The fileName of the FileList data;
	 */
	private String name;
	/**
	 * The type of the FileList data;
	 */
	private String type;
	/**
	 * The content of the FileList data;
	 */
	private String content;
	/**
	 * The createDate of the FileList data;
	 */
	private String createDate;
	/**
	 * The lastModifyDate of the FileList data;
	 */
	private String lastModifyDate;
	/**
	 * The description of the FileList data;
	 */
	private String description;
}




