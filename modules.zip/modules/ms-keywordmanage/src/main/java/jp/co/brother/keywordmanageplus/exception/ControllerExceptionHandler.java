package jp.co.brother.keywordmanageplus.exception;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import jp.co.brother.keywordmanageplus.constant.Constant;
import jp.co.brother.keywordmanageplus.vo.ResultVO;


@RestController
@ControllerAdvice
public class ControllerExceptionHandler {

    private final Logger logger = LoggerFactory.getLogger(this.getClass());

    @ExceptionHandler(value = IllegalArgumentException.class)
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    public ResultVO illegalArgumentException(HttpServletRequest request, IllegalArgumentException e) {
        logger.error(Constant.EXCEPTION_LOG_RECORD, e.getClass().getName(), e.getMessage());
        ResultVO result = new ResultVO();
        result.setCode(HttpStatus.BAD_REQUEST.value());
        result.setMessage(e.getMessage());
        return result;
    }

    @ExceptionHandler(value = MethodArgumentNotValidException.class)
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    public ResultVO argumentNotValidExceptionHandler(HttpServletRequest request, MethodArgumentNotValidException e) {
        logger.error(Constant.EXCEPTION_LOG_RECORD, e.getClass().getName(), e.getMessage());
        ResultVO result = new ResultVO();
        result.setCode(HttpStatus.BAD_REQUEST.value());
        result.setMessage(e.getMessage());
        return result;
    }

    /**
     * In order to avoid FileDeleteFailedException, set the response status code to 500.
     * 
     * @param request
     * @param e
     * @return
     */
    @ExceptionHandler(value = FileDeleteFailedException.class)
    @ResponseStatus(HttpStatus.OK)
    public ResultVO fileDeleteFailedExceptionHandler(HttpServletRequest request, FileDeleteFailedException e) {
        logger.error(Constant.EXCEPTION_LOG_RECORD, e.getClass().getName(), e.getMessage());
        ResultVO result = new ResultVO();
        result.setCode(HttpStatus.INTERNAL_SERVER_ERROR.value());
        result.setMessage(e.getMessage());
        return result;
    }

    /**
     * In order to avoid FileToStringException, set the response status code to 500.
     * 
     * @param request
     * @param e
     * @return
     */
    @ExceptionHandler(value = FileToStringException.class)
    @ResponseStatus(HttpStatus.OK)
    public ResultVO fileToStringExceptionHandler(HttpServletRequest request, FileToStringException e) {
        logger.error(Constant.EXCEPTION_LOG_RECORD, e.getClass().getName(), e.getMessage());
        ResultVO result = new ResultVO();
        result.setCode(HttpStatus.INTERNAL_SERVER_ERROR.value());
        result.setMessage(e.getMessage());
        return result;
    }
    
    /**
     * In order to avoid StringToFileException, set the response status code to 500.
     * @param request
     * @param e
     * @return
     */
    @ExceptionHandler(value = StringToFileException.class)
    @ResponseStatus(HttpStatus.OK)
    public ResultVO stringToFileExceptionHandler(HttpServletRequest request, StringToFileException e) {
        logger.error(Constant.EXCEPTION_LOG_RECORD, e.getClass().getName(), e.getMessage());
        ResultVO result = new ResultVO();
        result.setCode(HttpStatus.INTERNAL_SERVER_ERROR.value());
        result.setMessage(e.getMessage());
        return result;
    }
    
    /**
     * In order to avoid DataNotFoundException, set the response status code to 404.
     * 
     * @param request
     * @param e
     * @return
     */
    @ExceptionHandler(value = DataNotFoundException.class)
    @ResponseStatus(HttpStatus.OK)
    public ResultVO dataNotFoundExceptionHandler(HttpServletRequest request, DataNotFoundException e) {
        logger.error(Constant.EXCEPTION_LOG_RECORD, e.getClass().getName(), e.getMessage());
        ResultVO result = new ResultVO();
        result.setCode(HttpStatus.NOT_FOUND.value());
        result.setMessage(e.getMessage());
        return result;
    }
    
    /**
     * In order to avoid AlreadyExistsException, set the response status code to 409.
     * @param request
     * @param e
     * @return
     */
    @ExceptionHandler(value = AlreadyExistsException.class)
    @ResponseStatus(HttpStatus.OK)
    public ResultVO alreadyExistsExceptionExceptionHandler(HttpServletRequest request, AlreadyExistsException e) {
        logger.error(Constant.EXCEPTION_LOG_RECORD, e.getClass().getName(), e.getMessage());
        ResultVO result = new ResultVO();
        result.setCode(HttpStatus.CONFLICT.value());
        result.setMessage(e.getMessage());
        return result;
    }
    
    /**
     * In order to avoid AlreadyExistsException, set the response status code to 409.
     * @param request
     * @param e
     * @return
     */
    @ExceptionHandler(value = BadRequestException.class)
    @ResponseStatus(HttpStatus.OK)
    public ResultVO badRequestExceptionExceptionHandler(HttpServletRequest request, BadRequestException e) {
        logger.error(Constant.EXCEPTION_LOG_RECORD, e.getClass().getName(), e.getMessage());
        ResultVO result = new ResultVO();
        result.setCode(HttpStatus.BAD_REQUEST.value());
        result.setMessage(e.getMessage());
        return result;
    }
    
    /**
     * In order to avoid DataNotFoundException, set the response status code to 500.
     * @param request
     * @param e
     * @return
     */
    @ExceptionHandler(value = OperationDBException.class)
    @ResponseStatus(HttpStatus.OK)
    public ResultVO opeartionDBExceptionHandler(HttpServletRequest request, OperationDBException e) {
        logger.error(Constant.EXCEPTION_LOG_RECORD, e.getClass().getName(), e.getMessage());
        ResultVO result = new ResultVO();
        result.setCode(HttpStatus.INTERNAL_SERVER_ERROR.value());
        result.setMessage(e.getMessage());
        return result;
    }
    
    /**
     * 
     * @param request
     * @param e
     * @return
     */
    @ExceptionHandler(Exception.class)
    @ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR)
    public ResultVO othersExceptionHandler(HttpServletRequest request, Exception e) {
        logger.error(Constant.EXCEPTION_LOG_RECORD, e.getClass().getName(), e.getMessage());
        ResultVO result = new ResultVO();
        result.setCode(HttpStatus.INTERNAL_SERVER_ERROR.value());
        result.setMessage(e.getMessage());
        return result;
    }
}
