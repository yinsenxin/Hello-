package jp.co.brother.keywordmanageplus.dto;

import lombok.Data;

import java.util.List;

@Data
public class KeywordDependencyDTO {
    /**
     * The unique ID of the group data.
     */
    private String id;
    /**
     * The name of the KeyWordDO data;
     */
    private String name;
    /**
     * The version of the KeyWordDO data;
     */
    private String version;
    /**
     * The uri of the KeyWordDO data;
     */
    private String uri;
    /**
     * The fileList of the KeyWordDO data;
     */
    private List<FileList> fileList;
    /**
     * The description of the KeyWordDO data;
     */
    private String description;
}
