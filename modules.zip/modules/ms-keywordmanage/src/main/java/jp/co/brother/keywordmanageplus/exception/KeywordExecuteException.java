package jp.co.brother.keywordmanageplus.exception;

public class KeywordExecuteException extends RuntimeException {

    private static final long serialVersionUID = 6051044877767279955L;

    public KeywordExecuteException() {
    }

    public KeywordExecuteException(String message) {
        super(message);
    }
}
