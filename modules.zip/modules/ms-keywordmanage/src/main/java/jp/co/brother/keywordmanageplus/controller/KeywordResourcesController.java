package jp.co.brother.keywordmanageplus.controller;

import jp.co.brother.keywordmanageplus.service.KeywordResourcesService;
import jp.co.brother.keywordmanageplus.vo.ResultVO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletResponse;

@RestController
@RequestMapping("/keywordResources")
public class KeywordResourcesController {

    @Autowired
    private KeywordResourcesService keywordResourcesService;

    @GetMapping(produces = "application/json;charset=UTF-8")
    public ResultVO getAllKeywordResources() {
        return keywordResourcesService.getAllKeywordResources();
    }

    @PostMapping(value = "/download", produces = "application/json;charset=UTF-8")
    public ResultVO downloadKeywordResources(HttpServletResponse response, @RequestParam(name = "keywordResourceNames") String[] keywordResourceNames) {
        return keywordResourcesService.downloadKeywordResources(response, keywordResourceNames);
    }

}
