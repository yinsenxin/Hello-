package jp.co.brother.keywordmanageplus.aspect;

import java.lang.reflect.Method;

import javax.servlet.http.HttpServletRequest;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;
import org.aspectj.lang.reflect.MethodSignature;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

@Aspect
@Component
public class RestControllerAspect {
	
	private final Logger logger = LoggerFactory.getLogger(this.getClass());
	
	@Pointcut("execution(* jp.co.brother.keywordmanageplus.controller..*(..)) and @annotation(org.springframework.web.bind.annotation.RequestMapping)")
	private void cut() {
		throw new UnsupportedOperationException();
	}
	
	/**
        * 环绕通知
     * @param joinPoint 连接点
     * @return 切入点返回值
     * @throws Throwable 异常信息
     */
    @Around("cut()")
    public Object apiLog(ProceedingJoinPoint joinPoint) throws Throwable {
        MethodSignature signature = (MethodSignature) joinPoint.getSignature();
        //Gets the method to be intercepted
        Method method = signature.getMethod();
        //Gets the name of the intercepted method
		String methodName = method.getName(); 
		//Gets the current request
        ServletRequestAttributes attributes = (ServletRequestAttributes) RequestContextHolder.getRequestAttributes();
        HttpServletRequest request = attributes.getRequest();
        
        //Gets the request header information
        String userAgent = request.getHeader("user-agent");
        logger.info("Started request method [{}] params [{}] userAgent [{}]", methodName, "", userAgent);
        long start = System.currentTimeMillis();
        
        //Proceed processing
        Object result = joinPoint.proceed();
        
        //post-processing
        logger.info("Ended request method [{}] response is [{}] cost [{}] millis ",
                 methodName, "", System.currentTimeMillis() - start);
        return result;
    }
}
