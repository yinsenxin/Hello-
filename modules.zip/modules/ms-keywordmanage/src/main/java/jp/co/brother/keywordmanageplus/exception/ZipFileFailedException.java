package jp.co.brother.keywordmanageplus.exception;

public class ZipFileFailedException extends RuntimeException {

    private static final long serialVersionUID = 8958141669330042165L;

    public ZipFileFailedException() {
    }

    public ZipFileFailedException(String message) {
        super(message);
    }
}
