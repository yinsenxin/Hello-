var $table = $('#table');
var index;
// add ParamTable
var $tableModal = $('#add_ParamTable');
var $buttonAdd_addParam = $('#add_addParam');
var $buttonAdd_deleteParam = $('#add_deleteParam');

// edit ParamTable
var $editTableModal = $('#edit_ParamTable');
var $buttonEdit_addParam = $('#edit_addParam');
var $buttonEdit_deleteParam = $('#edit_deleteParam');

// about FileTable
var $editFileTable = $('#edit_FileTable');
var $buttonAdd_file = $('#edit_file_addFile');
var $buttonDelete_file = $('#edit_file_deleteFile');
var $buttonEdit_file = $('#edit_file_editFile');

var caseColums;
var caseTableId =[];
$(function (){

    toastr.options = {
        "closeButton": false, //是否显示关闭按钮
        "debug": false, //是否使用debug模式
        "positionClass": "toast-center-center",//弹出窗的位置
    }
    
        //Data All
    $table.bootstrapTable('destroy').bootstrapTable({
         url: "/keywords",
         method: 'get',
         toolbar: '#toolbar',
         strictSearch: false,
         showColumns: true,
         showRefresh: true,
         clickToSelect: true,
         showToggle:false,
         detailView: true,//父子表
         detailFormatter:"detailFormatter",
         onExpandRow: function (index, row, $detail) {
             detailview(index, row, $detail)
         },
         responseHandler:function (res) {
             return  res.data;
         },
         checkbox:true,
         columns: [{
             field: 'checkbox',
             checkbox: true,
         },{
             field: 'id',
             title: 'Id',
             align: 'center',
             visible: false,
         },{
             field: 'name',
             title: 'Name',
             align: 'center',
             sortable: true,
         },{
             field: 'type',
             title: 'Type',
             align: 'center',
             sortable: true,
         },{
             field: 'status',
             title: 'Status',
             align: 'center',
             sortable: true,
         },{
             field: 'version',
             title: 'Version',
             align: 'center',
             sortable: true,
         },{
             field: 'uri',
             title: 'URI',
             align: 'center',
             sortable: true,
         },{
             field: 'fileList',
             align: 'center',
             title: 'FileList',
             sortable: true,
             formatter: function(data) {
                        var str = '';
                    for (let i in data) {
                            if (str.length != 0) {
                                    str = str + ',';
                            }
                            str +=  data[i].name;
                    }
                    return str;

                 
             }
         },{
             field: 'description',
             title: 'Description',
             align: 'center',
             visible: false,
             formatter: function(data) {
                if (data == null){
                    return "";
                }
                 return data;
              }
         }]
         
    })

    $tableModal.bootstrapTable({
          toolbar: '#toolbarModal',
          strictSearch: true,
          showColumns: false,
          showRefresh: false,
          clickToSelect: false,
          checkbox:true,
          columns: [{
              field: 'checkbox',
              checkbox: true
          },{
              field: 'id',
              title: 'id',
              align: 'center',
              visible: false
          },{
              field: 'name',
              title: 'Name',
              align: 'center',
              editable: {
                  type: 'text',
                  title: 'Name',
                  validate: function (v) {
                      if (!v){
                          return 'The param name cannot be empty.';
                      }
                      var data = $tableModal.bootstrapTable('getData', true);
                      var map = [];
                      for(var i in data){
                          var element = data[i];
                          map.push(element.name);
                      }
                      if(v){
                          var flag = findName(v,map);
                          if(flag == false){
                              return 'Name already exists. Please rename param.';
                          }
                      }
                  }
              }
          },{
              field: 'type',
              title: 'Type',
              align: 'center',
              editable: {
                  type: 'select',
                  title: 'Type',
                  source:["STRING","JSON","NUMBER"],
                  validate: function (v) {
                      if (!v){
                          return 'ParamList type can not be empty.';
                      }
                      var str = jQuery.trim(v);
                      var arr = str.split("");
                      var length = arr.length - 1;
                      if(arr[0] == "," || arr[length] =="," || (arr[0] == "," && arr[length] ==",")){
                          return "The head and tail of the value must not ','" ;
                      }
                  }
              }
          },{
              field: 'description',
              title: 'Description',
              align: 'center',
              editable: {
                  type: 'text',
                  title: 'Description',
                  validate: function (v) {
                      if (!v){
                          return 'ParamList description can not be empty.';
                      }
                      var str = jQuery.trim(v);
                      var arr = str.split("");
                      var length = arr.length - 1;
                      if(arr[0] == "," || arr[length] =="," || (arr[0] == "," && arr[length] ==",")){
                          return "The head and tail of the value must not ','" ;
                      }
                  }
              }
          }]
      });
    
    $('#file').fileinput({
    	allowedFileExtensions:['py','robot']
    })
    $('#files').fileinput({
    	allowedFileExtensions:['py','robot']
    })
})

function detailFormatter(index, row){
    var html = [];                
    html.push('<div  class="row">');
    html.push('<div class="col-sm-1"> </div>');
    html.push('<div class="col-md-10">');
    html.push('<table id="caseTable'+ index +'"></table>');
    html.push('</div>');
    html.push('</div>');
    return html;
}

function detailview(index, row, $detail){
    caseColums=[];
    caseColums.push({
        field: 'name',
        title: '参数名(name)',
        align: 'center',
        width:200
    },{
        field: 'type',
        title: '参数类型(type)',
        align: 'center',
            width:200        
    },{
        field: 'description',
        title: '参数说明(description)',
        align: 'center',
        width:200
    })
    $("#caseTable" + index).bootstrapTable('destroy').bootstrapTable({
        url: "/keywords/"+row.id,
        method:"get",
        search: false,
        striped: true,
        clickToSelect: false,
        columns: caseColums,
        height:200,
        responseHandler:function(res){
            var paramList = res.data.paramList;
            var data = [];
            for(let index = 0; index < paramList.length; index++){
                let m = paramList[index];
                let d ={
                    name : m.name,
                    type : m.type,
                    description : m.description
                }
                data.push(d);
            }
            return data;
        }
    });
    if(caseTableId.length == 0){
        caseTableId[0] = "caseTable" + index;
    }
    else{
        var str = "caseTable" + index;
        for(let caseindex = 0;caseindex <caseTableId.length;caseindex++){
            if(str == caseTableId[caseindex]){
                str = null;
                return;
            }
        }
        if(str!= null){
            caseTableId[caseTableId.length] = str;
        }
    }

}


var conditionId = 1;
        
  $buttonAdd_addParam.click(function () {
      conditionId++;
      $tableModal.bootstrapTable('insertRow', {
          index: 0,
          row: {
              id:conditionId,
              name: "",
              type:"STRING",
              description:""
          }
      });
  });
  
  $buttonAdd_deleteParam.click(function () {
     var ids = $.map($tableModal.bootstrapTable('getSelections'), function (row) {
         return row.id;
     });
     if (ids.length <= 0){
    	 toastr.warning('Please choose the data to delete! ');
    	 return false;
     }
     
     $tableModal.bootstrapTable('remove', {
         field: 'id',
         values: ids,
     });
  });
  
  $buttonEdit_addParam.click(function () {
	    conditionId++;
	    $editTableModal.bootstrapTable('insertRow', {
	        index: 0,
	        row: {
	            id:conditionId,
	            name: "",
	            type:"STRING",
	            description:""
	        }
	    });
	}); 
 
  $buttonEdit_deleteParam.click(function () {
	    var ids = $.map($editTableModal.bootstrapTable('getSelections'), function (row) {
	        return row.id;
	    });
	    if (ids.length <= 0){
	    	 toastr.warning('Please choose the data to delete! ');
	    	 return false;
	     }
	    $editTableModal.bootstrapTable('remove', {
	        field: 'id',
	        values: ids,
	    });
	});
  
   

 function findName(name,map){
    var result = true;
        var tmp = map.indexOf(name);
        if(tmp != -1){
            result = false;
            return result;
        }
    return result;
}

function addKeywordModal(){
        
    $('#addName').val('');
    $('#addVersion').val('');
    $('#addURI').val('');
    $('#addDescription').val('');
    $tableModal.bootstrapTable("removeAll");
    $('#file').fileinput('clear');
    $('#addKeywordInfo').modal('show');
}


// sure add 
function addSave(){
        
    var formdata = new FormData();
    var name = $('#addName').val();
    var type = $('#addType').val()
    var status = $('#addStatus').val();
    var version = $('#addVersion').val();
    var uri = $('#addURI').val()
    var description = $('#addDescription').val()
    var file = document.getElementById('file').files;
    var paramArray = $tableModal.bootstrapTable('getData', true);
    
    if(name.replace(/(^\s*)|(\s*$)/g, "")==""){
         toastr.warning('Name can not be empty!');
         return false;
     }
    
	 if(version.replace(/(^\s*)|(\s*$)/g, "")==""){
         toastr.warning('Version can not be empty!');
         return false;
     }
	 if(uri.replace(/(^\s*)|(\s*$)/g, "")==""){
         toastr.warning('URI can not be empty!');
         return false;
     }
	 if (file.length < 1){
	    	toastr.warning("The uploaded file must is not empty");
			return false;
	 }
     if (paramArray.length > 0){
         
         for(var index = 0; index < paramArray.length; index++){
             if (paramArray[index].name == ''){
                 toastr.warning('Param Name not can be empty!');
                 return false;
             }
         }
     }
    for (var i = 0; i < file.length; i++) {
        formdata.append('file['+i+']', file[i]);
    }
    for (var j = 0; j < paramArray.length; j++) {
        formdata.append('param['+j+'].name',paramArray[j].name);
        formdata.append('param['+j+'].type',paramArray[j].type);
        formdata.append('param['+j+'].description',paramArray[j].description);
    }
    formdata.append("name", name);
    formdata.append("type", type);
    formdata.append("status", status);
    formdata.append("version", version);
    formdata.append("uri", uri);
    formdata.append("description", description);
    
    var result = insertKeywordData(formdata);
    if (result.code == 200){
        $('#addKeywordInfo').modal('hide');
        toastr.success('Create keyword successfully');
    } else if (result.code == 409 && result.message == "Name and URI is already exists!") {
    	toastr.warning('The Name + URI  already exists');
    	return false;
    } else if (result.code == 409 && result.message == "The file already exists"){
    	toastr.warning('The file already exists');
    	return false;
    } else {
    	toastr.warning('Create keyword failed!');
    }
    $table.bootstrapTable('refresh');
}

//delete Modal
function deleteKeywordModal(){
	var seleObj = $table.bootstrapTable('getSelections');
    if(seleObj.length <= 0){
        toastr.warning('Please choose the data to delete!');
        return false;
    }
    $('#waringAlert').modal('show');
}


$buttonDelete_file.click(function(){
    $('#fileWaringAlert').modal('show');
})

//Sure to delete 
function deleteSave(){
    var keywordId = $.map($table.bootstrapTable('getSelections'),function (rows){
        return rows.id;
    });
     
    var result = deleteKeyword(keywordId);
    if (result.code == 200 && result.message == "OK"){
         toastr.success('Delete keyword successfully');
    }else {
        toastr.warning("Data deletion failure");
        return false;
    }
    $table.bootstrapTable('refresh');
}


 
 
 
function ParamListTable(paramList){
	var paramLists = [];
    for(var i = 0; i < paramList.length; i++){
        var param = {};
        param.id = i;
        param.name = paramList[i].name;
        param.type = paramList[i].type;
        param.description = paramList[i].description;
        paramLists.push(param);
    }
    $editTableModal.bootstrapTable({
        toolbar: '#edit_toolbarModal',
        strictSearch: true,
        showColumns: false,
        showRefresh: false,
        clickToSelect: false,
        checkbox:true,
        data:paramLists,
        columns: [{
            field: 'checkbox',
            checkbox: true
        },{
            field: 'id',
            title: 'id',
            align: 'center',
            visible: false
        },{
            field: 'name',
            title: 'Name',
            align: 'center',
            editable: {
                type: 'text',
                title: 'Name',
                validate: function (v) {
                    if (!v){
                        return 'The param name cannot be empty.';
                    }
                    var data = $editTableModal.bootstrapTable('getData', true);
                    var map = [];
                    for(var i in data){
                        var element = data[i];
                        map.push(element.name);
                    }
                    if(v){
                        var flag = findName(v,map);
                        if(flag == false){
                            return 'Name already exists. Please rename param.';
                        }
                    }
                }
            }
        },{
            field: 'type',
            title: 'Type',
            align: 'center',
           editable: {
                type: 'select',
                title: 'Type',
                source:["STRING","JSON","NUMBER"],
                validate: function (v) {
                    if (!v){
                        return 'ParamList type can not be empty.';
                    }
                    var str = jQuery.trim(v);
                    var arr = str.split("");
                    var length = arr.length - 1;
                    if(arr[0] == "," || arr[length] =="," || (arr[0] == "," && arr[length] ==",")){
                        return "The head and tail of the value must not ','" ;
                    }
                }
            }
        },{
            field: 'description',
            title: 'Description',
            align: 'center',
            editable: {
                type: 'text',
                title: 'Description',
                validate: function (v) {
                    if (!v){
                        return 'ParamList description can not be empty.';
                    }
                    var str = jQuery.trim(v);
                    var arr = str.split("");
                    var length = arr.length - 1;
                    if(arr[0] == "," || arr[length] =="," || (arr[0] == "," && arr[length] ==",")){
                        return "The head and tail of the value must not ','" ;
                    }
                }
            }
        }]
    });
}
 
//edit  -- FileListTable
function FilelistTable(keywordId){
     
    $editFileTable.bootstrapTable({
        url:"keywords/"+keywordId,
        toolbar: '#edit_file_toolbarModal',
        showColumns: true,
        strictSearch: false,
        clickToSelect: true,
        checkbox:true,
        responseHandler:function (res) {
        	var data = res.data.fileList;
        	var dataArray = [];
        	for(var i = 0; i < data.length; i++){
        		var datas = {};
        		datas.index = i;
        		datas.id = data[i].id;
        		datas.name = data[i].name;
        		datas.type = data[i].type;
        		datas.content = data[i].content;
        		datas.createDate = data[i].createDate;
        		datas.lastModifyDate = data[i].lastModifyDate;
        		dataArray.push(datas);
        	}
            return dataArray;
        },
        columns: [{
            field: 'checkbox',
            checkbox: true
         },{
            field: 'index',
            title: 'Index',
            align: 'center',
            visible: false,
        },{
            field: 'id',
            title: 'Id',
            align: 'center',
            visible: false,
        },{
            field: 'name',
            title: 'FileName',
            align: 'center',
        },{
            field: 'type',
            title: 'FileType',
            align: 'center',
        },{
            field: 'content',
            title: 'Content',
            align: 'center',
            visible: false,
            formatter : function(res){
                return res;
            }
        },{
            field: 'createDate',
            title: 'CreateDate',
            align: 'center',
        },{
            field: 'lastModifyDate',
            title: 'LastModifyDate',
            align: 'center',
        }]
    });
     
     
}
 
//edit Modal
function editKeywordModal(){
     
    var seleObj = $table.bootstrapTable('getSelections');
    if(seleObj.length <= 0 || seleObj.length > 1){
        toastr.warning('Please choose a data to edit!');
        return false;
    }
    var data = $.map($table.bootstrapTable('getSelections'),function (rows){
        return rows;
    });
    $('#editName').val(data[0].name);
    $('#editType').val(data[0].type);
    $('#editStatus').val(data[0].status);
    $('#editVersion').val(data[0].version);
    $('#editURI').val(data[0].uri);
    $('#editDescription').val(data[0].description);
     
    var result = getKeywordById(data[0].id);
    var paramList = result.data.paramList;
    var keywordId = data[0].id;
    $editTableModal.bootstrapTable('destroy');
    ParamListTable(paramList);
    $editFileTable.bootstrapTable('destroy');
    FilelistTable(keywordId);
    $('#editKeywordInfo').modal('show');
}
 
// execute Keyword Modal
function executeKeywordModal(){
    var selfObj = $table.bootstrapTable('getSelections');
    if(selfObj.length <= 0 || selfObj.length > 1){
        toastr.warning('Please choose a data to edit!');
        return false;
    }
    var data = $.map($table.bootstrapTable('getSelections'),function (rows){
        return rows;
    });
    $('#executeName').val(data[0].name);
    $('#executeType').val(data[0].type);


    // get machineList and set option
    getExecuteMachine(data[0].uri)
    // params list
    var paramHtmls = ""
    paramList = data[0].paramList
    if (paramList != null & paramList.length != 0){
        for(paramIndex in paramList){
            if ("machineId" == paramList[paramIndex].name){
                continue;
            }
            paramHtml = '<div class="input-group"><span class="input-group-addon"> ' + paramList[paramIndex].name + '(' + paramList[paramIndex].type + ')' + '</span>'+
            '<input type="text" id="' + paramList[paramIndex].name + '" class="form-control" placeholder="' + paramList[paramIndex].description + '"></div><br>'
            paramHtmls += paramHtml
        }
        $("#executeParams").append(paramHtmls)
    }
    document.getElementById("logs").innerHTML = ""
    $('#executeKeywordInfo').modal('show');
}

// execute Keyword
function executeKeyword(){
    var requestParamList = []
    var machineId = null

    var data = $.map($table.bootstrapTable('getSelections'),function (rows){
        return rows;
    });
    paramList = data[0].paramList
    machineId = $("#machineId").val()
    if (machineId == '' || machineId == null){
        toastr.warning('Please choose a machine !');
        return false;
    }
    if (paramList != null & paramList.length != 0){
        for(paramIndex in paramList){
            if (paramList[paramIndex].name!="machineId"){
                requestParamList.push($("#"+paramList[paramIndex].name).val())
            }
        }
    }
    document.getElementById("logs").innerHTML = ""
    execute(data[0].id, machineId, requestParamList)
}
 
 
//fileList --add
$buttonAdd_file.click(function(){
     $('#files').trigger('click');
})
 
function getNowFormatDate() {
    var date = new Date();
    var seperator1 = "-";
    var seperator2 = ":";
    var month = date.getMonth() + 1;
    var strDate = date.getDate();
    if (month >= 1 && month <= 9) {
        month = "0" + month;
    }
    if (strDate >= 0 && strDate <= 9) {
        strDate = "0" + strDate;
    }
    var currentdate = date.getFullYear() + seperator1 + month + seperator1 + strDate
            + " " + date.getHours() + seperator2 + date.getMinutes()
            + seperator2 + date.getSeconds();
    return currentdate;
}
 
function guid() {
    return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function (c) {
        var r = Math.random() * 16 | 0,
            v = c == 'x' ? r : (r & 0x3 | 0x8);
        return v.toString(16);
    });
}
 
//upload file
function importFileData(files){
     
    var file = document.getElementById('files').files;
    $('#files').replaceWith('<input type="file" name="file" id="files" accept=".robot,.py"  class="file" onchange="importFileData(this)" style="visibility:hidden"/>');
    var createDates = getNowFormatDate();
    var id = guid();
     
    var type = file[0].name.split('.')[1];
    if (type == 'py'){
        type = 'python';
    } else if(type == 'robot') {
        type = 'robot';
    }
   
    var data = $.map($editFileTable.bootstrapTable('getData'),function (rows){
        return rows.name;
    });
     
    for(var i = 0; i< data.length; i++){
        if(data[i] == file[0].name){
            toastr.warning('File already exists!');
            return false;
        }
    }
     
    const reader = new FileReader();
    reader.readAsText(file[0], "UTF-8");
    reader.onload = function(e){
    const fileString = e.target.result;
    var data = $.map($editFileTable.bootstrapTable('getData'),function (rows){
        return rows;
    }); 
    
    for (var i = 0; i < data.length; i++){
    	
    	index = data[i].index;
    }
    index++;
    $editFileTable.bootstrapTable('insertRow', {
        index:index,
        row: {
            id:id,
            index:index,
            name: file[0].name,
            type:type,
            content:fileString,
            createDate:createDates,
            lastModifyDate:createDates
        }
    });
  }
}
 
//fileList --delete
function deleteFile(){
    var seleObj = $editFileTable.bootstrapTable('getSelections');
    if(seleObj.length <= 0){
        toastr.warning('Please choose the file data to delete!');
        return false;
    }
    var data = $.map($editFileTable.bootstrapTable('getSelections'),function (rows){
        return rows.id;
    });
    var datas = $editFileTable.bootstrapTable('getData');
    for (var i = 0 ;i < data.length; i++){
        $editFileTable.bootstrapTable('remove', {
        	field: 'id',
            values: data[i],
        });
     }
    for (var j = 0; j < datas.length; j++) {
		datas[j].index = j;
	}
    if (datas.length < 1){
    	index = -1;
    } 
    
}
 
$(function (){
     
    window.editor = CodeMirror.fromTextArea(document.getElementById("edit_fileContent"), {
        mode : "python",  
        lineNumbers: true,
        indentUnit: 3,
        extraKeys: {
            "Ctrl-Q": function (cm) {
                cm.foldCode(cm.getCursor());
            }
        },
        foldGutter: true,
        theme: 'monokai', // 使用monokai模版
        gutters: ["CodeMirror-linenumbers", "CodeMirror-foldgutter"]
    });
 
})
 
var content;
$buttonEdit_file.click(function(){
     
    $('#edit_fileContent').val('');
    var seleObj = $editFileTable.bootstrapTable('getSelections');
    if(seleObj.length <= 0 || seleObj.length > 1){
        toastr.warning('Please choose a file to edit!');
        return false;
    }
     
    var data = $.map($editFileTable.bootstrapTable('getSelections'),function (rows){
        return rows;
    });
    content = data[0].content;
    $("#edit_fileContent").val(content); 
    editor.setValue(content);
     
    setInterval(function () {
        editor.refresh();
    }, 100)
    $('#fileContent').modal('show');
     
})
 
 
function editFileContent(){
	  var data = $editFileTable.bootstrapTable('getSelections');
	  if (editor.getValue() == ''){
		  toastr.warning('The file content not be empty!');
		  return false;
	  }
      $editFileTable.bootstrapTable("updateRow", {
           index:data[0].index,
           row:{
        	   content:editor.getValue(),
        	   lastModifyDate:getNowFormatDate()
    	   }
      })
}
 
 
//sure edit
$('#editSaveButton').click(function(){
     
    var obj = {};
    obj.name = $('#editName').val();
    obj.type = $('#editType').val();
    obj.status = $('#editStatus').val();
    obj.version = $('#editVersion').val();
    obj.uri = $('#editURI').val();
    obj.description = $('#editDescription').val();
    
    //fileList
    var file = $editFileTable.bootstrapTable('getData', true);
    if (file.length < 1){
    	toastr.warning("The uploaded file must is not empty");
		return false;
    }
    var fileList = [];
    for (var i = 0; i < file.length; i++) {
        var files ={};
        files.id = file[i].id;
        files.name = file[i].name;
        files.type = file[i].type;
        files.content = file[i].content;
        files.createDate = file[i].createDate;
        files.lastModifyDate = file[i].lastModifyDate;
        fileList.push(files);
    }
    obj.fileList = fileList;
    
    //paramList
    var paramArray = $editTableModal.bootstrapTable('getData', true);
    var paramList = [];
    for(var j = 0; j < paramArray.length; j++){
        var params = {};
        params.name = paramArray[j].name;
        params.type = paramArray[j].type;
        params.description = paramArray[j].description;
        paramList.push(params);
    }
    obj.paramList = paramList;
     
    if (paramArray.length > 0){
        for(var index = 0; index < paramArray.length; index++){
            if (paramArray[index].name == ''){
                toastr.warning('Param Name not can be empty!');
                return false;
            }
        }
    }
    
    var data = $.map($table.bootstrapTable('getSelections'),function (rows){
        return rows.id;
    });
    var result = updateKeyword(data[0], obj);
    if (result.code == 200 && result.message == 'OK'){
    	$('#editKeywordInfo').modal('hide');
    	toastr.success('Update keyword successfully');
    } else if (result.code == 409 && result.message == 'The file already exists'){
    	toastr.warning(result.message);
    	return false;
    } else if (result.code == 500){
    	toastr.warning(result.message);
    	return false;
    }
     
    $table.bootstrapTable('refresh');
     
})
 
function deleteCancel(){
	$('#cancelObj').modal('show')
}

function deleteFileCancel(){
	$('#fileWaringAlert').modal('hide')
}

function doCancel(){
	
	$('#cancelObj').modal('show');
}

function editCancel(){
	$('#cancelObj').modal('show');
}

function isCancelObj(){
	$('#waringAlert').modal('hide');
	$('#addKeywordInfo').modal('hide');
    $('#editKeywordInfo').modal('hide');
    $('#executeKeywordInfo').modal('hide');
    $('#fileWaringAlert').modal('hide');
    cleanExecuteModal()
}

function cleanExecuteModal(){
    document.getElementById("executeParams").innerHTML = '<div class="input-group"><span class="input-group-addon"> MachineId</span><select id="machineId" class="form-control"></select></div><br>'
    document.getElementById("logs").innerHTML = ""
}



//Request -- updateKeyword
function updateKeyword(keywordId, obj){
    var result = {};
    $.ajax({
        type: 'put',
        url: "/keywords/"+keywordId,
        async: false,
        contentType: "application/json",
        dataType: "json",
        data:JSON.stringify(obj),
        success: function(data) {
            result = data;
        },
        error: function(data){
             
        }
    });
    return result;
}

//Request -- add
function insertKeywordData(formdata){
    var result = {};
    $.ajax({
        type: 'post',
        url: "/keywords",
        async: false,
        contentType: false,
        processData: false,
        dataType: "json",
        data: formdata,
        success: function(data) {
            result = data;
        },
        error: function(data){
                result = data;
        }
    });
    return result;
}

// execute -- execute
function execute(keywordId, machineId, requestParamList){
    $("#logs").append("正在执行 请稍等 ...<br/>")
    $.ajax({
        type: 'post',
        url: "/keywords/execute",
        async: true,
        contentType: "application/json",
        processData: false,
        dataType: "json",
        data: JSON.stringify({
            "keywordId":keywordId,
            "machineId":machineId,
            "paramList":requestParamList
        }),
        success: function(res) {
            $("#logs").append(res.data.message)
            $("#logs").append("<br/>执行完毕 关键字执行")
            $("#logs").append(res.data.resultCode == 0 ? "成功<br/>" : "失败<br/>")
        },
        error: function(data){
            toastr.warning(data.message);
        }
    });
}

//Request -- delete
function deleteKeyword(keywordId){
	var result = {};
    $.ajax({
        type: 'delete',
        url: "/keywords/"+keywordId,
        async: false,
        contentType: false,
        processData: false,
        dataType: "json",
        success: function(data) {
            result = data;
        },
        error: function(data){
            
        }
    });
    return result;
}

//Request -- getOne
function getKeywordById(keywordId){
	var result = {};
    $.ajax({
        type: 'get',
        url: "/keywords/"+keywordId,
        async: false,
        contentType: false,
        processData: false,
        dataType: "json",
        success: function(data) {
            result = data;
        },
        error: function(data){
            
        }
    });
    return result;
	
}

