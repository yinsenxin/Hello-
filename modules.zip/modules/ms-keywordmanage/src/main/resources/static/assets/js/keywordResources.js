var $table = $('#table');
var index;
// add ParamTable
var $tableModal = $('#add_ParamTable');
var $buttonAdd_addParam = $('#add_addParam');
var $buttonAdd_deleteParam = $('#add_deleteParam');

// edit ParamTable
var $editTableModal = $('#edit_ParamTable');
var $buttonEdit_addParam = $('#edit_addParam');
var $buttonEdit_deleteParam = $('#edit_deleteParam');

// about FileTable
var $editFileTable = $('#edit_FileTable');
var $buttonAdd_file = $('#edit_file_addFile');
var $buttonDelete_file = $('#edit_file_deleteFile');
var $buttonEdit_file = $('#edit_file_editFile');

var caseColums;
var caseTableId =[];
$(function (){

    toastr.options = {
        "closeButton": false, //是否显示关闭按钮
        "debug": false, //是否使用debug模式
        "positionClass": "toast-center-center",//弹出窗的位置
    }


        //Data All
    $table.bootstrapTable('destroy').bootstrapTable({
         url: "/keywordResources",
         method: 'get',
         toolbar: '#toolbar',
         strictSearch: false,
         showColumns: false,
         showRefresh: true,
         clickToSelect: true,
         showToggle:false,
         detailView: false,
         detailFormatter:"detailFormatter",
         responseHandler:function (res) {
             return  res.data;
         },
         checkbox:true,
         columns: [{
             field: 'checkbox',
             checkbox: true,
         },{
             field: 'name',
             title: 'Name',
             align: 'center',
             sortable: true,
         }]
         
    })

})


function download(){
    var seleObj = $table.bootstrapTable('getSelections');
    if(seleObj.length <= 0){
        toastr.warning('Please choose data to edit!');
        return false;
    }
    var keywordUri = $.map($table.bootstrapTable('getSelections'),function (rows){
        return rows.uri.replace(/\\/g,"%5C");
    });

    downloadKeyword(keywordUri)
}


function downloadKeyword(keywordUri){
    var url = "/keywordResources/download?keywordResourceNames="+keywordUri;
    var form = document.createElement("form");
    form.style.display = "none";
    form.action = url;
    form.method = "post";
    document.body.appendChild(form)

    form.submit();
    form.remove();
}