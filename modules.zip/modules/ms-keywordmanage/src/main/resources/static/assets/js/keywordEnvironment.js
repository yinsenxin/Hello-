var $table = $('#table');

//initialization
$(function(){

	toastr.options = {
        "closeButton": false, //是否显示关闭按钮
        "debug": false, //是否使用debug模式
        "positionClass": "toast-center-center",//弹出窗的位置
	}
	
	//Data All
    $table.bootstrapTable('destroy').bootstrapTable({
         url: "/keywordEnvironments",
         method: 'get',
         toolbar: '#toolbar',
         strictSearch: false,
         showColumns: true,
         showRefresh: true,
         clickToSelect: true,
         showToggle:false,
         responseHandler:function (res) {
             return  res.data;
         },
         checkbox:true,
         columns: [{
             field: 'checkbox',
             checkbox: true,
         },{
             field: 'id',
             title: 'Id',
             visible: false,
         },{
             field: 'name',
             title: 'Name',
             sortable: true,
         },{
             field: 'version',
             title: 'Version',
             sortable: true,
         },{
             field: 'uri',
             title: 'URI',
             sortable: true,
         },{
             field: 'keywordEnvironmentFileList',
             title: 'File(s)',
             sortable: true,
             formatter: function(data) {
                 
                return data.name;
             }
         },{
             field: 'keywordEnvironmentFileList',
             title: 'CreateDate',
             formatter: function(data) {
                 
                return data.createDate;
             }
         },{
             field: 'description',
             title: 'Description',
             visible: false,
             formatter: function(data) {
                if (data == null){
                    return "";
                }
                 return data;
              }
         }]
         
    });
    $('#fileLoad').fileinput({
    	allowedFileExtensions:['zip']
    })
 
})	

	//add button
	function addKeywordEnvironmentModal(){
		$('#checkName').text('');
		$('#add_name').val('');
		$('#add_version').val('');
		$('#add_uri').val('');
		$('#add_description').val('');
		$('#fileLoad').fileinput('clear');
		$('#addKeyWordEnviroInfo').modal('show');
	
	}
	
	//add confirm
	function addSaveButton(){
		var name = $('#add_name').val();
		var version = $('#add_version').val();
		var uri = $('#add_uri').val();
		var description = $('#add_description').val();
		var file =  document.getElementById("fileLoad").files[0];
		
		 if(name.replace(/(^\s*)|(\s*$)/g, "")==""){
	         toastr.warning('Name can not be empty!');
	         return false;
	     }
		 
		 if(version.replace(/(^\s*)|(\s*$)/g, "")==""){
	         toastr.warning('Version can not be empty!');
	         return false;
	     }
		 if(uri.replace(/(^\s*)|(\s*$)/g, "")==""){
	         toastr.warning('URI can not be empty!');
	         return false;
	     }
		 if (file == null){
		    	toastr.warning("The uploaded file is empty");
				return false;
		 }
		var formdata = new FormData();
		formdata.append("version", version);
		formdata.append("uri", uri);
		formdata.append("file", file);
		formdata.append("name", name);
		formdata.append("description", description);
		var result = addKeyWordEnviro(formdata);
	    if (result.code == 200){
	    	$('#addKeyWordEnviroInfo').modal('hide');
	    	toastr.success('Create keywordEnvironment successfully');
	    	$table.bootstrapTable('refresh');
	    } else if (result.code == 409 && result.message == "Name and URI is already exists!"){
	    	toastr.warning("Name + URI is already exists!");
	    	return false;
	    } else if(result.code == 409 && result.message == "The file already exists"){
	    	toastr.warning("The file already exists");
	    	return false;
	    }  else {
	    	$('#addKeyWordEnviroInfo').modal('hide');
	    	toastr.error(result.message);
	    	return;
	    }
		
	}
	
	//Delete modal
	function deleteKeywordEnvironmentModal(){
	    var seleObj = $table.bootstrapTable('getSelections');
	    if(seleObj.length <= 0){
	        toastr.warning('Please choose the data to delete!');
	        return false;
	    }
	    $('#waringAlert').modal('show');
	     
	}
	
	//Sure to delete 
	function deleteSave(){
	    var keywordEnvironmentId = $.map($table.bootstrapTable('getSelections'),function (rows){
	        return rows.id;
	    });
	     
	    var result = deleteKeywordEnvironment(keywordEnvironmentId);
	    if (result.code == 200 && result.message == "OK"){
	         toastr.success('Delete keywordEnvironment successfully');
	    }else {
	        toastr.warning("Data deletion failure");
	        return false;
	    }
	    $table.bootstrapTable('refresh');
	}
	
	function deleteCancel(){
		$('#cancelObj').modal('show')
	}
	
	//Cancel modal
	function doCancel(){
		
		$('#cancelObj').modal('show');
	}
	
	//Cancel YES
	function isCancelObj(){
		$('#waringAlert').modal('hide');
		$('#addKeyWordEnviroInfo').modal('hide');
	}

	/**
	 * insert Data 
	 * @returns
	 */
	function addKeyWordEnviro(obj){
		var result = {};
	    $.ajax({
	        type: 'post',
	        url: "/keywordEnvironments",
	        async: false,
	        contentType: false,
	        processData: false,
	        dataType: "json",
	        data: obj,
	        success: function(data) {
	            result = data;
	        },
	        error: function(data){
	        	result = data;
	        }
	    });
	    return result;
	}
	
	/**
	 * delete Data 
	 * @returns
	 */
	function deleteKeywordEnvironment(keywordEnvironmentId){
	    var result = {};
	    $.ajax({
	        type: 'delete',
	        url: "/keywordEnvironments/"+keywordEnvironmentId,
	        async: false,
	        contentType: false,
	        processData: false,
	        dataType: "json",
	        success: function(data) {
	            result = data;
	        },
	        error: function(data){
	            
	        }
	    });
	    return result;
	}
