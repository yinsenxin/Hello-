toastr.options.positionClass = 'toast-center-center';

var $table = $('#table');
var $deleteBtn = $('#btn_model_delete');
var $addBtn = $('#btn_model_add');


function operateFormatter(value, row, index) {
    return [
        '<button type="button" id = "statusBtn" class="RoleOfdelete btn btn-primary" >Release</button>&nbsp;&nbsp;' ,
    ].join('');
}

window.operateEvents = {
    'click .RoleOfdelete': function (e, value, row, index) {
        var obj = {};
        obj.status = 1;
        var status = row.status;
        if (status == 1){
            toastr.warning('This model has been released');
            return false;
        }
        var result = updateModelData(row.id, obj, status);
        if (result.code == 200 && result.message == 'OK'){
            row.status = 1;
            toastr.success('Update Model status successfully!');
            $table.bootstrapTable('refresh');
        }
    }

};

$('#btn_model_edit').click(function () {
        var row = $table.bootstrapTable('getSelections');

        if (row.length == 1){

            if (row[0].status == 1){
                $('#edit_addContent').attr('disabled',true);
                $('#edit_deleteContent').attr('disabled',true);
                $('#tableSet').attr('disabled',true);
            }

            $('#model_name_edit').val(row[0].name);
            $('#edit_Content').bootstrapTable('removeAll');
            editContentTable(row[0].content);
            
            var templateData = new Array();
            
            if (row[0].templates.length > 0){
            	templateData = getTemplateData(row[0].templates);
            }
            
            var templateDatas = getTemplateDatas();
            var datas = array_diff(templateDatas, templateData);

            $('#bind_Template_edit').bootstrapTable('removeAll');
            $('#target_Template_edit').bootstrapTable('removeAll');
            // 1.获取 BindTemplate 数据 id name
            editBindTemplateTable(templateData);
            // 2.获取 TargetTemplate 数据 id name
            editTargetTemplateTable(datas);

            var selectLabels = row[0].labels;
            var result = getLabelsData();
            var labelsData = result.data;
            var arr = [];
            for (var i = 0; i < labelsData.length ; i++){
                for(var j = 0; j < selectLabels.length; j++){
                    if(labelsData[i].id == selectLabels[j]){
                        arr.push(labelsData[i].id);
                    }
                }
            }
            $('#model_labels_edit').selectpicker('val', arr);
            $('#template_content_preview_edit').val('');
            $('#model_description_edit').val(row[0].description);

            $('#modal_model_edit').modal('show');

        } else {
            toastr.warning('Please select a model data to edit');
        }


});

$('#saveEdit').click(function () {
    var row = $table.bootstrapTable('getSelections');
    var obj = {};
    var name = $('#model_name_edit').val();
    var labels = $('#model_labels_edit').val();
    var description = $('#model_description_edit').val();

    if(labels == null){
        labels = [];
    }

    var contents = {};
    var rows = $('#edit_Content').bootstrapTable('getData');

    if (rows.length < 1){
        toastr.warning('Content can not be empty!');
        return;
    }
    for (var i = 0; i < rows.length; i++){
        if (rows[i].name == ''){
            toastr.warning('Content can not be empty!');
            return;
        }
        contents[rows[i].name] = rows[i].example + "  " + rows[i].description;
    }

    var template = [];
    var templates = $('#bind_Template_edit').bootstrapTable('getData');
    if (templates.length == 0){
        templates = template;
    }

    for (var index = 0; index < templates.length; index++){
        template.push(templates[index].id);
    }
    obj.name = name;
    obj.labels = labels;
    obj.status = row[0].status;
    obj.content = contents;
    obj.description = description;
    obj.templates = template;

    var result = updateModelData(row[0].id, obj, 3);
    if (result.code == 200 && result.message == 'OK'){
        toastr.success('Update Model data successfully!');
        $('#modal_model_edit').modal('hide');
        $table.bootstrapTable('refresh');
    } 
});



function array_diff(a, b) {
    for (var i = 0; i < b.length; i++) {
        for (var j = 0; j < a.length; j++) {
            if (a[j].id == b[i].id) {
                a.splice(j, 1);
                j = j - 1;
            }
        }
    }
    return a;
}

$('#btn_Reset').click(function(){
    $('#model_name_search').val('');
    let arr = [];
    $('#model_labels_search').selectpicker('val', arr);
})

$('#btn_Search').click(function(){
    var name = $('#model_name_search').val();
    var labels = $('#model_labels_search').val();
    if (labels == null){
        labels = "";
    }
    if (name == '' && labels == ""){
        InitTable();
    } else {
        $table.bootstrapTable('destroy').bootstrapTable({
            url: "/models?name=" + name + "&labels=" + labels,
            method:"get",
            toolbar: '#toolbar',
            striped: true,
            showColumns: true,
            showRefresh: true,
            pageList: [10, 20, 50, 100],
            clickToSelect: true,
            search: true,
            strictSearch: false,
            responseHandler: function(res){
                return res.data;
            },
            columns:[{
                field:'checkbox',
                checkbox: true,
            },{
                field:'id',
                title:'Model ID',
                align: 'center',
                visible: false,
            },{
                field:'status',
                title:'Status',
                formatter: function(data) {
                    var str = "";
                    if (data == 0){
                        str = "unreleased";

                    } else if(data == 1){
                        str = "released";
                    }
                    return str;
                }
            },{
                field:'name',
                title:'Name',
            },{
                field:'templates',
                title:'Templates',
                visible: false,
                formatter: function(data) {
                    return data;
                }
            },{
                field:'labels',
                title:'Labels',
                formatter: function(data) {
                    var result = getLabelsDataById(data);
                    var data = result.data;
                    var str = "";
                    for(var i = 0; i <data.length; i++ ){
                        if (str.length > 0){
                            str += ",";
                        }
                        str += data[i].name;
                    }
                    return str;
                }
            },{
                field:'lastModifyDate',
                title:'LastModifyDate',
                align: 'center'
            },{
                field:'description',
                title:'Description',
                align: 'center'
            },{
                field: 'operate',
                title: 'Operate',
                align: 'center',
                width: '20%',
                events: operateEvents,
                formatter: operateFormatter
            }],
        })
    }
})



$(document).ready(function (){
    InitTable();
});

$(function(){
    var result = getLabelsData();
    var labelsList = result.data;
    for (var index in labelsList) {
        $("#model_labels").append("<option value='"+ labelsList[index].id +"'>"+ labelsList[index].name +"</option>");
        $('#model_labels_search').append("<option value='"+ labelsList[index].id +"'>"+ labelsList[index].name +"</option>");
        $('#model_labels_edit').append("<option value='"+ labelsList[index].id +"'>"+ labelsList[index].name +"</option>")
    }

    $('#add_Content').bootstrapTable({

        url: "",
        method:"get",
        toolbar: '#toolbarModal',
        striped: true,
        showColumns: true,
        showRefresh: true,
        pageList: [10, 20, 50, 100],
        clickToSelect: true,
        search: true,
        strictSearch: false,
        columns:[{
            field:'checkbox',
            checkbox: true,
        },{
            field: 'id',
            title: 'id',
            align: 'center',
            visible: false
        },{
            field:'name',
            title:'Name',
            align: 'center',
            editable: {
                type: 'text',
                title: 'Name',
                validate: function (v) {
                    if (!v){
                        return 'The  name cannot be empty.';
                    }
                    var data = $('#add_Content').bootstrapTable('getData', true);
                    var map = [];
                    for(var i in data){
                        var element = data[i];
                        map.push(element.name);
                    }
                    if(v){
                        var flag = findName(v,map);
                        if(flag == false){
                            return 'Name already exists. Please rename param.';
                        }
                    }
                }
            }
        },{
            field:'example',
            title:'Example',
            align: 'center',
            editable: {
                type: 'text',
                title: 'Example',
                validate: function (v) {
                    if (v.replace(/(^\s*)|(\s*$)/g, "") == ""){
                        return 'The example cannot be empty.';
                    }

                }
            }
        },{
            field:'description',
            title:'Description',
            align: 'center',
            editable: {
                type: 'text',
                title: 'Description',
                validate: function (v) {
                }
            }
        }]

    });

    $('#target_Template').bootstrapTable({

        url: "/templates/valid",
        method:"get",
        striped: true,
        showColumns: false,
        showRefresh: true,
        pageList: [10, 20, 50, 100],
        clickToSelect: true,
        search: true,
        strictSearch: false,
        responseHandler: function(res){
            return res.data;
        },
        columns:[{
            field:'checkbox',
            checkbox: true,
        },{
            field: 'id',
            title: 'id',
            align: 'center',
            visible: false
        },{
            field: 'name',
            title: 'Name',
            align: 'center',
        }]

    });


    $('#bind_Template').bootstrapTable({
        url: "",
        method:"get",
        striped: true,
        showColumns: false,
        showRefresh: true,
        pageList: [10, 20, 50, 100],
        clickToSelect: true,
        search: true,
        strictSearch: false,
        responseHandler: function(res){
            return res.data;
        },
        columns:[{
            field:'checkbox',
            checkbox: true,
        },{
            field: 'id',
            title: 'id',
            align: 'center',
            visible: false
        },{
            field: 'name',
            title: 'Name',
            align: 'center',
        }]

    });

});

function editContentTable(content){
    var contentList = [];
    var arrCondition = Object.keys(content);//对象 转成 数组 得到长度
    for(var i = 0; i < arrCondition.length; i ++){
        var obj = {};
        var value = content[arrCondition[i]];
        var values = value.split("  ");
        obj.name = arrCondition[i];
        obj.example = values[0];
        obj.description = values[1];
        contentList.push(obj);
    }
    $('#edit_Content').bootstrapTable('destroy').bootstrapTable({
        url: "",
        method:"get",
        toolbar: '#toolbarModalEdit',
        striped: true,
        showColumns: true,
        showRefresh: true,
        pageList: [10, 20, 50, 100],
        clickToSelect: true,
        search: true,
        strictSearch: false,
        data : contentList,
        columns:[{
            field:'checkbox',
            checkbox: true,
        },{
            field: 'id',
            title: 'id',
            align: 'center',
            visible: false
        },{
            field:'name',
            title:'Name',
            align: 'center',
            editable: {
                type: 'text',
                title: 'Name',
                validate: function (v) {
                    if (!v){
                        return 'The  name cannot be empty.';
                    }
                    var data = $('#edit_Content').bootstrapTable('getData', true);
                    var map = [];
                    for(var i in data){
                        var element = data[i];
                        map.push(element.name);
                    }
                    if(v){
                        var flag = findName(v,map);
                        if(flag == false){
                            return 'Name already exists. Please rename param.';
                        }
                    }
                }
            }
        },{
            field:'example',
            title:'Example',
            align: 'center',
            editable: {
                type: 'text',
                title: 'Example',
                validate: function (v) {
                    if (v.replace(/(^\s*)|(\s*$)/g, "") == ""){
                        return 'The example cannot be empty.';
                    }
                }
            }
        },{
            field:'description',
            title:'Description',
            align: 'center',
            editable: {
                type: 'text',
                title: 'Description',
                validate: function (v) {
                }
            }
        }]

    });


}


function editBindTemplateTable(data){
    var datas = [];
    for(var i = 0 ;i < data.length; i ++){
        var obj = {};
        obj.id = data[i].id;
        obj.name = data[i].name;
        datas.push(obj);
    }


    $('#bind_Template_edit').bootstrapTable('destroy').bootstrapTable({

        url: "",
        method:"get",
        striped: true,
        showColumns: false,
        showRefresh: true,
        pageList: [10, 20, 50, 100],
        clickToSelect: true,
        search: true,
        strictSearch: false,
        data: datas,
        columns:[{
            field:'checkbox',
            checkbox: true,
        },{
            field: 'id',
            title: 'id',
            align: 'center',
            visible: false
        },{
            field: 'name',
            title: 'Name',
            align: 'center',
        }]

    });

}

function editTargetTemplateTable(datas){
    $('#target_Template_edit').bootstrapTable('destroy').bootstrapTable({

        url: "",
        method:"get",
        striped: true,
        showColumns: false,
        showRefresh: true,
        pageList: [10, 20, 50, 100],
        clickToSelect: true,
        search: true,
        strictSearch: false,
        data: datas,
        columns:[{
            field:'checkbox',
            checkbox: true,
        },{
            field: 'id',
            title: 'id',
            align: 'center',
            visible: false
        },{
            field: 'name',
            title: 'Name',
            align: 'center',
        }]

    });
}


//  <--
$('#btn_addLeft').click(function (){

    var row = $('#target_Template').bootstrapTable('getSelections');

    if (row.length <= 0){
        toastr.warning('Please choose the data to add from Target Template Table!');
        return false;
    }

    for (var i = 0; i < row.length; i++){

        $('#bind_Template').bootstrapTable('insertRow', {

            index:0,
            row:{id:row[i].id, name:row[i].name }

        });

        $('#target_Template').bootstrapTable('remove', {

            field:'id',
            values: row[i].id,

        });

    }

})

$('#btn_edit_addLeft').click(function () {
    var row = $('#target_Template_edit').bootstrapTable('getSelections');

    if (row.length <= 0){
        toastr.warning('Please choose the data to add from Target Template Table!');
        return false;
    }

    for (var i = 0; i < row.length; i++){

        $('#bind_Template_edit').bootstrapTable('insertRow', {

            index:0,
            row:{id:row[i].id, name:row[i].name }

        });

        $('#target_Template_edit').bootstrapTable('remove', {

            field:'id',
            values: row[i].id,

        });

    }
})


// -->
$('#btn_addRight').click(function (){

    var row = $('#bind_Template').bootstrapTable('getSelections');

    if (row.length <= 0){
        toastr.warning('Please choose the data to add from Bind Template Table!');
        return false;
    }

    for (var i = 0; i < row.length; i++){

        $('#target_Template').bootstrapTable('insertRow', {

            index:0,
            row:{id:row[i].id, name:row[i].name }

        });

        $('#bind_Template').bootstrapTable('remove', {

            field:'id',
            values: row[i].id,

        });

    }

})

$('#btn_edit_addRight').click(function (){

    var row = $('#bind_Template_edit').bootstrapTable('getSelections');

    if (row.length <= 0){
        toastr.warning('Please choose the data to add from Bind Template Table!');
        return false;
    }

    for (var i = 0; i < row.length; i++){

        $('#target_Template_edit').bootstrapTable('insertRow', {

            index:0,
            row:{id:row[i].id, name:row[i].name }

        });

        $('#bind_Template_edit').bootstrapTable('remove', {

            field:'id',
            values: row[i].id,

        });

    }

})


// button preview
$('#btn_preview').click(function (){

    var row = $('#bind_Template').bootstrapTable('getSelections');
    if (row.length == 1){
        var obj = {};
        // template Content data
        var templateId = row[0].id;
        var result = getTemplateData(templateId);
        
        var templateContent = result[0].content;


        var modelContent = {};
        var rows = $('#add_Content').bootstrapTable('getData');

        if (rows.length < 1){
            toastr.warning('Content can not be empty!');
            return false;
        }
        for (var i = 0; i < rows.length; i++){
            if (rows[i].name == ''){
                toastr.warning('Content can not be empty!');
                return false;
            }
            modelContent[rows[i].name] = rows[i].example + "  " + rows[i].description;
        }

        obj.templateContent = templateContent;
        obj.modelContent = modelContent;


        var result = dataMapping(obj);

        var value = result.data;

        $('#template_content_preview').val(value);

    } else {
        toastr.warning("Please select a Bind template to preview!");

    }

})


$('#btn_edit_preview').click(function (){

    var row = $('#bind_Template_edit').bootstrapTable('getSelections');
    if (row.length == 1){
        var obj = {};
        // template Content data
        var templateId = row[0].id;
        var result = getTemplateData(templateId);
        var templateContent = result[0].content;

        var modelContent = {};
        var rows = $('#edit_Content').bootstrapTable('getData');

        if (rows.length < 1){
            toastr.warning('Content can not be empty!');
            return false;
        }
        for (var i = 0; i < rows.length; i++){
            if (rows[i].name == ''){
                toastr.warning('Content can not be empty!');
                return false;
            }
            modelContent[rows[i].name] = rows[i].example + "  " + rows[i].description;
        }

        obj.templateContent = templateContent;
        obj.modelContent = modelContent;

        console.log(obj);

        var result = dataMapping(obj);

        var value = result.data;

        $('#template_content_preview_edit').val(value);

    } else {
        toastr.warning("Please select a Bind template to preview!");

    }
});





function findName(name,map){
    var result = true;
    var tmp = map.indexOf(name);
    if(tmp != -1){
        result = false;
        return result;
    }
    return result;
}

var conditionId = 100;

$('#add_addContent').click(function (){

    conditionId++;

    $('#add_Content').bootstrapTable('insertRow',
        {index:0,
            row:{
                id:conditionId,
                name:"",
                example:"Test",
                description:"",
            }
        }
    );
})

$('#edit_addContent').click(function (){

    conditionId++;

    $('#edit_Content').bootstrapTable('insertRow',
        {index:0,
            row:{
                id:conditionId,
                name:"",
                example:"Test",
                description:"",
            }
        }
    );
})

$('#add_deleteContent').click(function () {

    var ids = $.map($('#add_Content').bootstrapTable('getSelections'), function (row) {
        return row.id;
    });

    if (ids.length <= 0){
        toastr.warning('Please choose the data to delete! ');
        return false;
    }

    $('#add_Content').bootstrapTable('remove', {
        field: 'id',
        values: ids,
    });

});

$('#edit_deleteContent').click(function () {

    var ids = $.map($('#edit_Content').bootstrapTable('getSelections'), function (row) {
        return row.checkbox;
    });

    if (ids.length <= 0){
        toastr.warning('Please choose the data to delete! ');
        return false;
    }

    $('#edit_Content').bootstrapTable('remove', {
        field: 'checkbox',
        values: ids,
    });

});


function InitTable(){

    $table.bootstrapTable('destroy').bootstrapTable({
        url: "/models",
        method:"get",
        toolbar: '#toolbar',
        striped: true,
        showColumns: true,
        showRefresh: true,
        pageList: [10, 20, 50, 100],
        clickToSelect: true,
        search: true,
        strictSearch: false,
        responseHandler: function(res){
            return res.data;
        },
        columns:[{
            field:'checkbox',
            checkbox: true,
        },{
            field:'id',
            title:'Model ID',
            align: 'center',
            visible: false,
        },{
            field:'status',
            title:'Status',
            formatter: function(data) {
                var str = "";
                if (data == 0){
                    str = "unreleased";

                } else if(data == 1){
                    str = "released";
                }
                return str;
            }
        },{
            field:'name',
            title:'Name',
        },{
            field:'templates',
            title:'Templates',
            visible: false,
            formatter: function(data) {
                return data;

            }
        },{
            field:'labels',
            title:'Labels',
            formatter: function(data) {
                var result = getLabelsDataById(data);
                var data = result.data;
                var str = "";
                for(var i = 0; i <data.length; i++ ){
                    if (str.length > 0){
                        str += ",";
                    }
                    str += data[i].name;
                }
                return str;
            }
        },{
            field:'lastModifyDate',
            title:'LastModifyDate',
            align: 'center'
        },{
            field:'description',
            title:'Description',
            align: 'center'
        },{
            field: 'operate',
            title: 'Operate',
            align: 'center',
            width: '20%',
            events: operateEvents,
            formatter: operateFormatter
        }]
    });

}


function getSelectionData(){
    var row = $table.bootstrapTable('getSelections');
    return row;
}


// add button
$addBtn.click(function(){

    $('#model_name').val('');
    $('#model_content').val('');
    $('#model_description').val('');
    $('#model_labels').selectpicker('val',"");
    $('#add_Content').bootstrapTable('removeAll')
    $('#bind_Template').bootstrapTable('removeAll')
    $('#target_Template').bootstrapTable('refresh')
    $('#template_content_preview').val('');
    $('#modal_model_add').modal('show');

})


// save add
function saveAddModel(){
    var obj = {};

    var name = $('#model_name').val();
    var labels = $('#model_labels').val();
    var description = $('#model_description').val();

    if(name.replace(/(^\s*)|(\s*$)/g, "") == ""){
        toastr.warning('Name can not be empty!');
        return false;
    }
    if(labels == null){
        labels = [];
    }

    var contents = {};
    var row = $('#add_Content').bootstrapTable('getData');

    if (row.length < 1){
        toastr.warning('Content can not be empty!');
        return false;
    }
    for (var i = 0; i < row.length; i++){
        if (row[i].name == ''){
            toastr.warning('Content can not be empty!');
            return false;
        }
        contents[row[i].name] = row[i].example + "  " + row[i].description;
    }

    var template = [];
    var templates = $('#bind_Template').bootstrapTable('getData');
    if (templates.length == 0){
        templates = template;
    }

    for (var index = 0; index < templates.length; index++){
        template.push(templates[index].id);
    }

    obj.name = name;
    obj.labels = labels;
    obj.status = 0;
    obj.content = contents;
    obj.description = description;
    obj.templates = template;

    var result = addModelData(obj);
    if (result.code == 200 && result.message == 'OK'){
        toastr.success('Create Model data successfully!');
        $('#modal_model_add').modal('hide');
    }
    InitTable();
}



function showCancelModal(){

    $('#model_add_cancel').modal('show');
}

function addCancel(){
    $('#modal_model_add').modal('hide');
}

function showCancelModalEdit(){

    $('#model_edit_cancel').modal('show');
}

function editCancel(){
    $('#modal_model_edit').modal('hide');
}


// delete button
$deleteBtn.click(function(){

    var row = getSelectionData();
    if (row.length == 0){
        toastr.warning("Please select the data to delete!");
        return false;
    } else {
        $('#model_name_delete').val('');
        $('#YES').attr('disabled',true);
        $('#waringAlert').modal('show');
    }

})


$('#model_name_delete').keyup(function(){
    var name = $('#model_name_delete').val();
    if (name != "delete model"){
        $('#YES').attr('disabled',true);
    }

})


$('#model_name_delete').keyup(function(){
    var name = $('#model_name_delete').val();
    if (name == "delete model"){

        $('#YES').attr('disabled',false);

    }
})




// save delete
function saveDelete(){
    var row = getSelectionData();
    var modelIds = new Array();
    $(row).each(function(){
        modelIds.push(this.id);
    })

    var result = deleteTemplateData(modelIds);
    if (result.data == 200 && result.message == 'OK'){
        toastr.success("Delete this data successfully!");
    }
    InitTable();
}


function getTemplateData(templateId){
    var result = {};
    $.ajax({
        type: 'get',
        url: "/templates?templateIds=" + templateId,
        async: false,
        contentType: "application/json",
        dataType: "json",
        success: function(data) {
            result = data.data;
        },
        error: function(data){
            toastr.error(data.responseJSON.message);
        }
    })
    return result;
}

function getTemplateDatas(){
    var result = {};
    $.ajax({
        type: 'get',
        url: "/templates/valid",
        async: false,
        contentType: "application/json",
        dataType: "json",
        success: function(data) {
            result = data.data;
        },
        error: function(data){
            toastr.error(data.responseJSON.message);
        }
    })
    return result;
}



function getLabelsData(){
    var result = {};
    $.ajax({
        type: 'get',
        url: "/labels",
        async: false,
        contentType: "application/json",
        dataType: "json",
        success: function(data) {
            result = data;
        },
        error: function(data){
            toastr.error(data.responseJSON.message);
        }
    })
    return result;
}


function deleteTemplateData(modelIds){
    var result = {};
    $.ajax({
        type: 'delete',
        url: "/models/"+modelIds,
        async: false,
        contentType: "application/json",
        dataType: "json",
        success: function(data) {
            result = data;
        },
        error: function(data){
            toastr.error(data.responseJSON.message);
        }
    })
    return result;
}

// add model data
function addModelData(obj){
    var result = {};
    $.ajax({
        type: 'post',
        url: "/models",
        async: false,
        contentType: "application/json",
        dataType: "json",
        data:JSON.stringify(obj),
        success: function(data) {
            result = data;
        },
        error: function(data){
            toastr.error(data.responseJSON.message);
        }
    })
    return result;
}

//add model data
function updateModelData(modelId, obj, type){
    var  url;
    if (type < 2){
        url = "/models?modelId=" + modelId + "&type=" + type;
    } else {
        url = "/models?modelId=" + modelId;
    }
    var result = {};
    $.ajax({
        type: 'put',
        url: url,
        async: false,
        contentType: "application/json",
        dataType: "json",
        data:JSON.stringify(obj),
        success: function(data) {
            result = data;
        },
        error: function(data){
            toastr.error(data.responseJSON.message);
        }
    })
    return result;
}



function dataMapping(obj){
    var result = {};
    $.ajax({
        type: 'post',
        url: "/scripts",
        async: false,
        contentType: "application/json",
        dataType: "json",
        data:JSON.stringify(obj),
        success: function(data) {
            result = data;
        },
        error: function(data){
            toastr.error('request fail');
        }
    })
    return result;
}

function getLabelsDataById(labelId){
    var result = {};
    $.ajax({
        type: 'get',
        url: "/labels/label?labelIds=" + labelId,
        async: false,
        contentType: "application/json",
        dataType: "json",
        success: function(data) {
            result = data;
        },
        error: function(data){
            toastr.error(data.responseJSON.message);
        }
    })
    return result;
}
