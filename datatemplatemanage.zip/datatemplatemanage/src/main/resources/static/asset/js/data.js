toastr.options.positionClass = 'toast-center-center';
var $table = $('#table');
var $btn_data_add = $('#btn_data_add');
var $btn_data_edit = $('#btn_data_edit');
var $btn_data_view = $('#btn_data_view');
var $btn_data_delete = $('#btn_data_delete');

// add SelectModel
var datas = [];
// add bindTempalte
var templates = [];

$('#btn_Reset').click(function(){
	$('#name_search').val('');
	let arr = [];
	$('#labels_search').selectpicker('val', arr);
})

$('#btn_Search').click(function(){
	var name = $('#name_search').val();
	var labels = $('#labels_search').val();
	if (labels == null){
		labels = "";
	}
	if (name == '' && labels == ""){
		InitTable();
	} else {
		$table.bootstrapTable('destroy').bootstrapTable({
			url: "/datasets?name=" + name + "&labels=" + labels,
			method:"get",
			toolbar: '#toolbar',
			striped: true,
			showColumns: true,
			showRefresh: true,
			pageList: [10, 20, 50, 100],
			clickToSelect: true,
			search: true,
			strictSearch: false,
			responseHandler: function(res){
				return res.data;
			},
			columns:[{
				field:'checkbox',
				checkbox: true,
			},{
				field:'id',
				title:'Data ID',
				align: 'center',
				visible: false,
			},{
				field:'name',
				title:'Name',
				align: 'center',
			},{
				field:'labels',
				title:'Labels',
				align:'center',
				formatter: function(data) {
					var result = getLabelsDataById(data);
					var data = result.data;
					var str = "";
					for(var i = 0; i <data.length; i++ ){
						if (str.length > 0){
							str += ",";
						}
						str += data[i].name;
					}
					return str;
				}
			},{
				field:'type',
				title:'Type',
				align:'center',
				formatter: function(data) {
					
					return data;
				}
			},{
				field:'modelId',
				title:'model Name',
				align:'center',
				formatter: function(data) {
					var result = getModelDataById(data);
					var str = '';
					for (var index = 0; index < result.length; index++){
						str += result[index].name;
					}
					return str;
				}
			},{
				field:'lastModifyDate',
				title:'LastModifyDate',
				align:'center',
			},{
				field:'description',
				title:'Description',
				align: 'center',
				formatter: function(data) {
					if (data == null){
						return "";
					}
					return data;
				}
			}]
		})
	}
})


$(function(){
	InitTable();

})


function InitTable(){
	$table.bootstrapTable('destroy').bootstrapTable({
		url: "/datasets",
		method:"get",
		toolbar: '#toolbar',
		striped: true,
		showColumns: true,
		showRefresh: true,
		pageList: [10, 20, 50, 100],
		clickToSelect: true,
		search: true,
		strictSearch: false,
		responseHandler: function(res){
			return res.data;
		},
		columns:[{
			field:'checkbox',
			checkbox: true,
		},{
			field:'id',
			title:'Data ID',
			align: 'center',
			visible: false,
		},{
			field:'name',
			title:'Name',
			align: 'center',
		},{
			field:'labels',
			title:'Labels',
			align:'center',
			formatter: function(data) {
				var result = getLabelsDataById(data);
				var data = result.data;
				var str = "";
				for(var i = 0; i <data.length; i++ ){
					if (str.length > 0){
						str += ",";
					}
					str += data[i].name;
				}
				return str;
			}
		},{
			field:'type',
			title:'Type',
			align:'center',
			formatter: function(data) {
				
				return data;
			}
		},{
			field:'modelId',
			title:'model Name',
			align:'center',
			formatter: function(data) {
				var result = getModelDataById(data);
				var str = '';
				for (var index = 0; index < result.length; index++){
					str += result[index].name;
				}
				return str;
			}
		},{
			field:'lastModifyDate',
			title:'LastModifyDate',
			align:'center',
		},{
			field:'description',
			title:'Description',
			align: 'center',
			formatter: function(data) {
				if (data == null){
					return "";
				}
				return data;
			}
		}]
	});

}

$(function (){

	var result = getLabelsData();
	for (var index = 0; index < result.length; index++){
		$('#data_labels').append('<option value = '+result[index].id+'>'+result[index].name+'</option>');
		$('#data_labels_edit').append('<option value = '+result[index].id+'>'+result[index].name+'</option>');
		$('#labels_search').append('<option value = '+result[index].id+'>'+result[index].name+'</option>');

	}

})


$btn_data_add.click(function(){
	$('#modelName').empty();
	var result = getModelData();
	for (var i = 0; i < result.length; i++){
		if (result[i].status == 1){
			var data = {};
			data.id = result[i].id;
			data.name = result[i].name;
			datas.push(data);
		}
	}
	for (var index = 0; index < datas.length; index++){
		$('#modelName').append('<option value = '+datas[index].id+'>'+datas[index].name+'</option>');
	}
	datas = [];
	$('#modal_add').modal('show');
})

function cancel(){
	$('#modal_add').modal('hide');
}

function next(){
	var modelName = $('#modelName').val();
	if (modelName == null){
		toastr.warning('Model is must not be null, Please add model data!');
		return;
	}
	//$('#modal_add').modal('hide');
	$('#data_name').val('');
	var model = $('#modelName option:selected').text();//选中的文本
	$('#data_model').val(model);
	$('#data_description').val('');
	$('#data_labels').selectpicker('val',"")

	var columns = [{
		field:'checkbox',
		checkbox: true,
	},{
		field:'CaseID',
		title:'CaseID',
	},{
		field:'labels',
		title:'labels',
		editable: {
			type: 'text',
			validate: function (v) {
			}
		}
	},{
		field:'conditions',
		title:'conditions',
		editable: {
			type: 'text',
			validate: function (v) {
			}
		}
	},{
		field:'template',
		title:'template',
	}];

	var result = getModelDataById(modelName);
	if (result.length == 0){
		toastr.warning('Model data is null!');
		return false;
	}
	var content = [];
	for(var i = 0; i < result.length; i++){
		content = Object.keys(result[i].content);
	}
	for (var j = 0; j < content.length; j++){
		columns.push({ "field": content[j], "title": content[j],"editable":{type: "text",validate: function (v) {}}
		});
	}

	$('#add_Content').bootstrapTable('destroy').bootstrapTable({
		toolbar: '#toolbarModal',
		striped: true,
		showColumns: true,
		showRefresh: true,
		pageList: [10, 20, 50, 100],
		clickToSelect: true,
		search: true,
		strictSearch: false,
		showExport: true,
		exportDataType: 'all',
		exportTypes: ['csv'],
		uniqueId:'CaseID',
		columns:columns,
	});

	// delete button
	$('#add_Content_delete').click(function (){

		var ids = $.map($('#add_Content').bootstrapTable('getSelections'), function (row) {
			return row.checkbox;
		});

		if (ids.length) {
			$('#add_Content').bootstrapTable('remove', {
				field: 'checkbox',
				values: ids,
			});
		} else {
			toastr.warning('Please select a data delete');
		}

	})

	// bind button
	$('#add_Content_bind').click(function (){

		$('#templateName').empty();
		var ids = $.map($('#add_Content').bootstrapTable('getSelections'), function (row) {
			return row.checkbox;
		});

		if (ids.length) {

			var result = getModelDataById(modelName);
			templates = result[0].templates;

			if (templates.length){
				var templateData = getTemplateDataById(templates);

				$('#templateName').append('<option value=""></option>');
				for (var i = 0; i < templateData.length; i ++){
					$('#templateName').append('<option value = '+templateData[i].id+'>'+templateData[i].name+'</option>');
				}
			}
			if (templates.length == 0){
				toastr.warning("Template data is null!");
			}
			$('#add_data_bind').modal('show');
			templates = [];
		} else {
			toastr.warning('Please select a data delete');
		}
	})

	$('#bindTemplateSave').click(function(){

		var ids = $.map($('#add_Content').bootstrapTable('getSelections'), function (row) {
			return row.CaseID;
		});
		var tempalteName = $('#templateName option:selected').text();
		for (var i = 0; i < ids.length; i ++){
			$('#add_Content').bootstrapTable('updateByUniqueId', {
				id: ids[i],
				row: {
					template:tempalteName
				}
			});
		}

	})

	$('#add_Content_import').click(function(){
		$('#file').trigger('click');
	})

	$('#modal_data_add').modal('show');
}

function importData(files){

	var modelId = $('#modelName').val();
	if (files.length){
		var file = files[0];//js 获取文件对象
		var name = file.name;
		$('#file').replaceWith('<input id="file" name="file" type="file" style="filter:alpha(opacity=0);opacity:0;width: 0;height: 0;" onchange="importData(this.files)">');
		var file_typename =   file.name.substring(file.name.lastIndexOf('.'));
		if (file_typename === '.csv' || file_typename === '.CSV') {
			var form = new FormData(); // FormData 对象
			form.append("file", file); // 文件对象

			var result = ImportParseData(form, modelId);
			if (result.code == 200){
				toastr.success("Import file successfully!");
			}
			$('#add_Content').bootstrapTable('removeAll');
			var data = result.data;
			$('#add_Content').bootstrapTable('append',data);

		}else {
			toastr.warning("Please select the correct file type such as CSV");
			return false;
		}
	}
}


// cancel add
function showCancelModal(){

	$('#modal_data_add').modal('hide');
}
// cancel sure
function addCancel(){
	$('#modal_data_add').modal('hide');
}



// save add
function saveAdd(){

	var modelData = $('#add_Content').bootstrapTable('getData');
	var obj = {};
	var name = $('#data_name').val();
	var description = $('#data_description').val();
	if(name.replace(/(^\s*)|(\s*$)/g, "") == ""){
		toastr.warning('Name can not be empty!');
		return false;
	}
	var labels = $('#data_labels').val();
	if (labels == null){
		labels = [];
	}
	var type = $('#data_type').val();
	if(type.replace(/(^\s*)|(\s*$)/g, "") == ""){
		toastr.warning('Type can not be empty!');
		return false;
	}
	var modelName = $('#modelName').val();
	if (modelName == null){
		toastr.warning('Model is must not be null, Please add model data!');
		return;
	}
	obj.name = name;
	obj.labels = labels;
	obj.type = type;
	obj.modelId = modelName;
	obj.description = description;
	if (modelData.length){
		obj.modelContent = modelData;
	} else {
		toastr.warning('Model Content can not be empty!');
		return ;
	}
	
	for (var i = 0; i < modelData.length; i ++){
		if (modelData[i].template == ""){
			$('#modelContent_add_cancel').modal('show');
			return;
		}
	}
	
	var result = addDataSet(obj);
	if (result.code == 200 && result.message == 'OK'){
		toastr.success("Add data is successfully!");
	}
	$('#modal_add').modal('hide');
	$('#modal_data_add').modal('hide');
	InitTable();
}

function addContinue(){
	var modelData = $('#add_Content').bootstrapTable('getData');
	var obj = {};
	var name = $('#data_name').val();
	var description = $('#data_description').val();
	if(name.replace(/(^\s*)|(\s*$)/g, "") == ""){
		toastr.warning('Name can not be empty!');
		return false;
	}
	var labels = $('#data_labels').val();
	if (labels == null){
		labels = [];
	}
	var type = $('#data_type').val();
	if(type.replace(/(^\s*)|(\s*$)/g, "") == ""){
		toastr.warning('Type can not be empty!');
		return false;
	}
	var modelName = $('#modelName').val();
	if (modelName == null){
		toastr.warning('Model is must not be null, Please add model data!');
		return;
	}
	obj.name = name;
	obj.labels = labels;
	obj.type = type;
	obj.modelId = modelName;
	obj.description = description;
	if (modelData.length){
		obj.modelContent = modelData;
	} else {
		toastr.warning('Model Content can not be empty!');
		return ;
	}
	
	var result = addDataSet(obj);
	if (result.code == 200 && result.message == 'OK'){
		toastr.success("Add data is successfully!");
	}
	$('#modal_add').modal('hide');
	$('#modal_data_add').modal('hide');
	InitTable();
}




// edit dialog
$btn_data_edit.click(function () {
	var row = $table.bootstrapTable('getSelections');
	if (row.length != 1){
		toastr.warning('Please select a data to edit!');
		return ;
	}
	$('#data_name_edit').val(row[0].name);
	$('#data_type_edit').val(row[0].type);
	$('#data_description_edit').val(row[0].description);

	var selectLabels = row[0].labels;
	var labelsData = getLabelsData();
	var arr = [];
	for (var i = 0; i < labelsData.length ; i++){
		for(var j = 0; j < selectLabels.length; j++){
			if(labelsData[i].id == selectLabels[j]){
				arr.push(labelsData[i].id);
			}
		}
	}
	$('#data_labels_edit').selectpicker('val', arr);

	var modelId = row[0].modelId;
	if (modelId != null){
		var result = getModelDataById(modelId);
		$('#data_model_edit').val(result[0].name);
	}
	var columns = [{
		field:'checkbox',
		checkbox: true,
	},{
		field:'CaseID',
		title:'CaseID',
	},{
		field:'labels',
		title:'labels',
		editable: {
			type: 'text',
			validate: function (v) {
			}
		}
	},{
		field:'conditions',
		title:'conditions',
		editable: {
			type: 'text',
			validate: function (v) {
			}
		}
	},{
		field:'template',
		title:'template',
	},{
		field:'status',
		title:'status',
		formatter: function(data) {
			if (data == null){
				return "";
			}
			return data;
		}
	}];
	var content = [];
	for(var i = 0; i < result.length; i++){
		content = Object.keys(result[i].content);
	}
	for (var j = 0; j < content.length; j++){
		columns.push({ "field": content[j], "title": content[j],"editable":{type: "text",validate: function (v) {}}
		});
	}

	$('#edit_Content').bootstrapTable('removeAll');
	$('#edit_Content').bootstrapTable('destroy').bootstrapTable({
		toolbar: '#toolbarModalEdit',
		striped: true,
		showColumns: true,
		showRefresh: true,
		pageList: [10, 20, 50, 100],
		clickToSelect: true,
		search: true,
		strictSearch: false,
		showExport: true,
		exportDataType: 'all',
		exportTypes: ['csv'],
		uniqueId:'CaseID',
		columns:columns,
	});
	var datas = row[0].modelContent;
	$('#edit_Content').bootstrapTable('append', datas);
	
	$('#edit_data').modal('show');
})


// delete button
$('#edit_Content_delete').click(function (){

	var ids = $.map($('#edit_Content').bootstrapTable('getSelections'), function (row) {
		return row.checkbox;
	});

	if (ids.length) {
		$('#edit_Content').bootstrapTable('remove', {
			field: 'checkbox',
			values: ids,
		});
	} else {
		toastr.warning('Please select a data delete');
	}

})

// bind button
$('#edit_Content_bind').click(function (){
	$('#templateNameEdit').empty();
	var ids = $.map($('#edit_Content').bootstrapTable('getSelections'), function (row) {
		return row.checkbox;
	});
	var row = $table.bootstrapTable('getSelections');
	if (ids.length) {
		if (row[0].modelId == ""){
			toastr.warning("modelId is Invalid");
			return ;
		}
		var result = getModelDataById(row[0].modelId);
		templates = result[0].templates;
		if (templates.length){
			var templateData = getTemplateDataById(templates);
			$('#templateNameEdit').append('<option value=""></option>');
			for (var i = 0; i < templateData.length; i ++){
				$('#templateNameEdit').append('<option value = '+templateData[i].id+'>'+templateData[i].name+'</option>');
			}
		}
		if (templates.length == 0){
			toastr.warning("Template data is null!");
		}
		$('#edit_data_bind').modal('show');
		templates = [];


	} else {
		toastr.warning('Please select a data delete');
	}
})

// bind save
$('#bindTemplateEditSave').click(function(){
	var ids = $.map($('#edit_Content').bootstrapTable('getSelections'), function (row) {
		return row.CaseID;
	});
	var tempalteName = $('#templateNameEdit option:selected').text();
	for (var i = 0; i < ids.length; i ++){
		$('#edit_Content').bootstrapTable('updateByUniqueId', {
			id: ids[i],
			row: {
				template:tempalteName
			}
		});
	}
})

// import button
$('#edit_Content_import').click(function(){
	$('#fileEdit').trigger('click');
})

function importDataEdit(files){

	var row = $table.bootstrapTable('getSelections');

	var modelId = row[0].modelId;
	var dataId = row[0].id;
	if (modelId == ""){
		toastr.warning("modelId is Invalid");
	}
	if (dataId == ""){
		toastr.warning("dataId is Invalid");
	}

	if (files.length){
		var file = files[0];//js 获取文件对象
		$('#fileEdit').replaceWith('<input id="fileEdit" name="file" type="file" style="filter:alpha(opacity=0);opacity:0;width: 0;height: 0;" onchange="importDataEdit(this.files)">');
		var file_typename =   file.name.substring(file.name.lastIndexOf('.'));
		if (file_typename === '.csv' || file_typename === '.CSV') {
			var form = new FormData(); // FormData 对象
			form.append("file", file); // 文件对象

			var result = ImportParseDataEdit(form, modelId, dataId);
			if (result.code == 200){
				toastr.success("Import file successfully!");
			}
			$('#edit_Content').bootstrapTable('removeAll');
			var data = result.data;
			$('#edit_Content').bootstrapTable('append',data);
			var content = result.content;
			if (content.length == 0){
				toastr.warning('Model Content already exists!');
			} else {
				var ids = [];
				var status = [];
				for (var i = 0; i < content.length; i ++){
					ids.push(content[i].CaseID);
					status.push(content[i].status);
				}
				
				for (var i = 0; i < ids.length; i ++){
					$('#edit_Content').bootstrapTable('updateByUniqueId', {
						id: ids[i],
						row: {
							status:status[i]
						}
					});
				}
				
			}
		}else {
			toastr.warning("Please select the correct file type such as CSV");
			return false;
		}
	}
}


// save edit
function saveEdit() {
	var obj = {};
	var labels = $('#data_labels_edit').val();
	if (labels == null){
		labels = [];
	}
	var type = $('#data_type_edit').val();
	if(type.replace(/(^\s*)|(\s*$)/g, "") == ""){
		toastr.warning('Type can not be empty!');
		return false;
	}

	var row = $table.bootstrapTable('getSelections');

	if (row[0].modelId == null){
		toastr.warning('Model is must not be null, Please add model data!');
		return;
	}

	var datas = $('#edit_Content').bootstrapTable('getData');
	var description = $('#data_description_edit').val();
	
	obj.labels = labels;
	obj.type = type;
	obj.modelContent = datas;
	obj.description = description;

	for (var i = 0; i < datas.length; i ++){
		if (datas[i].template == ""){
			$('#modelContent_edit_cancel').modal('show');
			return;
		}
	}
	var result = updateDataSet(obj, row[0].id);

	if (result.code == 200 && result.message == 'OK'){
		toastr.success('Edit dataset is successfully!');
		$('#edit_data').modal('hide');
	}
	InitTable();
}

function editContinue(){
	var obj = {};
	var labels = $('#data_labels_edit').val();
	if (labels == null){
		labels = [];
	}
	var type = $('#data_type_edit').val();
	if(type.replace(/(^\s*)|(\s*$)/g, "") == ""){
		toastr.warning('Type can not be empty!');
		return false;
	}
	var row = $table.bootstrapTable('getSelections');
	if (row[0].modelId == null){
		toastr.warning('Model is must not be null, Please add model data!');
		return;
	}
	var datas = $('#edit_Content').bootstrapTable('getData');
	var description = $('#data_description_edit').val();

	obj.labels = labels;
	obj.type = type;
	obj.modelContent = datas;
	obj.description = description;
	var result = updateDataSet(obj, row[0].id);
	if (result.code == 200 && result.message == 'OK'){
		toastr.success('Edit dataset is successfully!');
		$('#edit_data').modal('hide');
	}
	InitTable();
}






function editCancel(){
	$('#model_edit_cancel').modal('show');
}
function editModalCancel(){
	$('#edit_data').modal('hide');
}

// delete button
$btn_data_delete.click( function(){

	var row = $table.bootstrapTable('getSelections');
	if (row.length <= 0 ){
		toastr.warning('Please select the data to delete!');
		return ;
	}
	$('#waringAlert').modal('show');
})

// delete save
function saveDelete(){
	var row = $table.bootstrapTable('getSelections');
	var dataId = [];
	for (var i = 0; i < row.length; i ++){
		dataId.push(row[i].id);
	}
	var result = deleteDataById(dataId);
	if (result.code == 200 && result.message == 'OK'){
		toastr.success('Delete the data is successfully!');
	}
	InitTable();
}

$('#btn_data_export_local').click(function () {
	var row = $table.bootstrapTable('getSelections');
	if (row.length == 1){
		
		var type = row[0].type;
		if (type == "case"){
			$('#caseExport').modal('show');
		}
		 if (type == "file"){
			 $('#data_filetype').val('');
			$('#selectFileType').modal('show');
		}
		
	} else {
		toastr.warning('Please select a data to export!');
		return;
	}
})

$('#Save_CaseExport').click(function (){
	var type = $('#caseType').val();
	var data = {};
	var rows = $table.bootstrapTable('getSelections');
	data.dataId = rows[0].id;
	
	var url = "/datasets/export?type="+type;
	var form = document.createElement("form");
    form.style.display = "none";
    form.action = url;
    form.method = "post";
    document.body.appendChild(form)
	
    for (var key in data) {
        var input = document.createElement("input");
        input.type = "hidden";
        input.name = key;
        input.value = data[key];
        form.appendChild(input);
      }
      form.submit();
      form.remove();
})

$('#Save_FileExport').click(function (){

	var fileType = "txt,py,robot,groove,md,word,csv,xls,java";
	
	var type = $('#data_filetype').val();
	var rs = fileType.indexOf(type);
	if (rs == -1){
		toastr.warning('Please enter a valid file type');
		return;
	} 
	
	var data = {};
	var rows = $table.bootstrapTable('getSelections');
	data.dataId = rows[0].id;
	
	var url = "/datasets/export?type="+type;
	var form = document.createElement("form");
    form.style.display = "none";
    form.action = url;
    form.method = "post";
    document.body.appendChild(form)
	
    for (var key in data) {
        var input = document.createElement("input");
        input.type = "hidden";
        input.name = key;
        input.value = data[key];
        form.appendChild(input);
      }
      form.submit();
      form.remove();

})



$('#btn_data_export_case').click(function () {
	var row = $table.bootstrapTable('getSelections');
	if (row.length == 1){

		var type = row[0].type;
		
		 if (type == "file"){
			 toastr.warning("type must be case");
			 return ;
		}
		
		var result = exportCaseManage(row[0].id);
		if (result.code == 200 && result.message == 'OK'){
			toastr.success('Export data to caseManager successfully!');
		} else if(result.code == 500) {
			toastr.warning(result.message);
		}

	} else {
		toastr.warning('Please select a data to export!');
		return;
	}

})


function exportCaseManage(dataId){

	var result = {};
	$.ajax({
		type: 'post',
		url: "/datasets/export/exportCase?datasetId="+ dataId,
		contentType: "application/json",
		dataType: "json",
		async: false,
		success: function(data) {
			result = data;
		},
		error: function(data){
			toastr.error(data.responseJSON.message);
		}
	})
	return result;
}

// Get model data
function getModelData(){
	var result = {};
	$.ajax({
		type: 'get',
		url: "/models",
		contentType: "application/json",
		dataType: "json",
		async: false,
		success: function(data) {
			result = data.data;
		},
		error: function(data){
			toastr.error(data.responseJSON.message);
		}
	})
	return result;
}

// Get special model data
function getModelDataById(modelIds){
	var result = {};
	$.ajax({
		type: 'get',
		url: "/models?modelIds="+modelIds,
		contentType: "application/json",
		dataType: "json",
		async: false,
		success: function(data) {
			result = data.data;
		},
		error: function(data){
			toastr.error(data.responseJSON.message);
		}
	})
	return result;
}

// Get templates data
function getLabelsData(){
	var result = {};
	$.ajax({
		type: 'get',
		url: "/labels",
		async: false,
		contentType: "application/json",
		dataType: "json",
		success: function(data) {
			result = data.data;
		},
		error: function(data){
			toastr.error(data.responseJSON.message);
		}
	})
	return result;
}

// Get labels data
function getLabelsDataById(labelId){
	var result = {};
	$.ajax({
		type: 'get',
		url: "/labels/label?labelIds=" + labelId,
		async: false,
		contentType: "application/json",
		dataType: "json",
		success: function(data) {
			result = data;
		},
		error: function(data){
			toastr.error(data.responseJSON.message);
		}
	})
	return result;
}

// Get templates data
function getTemplateDataById(tempalteId){
	var result = {};
	$.ajax({
		type: 'get',
		url: "/templates?templateIds=" + tempalteId,
		async: false,
		contentType: "application/json",
		dataType: "json",
		success: function(data) {
			result = data.data;
		},
		error: function(data){
			toastr.error(data.responseJSON.message);
		}
	})
	return result;
}






// Delete dataSet data
function deleteDataById(datasetId){
	var result = {};
	$.ajax({
		type: 'delete',
		url: "/datasets/" + datasetId,
		async: false,
		contentType: "application/json",
		dataType: "json",
		success: function(data) {
			result = data;
		},
		error: function(data){
			toastr.error(data.responseJSON.message);
		}
	})
	return result;
}


function ImportParseData(form, modelId) {
	var result = {};
	$.ajax({
		type: 'post',
		url: '/datasets/parse?modelId='+modelId,
		async: false,
		contentType: false,
		processData: false,
		dataType: "json",
		data: form,
		success: function(data) {
			result = data;
		},
		error: function(result){
			toastr.error(result.responseJSON.message);
		}
	});
	return result;
}

function ImportParseDataEdit(form, modelId, dataId) {
	var result = {};
	$.ajax({
		type: 'post',
		url: '/datasets/parse?modelId=' + modelId +'&datasetId=' + dataId,
		async: false,
		contentType: false,
		processData: false,
		dataType: "json",
		data: form,
		success: function(data) {
			result = data;
		},
		error: function(result){
			toastr.error(result.responseJSON.message);
		}
	});
	return result;
}

// Add dataSet data
function addDataSet(obj){
	var result = {};
	$.ajax({
		type: 'post',
		url: "/datasets",
		async: false,
		contentType: "application/json",
		dataType: "json",
		data:JSON.stringify(obj),
		success: function(data) {
			result = data;
		},
		error: function(data){
			toastr.error(data.responseJSON.message);
		}
	})
	return result;
}


// Edit dataSet data
function updateDataSet(obj, datasetId){
	var result = {};
	$.ajax({
		type: 'put',
		url: "/datasets/" + datasetId,
		async: false,
		contentType: "application/json",
		dataType: "json",
		data:JSON.stringify(obj),
		success: function(data) {
			result = data;
		},
		error: function(data){
			toastr.error(data.responseJSON.message);
		}
	})
	return result;
}


