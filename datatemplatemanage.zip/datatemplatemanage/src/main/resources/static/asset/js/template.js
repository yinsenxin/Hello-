toastr.options.positionClass = 'toast-center-center'; //toastrÌáÊ¾¿òÎ»ÖÃ³õÊ¼»¯

var $table = $('#table');
var $AddBtn  = $('#btn_template_add');
var $Editbtn = $('#btn_template_edit');
var $DeleteBtn = $('#btn_template_delete');


$('#btn_Reset').click(function(){
    $('#template_name_search').val('');
    let arr = [];
    $('#template_labels_search').selectpicker('val', arr);
})

$('#btn_Search').click(function(){
    var name = $('#template_name_search').val();
    var labels = $('#template_labels_search').val();
    if (labels == null){
        labels = "";
    }

    if (name == '' && labels == ""){
        InitTable();
    } else {
        $table.bootstrapTable('destroy').bootstrapTable({
            url: "/templates?name=" + name + "&labels=" + labels,
            method:"get",
            toolbar: '#toolbar',
            striped: true,
            showColumns: true,
            showRefresh: true,
            pageList: [10, 20, 50, 100],
            clickToSelect: true,
            search: true,
            strictSearch: false,
            responseHandler: function(res){
                return res.data;
            },
            columns:[{
                field:'checkbox',
                checkbox: true
            },{
                field:'id',
                title:'Template ID',
                align: 'center',
                visible: false,
            },{
                field:'name',
                title:'Name',
            },{
                field:'labels',
                title:'Labels',
                formatter: function(data) {
                    var result = getLabelsDataById(data);

                    var data = result.data;
                    var str = "";
                    for(var i = 0; i <data.length; i++ ){
                        if (str.length > 0){
                            str += ",";
                        }
                        str += data[i].name;
                    }
                    return str;


                }
            },{
                field:'modelId',
                title:'Model ID',
                visible: false,
                formatter: function(data) {
                    if (data == null){
                        return "";
                    }
                    return data;
                }
            },{
                field:'content',
                title:'Content',
                align: 'center',
                visible: false,
                formatter: function(data) {
                    var str = '';
                    if (data.length > 0){
                        for (var i = 0; i < data.length; i++){
                            if (str.length > 0 && i > 0){
                                str += "<br/>";
                            }
                            str += data[i];
                        }
                    }
                    return str;
                }
            },{
                field:'lastModifyDate',
                title:'LastModifyDate',
                align: 'center'
            },{
                field:'description',
                title:'Description',
                align: 'center',
                formatter: function(data) {
                    if (data == null){
                        return "";
                    }
                    return data;
                }
            }],
        })
    }
})

$(document).ready(function (){
    InitTable();
});

function InitTable(){
    $table.bootstrapTable('destroy').bootstrapTable({
        url: "/templates",
        method:"get",
        toolbar: '#toolbar',
        striped: true,
        showColumns: true,
        showRefresh: true,
        pageList: [10, 20, 50, 100],
        clickToSelect: true,
        search: true,
        strictSearch: false,
        responseHandler: function(res){
            return res.data;
        },
        columns:[{
            field:'checkbox',
            checkbox: true
        },{
            field:'id',
            title:'Template ID',
            align: 'center',
            visible: false,
        },{
            field:'name',
            title:'Name',
        },{
            field:'labels',
            title:'Labels',
            formatter: function(data) {
                var result = getLabelsDataById(data);
                var data = result.data;
                var str = "";
                for(var i = 0; i <data.length; i++ ){
                    if (str.length > 0){
                        str += ",";
                    }
                    str += data[i].name;
                }
                return str;
            }
        },{
            field:'modelId',
            title:'Model ID',
            visible: false,
            formatter: function(data) {
                if (data == null){
                    return "";
                }
                return data;
            }
        },{
            field:'content',
            title:'Content',
            align: 'center',
            visible: false,
            formatter: function(data) {
                var str = '';
                if (data.length > 0){
                    for (var i = 0; i < data.length; i++){
                        if (str.length > 0 && i > 0){
                            str += "<br/>";
                        }
                        str += data[i];
                    }
                }
                return str;
            }
        },{
            field:'lastModifyDate',
            title:'LastModifyDate',
            align: 'center'
        },{
            field:'description',
            title:'Description',
            align: 'center',
            formatter: function(data) {
                if (data == null){
                    return "";
                }
                return data;
            }
        }]
    });
}

$(function(){
       
	
    var result = getLabelsData();
    var labelsList = result.data;
    for (var index in labelsList) {
        $("#template_labels").append("<option value='"+ labelsList[index].id +"'>"+ labelsList[index].name +"</option>");
        $('#template_labels_search').append("<option value='"+ labelsList[index].id +"'>"+ labelsList[index].name +"</option>");
        $('#template_labels_edit').append("<option value='"+ labelsList[index].id +"'>"+ labelsList[index].name +"</option>");
    }

    var results = getModels();
    var modelList = results.data;
    $('#template_model_editSearch').append("<option value='' id ='testOption'></option>");
    for (var i in modelList) {
        $('#template_model_editSearch').append("<option value='"+ modelList[i].id +"'>"+ modelList[i].name +"</option>");
    }

});

function getSelectionData(){
    var row = $table.bootstrapTable('getSelections');
    return row;
}


function getModelIdData(id){

    var results = getModels();
    var modelList = results.data;
    $('#' + id).append("<option value='' id ='testOption'></option>");
    for (var i in modelList) {
        $('#' + id).append("<option value='"+ modelList[i].id +"'>"+ modelList[i].name +"</option>");
    }

}

function getModelIdDataEdit(id){

    var results = getModels();
    var modelList = results.data;
   
    
    $(id).append("<option value=''></option>");
    modelList.map(function(e){
        $(id).append("<option value='"+e.id+"'>"+e.name+"</option>");
    });

}


// add button
$AddBtn.click(function (){

    $('#template_name').val('');
    $('#template_content').val('');
    $('#template_description').val('');
    $('#template_content_preview').val('');
    $("#template_labels").empty();
    var result = getLabelsData();
    var labelsList = result.data;
    for (var index in labelsList) {
        $("#template_labels").append("<option value='"+ labelsList[index].id +"'>"+ labelsList[index].name +"</option>");
    }
    $("#template_labels").selectpicker('refresh');
    $('#template_model_search').empty();
    getModelIdData('template_model_search');
    $('#modal_template_add').modal('show');

})

// Cancel button
function showCancelModal(){
    $('#model_add_cancel').modal('show');
}

// Save button
function saveAddTemplate(){

    var obj = {};
    var name = $('#template_name').val();
    var labels = $('#template_labels').val();
    var contents = $('#template_content').val();
    var modelId = $('#template_model_search').val();
    var description = $('#template_description').val();

    if(name.replace(/(^\s*)|(\s*$)/g, "") == ""){
        toastr.warning('Name can not be empty!');
        return false;
    }

    if(labels == null){
        labels = [];
    }
    if(contents.replace(/(^\s*)|(\s*$)/g, "") == ""){
        toastr.warning('Content can not be empty!');
        return false;
    }
    // parse Content
    var content = parseContent(contents);

    obj.modelId = modelId;
    obj.name = name;
    obj.labels = labels;
    obj.content = content;
    obj.description = description;

    var result = addTemplateData(obj);
    if (result.code == 200 && result.message == 'OK'){

        toastr.success('Create Template data successfully!');
        $('#modal_template_add').modal('hide');
    }
    InitTable();
}



function parseContent(content){
    var arrays = content.split(/[(\r\n)\r\n]+/);
    var res = [];
    for (var index = 0; index < arrays.length; index++){
        if (arrays[index].replace(/(^\s*)|(\s*$)/g, "") != ""){
            res.push(arrays[index]);
        }
    }
    return res;
}



// edit button
$Editbtn.click(function (){
	 
    var row = getSelectionData();
    if (row.length == 1){

        $('#template_name_edit').val(row[0].name);
        var content = '';
        var stepList = [];
        if (row[0].content.length > 0){
            for (var i = 0; i < row[0].content.length; i++){
                stepList.push(row[0].content[i]);
            }
        }
        for (var i = 0; i < stepList.length; i++){
            if (content.length > 0){
                content +="\n";
            }
            content+= stepList[i];
        }

        var selectLabels = row[0].labels;
        var result = getLabelsData();
        var labelsData = result.data;
        var arr = [];
        for (var i = 0; i < labelsData.length ; i++){
            for(var j = 0; j < selectLabels.length; j++){
                if(labelsData[i].id == selectLabels[j]){
                    arr.push(labelsData[i].id);
                }
            }
        }
        
      
        $('#template_labels_edit').selectpicker('val', arr);
        $('#template_content_edit').val(content);

        $('#template_model_editSearch').empty();
        
        var results = getModels();
        var modelList = results.data;
        
        $('#template_model_editSearch').append("<option value=''></option>");
        modelList.map(function(e){
            $('#template_model_editSearch').append("<option value='"+e.id+"'>"+e.name+"</option>");
        });
        
			$('#template_model_editSearch').val(row[0].modelId);

        $('#template_description_edit').val(row[0].description);
        $('#template_content_Editpreview').val('');
        $('#modal_template_edit').modal('show');
    } else {
        toastr.warning("Please select a data to edit!");
        return false;
    }

})

$('#btn_preview').click(function(){

    var model = $('#template_model_search').val();
    var content = $('#template_content').val();
    if (content == ''){
        toastr.warning('Content must not be null!');
        return;
    }
    if (model == ''){
        toastr.warning('Please select a Model!');
        return;
    }

    // Get template content data
    var templateContent = parseContent(content);

    // Get model data
    var result = getModelData(model);
    var modelContent = result.data[0].content;

    // Request data --> dataMappings
    var obj = {};
    obj.templateContent = templateContent;
    obj.modelContent = modelContent;

    // result
    var results = dataMapping(obj);
    var value = results.data;
    $('#template_content_preview').val(value);



})


$('#btn_editPreview').click(function (){

    var model = $('#template_model_editSearch').val();
    var content = $('#template_content_edit').val();
    if (content == ''){
        toastr.warning('Content must not be null!');
        return;
    }
    if (model == ''){
        toastr.warning('Please select a Model!');
        return;
    }

    // Get template content data
    var templateContent = parseContent(content);
    // Get model data
    var result = getModelData(model);
    var modelContent = result.data[0].content;

    // Request data --> dataMappings
    var obj = {};
    obj.templateContent = templateContent;
    obj.modelContent = modelContent;

    // result
    var results = dataMapping(obj);
    var value = results.data;
    $('#template_content_Editpreview').val(value);

})


// edit save
function saveEditTemplate(){
    var row = getSelectionData();
    var obj = {};

    var name = $('#template_name_edit').val();
    var labels = $('#template_labels_edit').val();
    var contents = $('#template_content_edit').val();
    var description = $('#template_description_edit').val();
    if(contents.replace(/(^\s*)|(\s*$)/g, "") == ""){
        toastr.warning('Content can not be empty!');
        return false;
    }
    // parse Content
    var content = parseContent(contents);

    if(labels == null){
        labels = [];
    }

    var modelId = $('#template_model_editSearch').val();
    obj.modelId = modelId;
    obj.name = name;
    obj.labels = labels;
    obj.content = content;
    obj.description = description;

    var result = updateTemplate(row[0].id, obj);
    if (result.code == 200 && result.message == 'OK'){
        $('#modal_template_edit').modal('hide');
        toastr.success('Edit template data successfully!');
        InitTable();
    }

}


// delete button
$DeleteBtn.click(function(){
    var row = getSelectionData();
    if (row.length == 0) {
        toastr.warning("Please select the data to delete!");
        return;
    } else{
        $('#waringAlert').modal('show');
    }

})

// save delete
function saveDelete(){
    var row = getSelectionData();
    var templateIds = new Array();
    $(row).each(function(){
        templateIds.push(this.id);
    })

    var result = deleteTemplateData(templateIds);
    if (result.code == 200 && result.message == "OK"){
        toastr.success('Delete this data successfully');
    }
    InitTable();
}


function addCancel(){
    $('#modal_template_add').modal('hide');
}

function showCancelModalEdit(){
    $('#model_edit_cancel').modal('show');
}

function editCancel(){
    $('#modal_template_edit').modal('hide');
}





function addTemplateData(obj){
    var result = {};
    $.ajax({
        type: 'post',
        url: "/templates",
        async: false,
        contentType: "application/json",
        dataType: "json",
        data:JSON.stringify(obj),
        success: function(data) {
            result = data;
        },
        error: function(data){
            toastr.error(data.responseJSON.message);
        }
    })
    return result;
}


function deleteTemplateData(templateIds){
    var result = {};
    $.ajax({
        type: 'delete',
        url: "/templates/"+templateIds,
        async: false,
        contentType: "application/json",
        dataType: "json",
        success: function(data) {
            result = data;
        },
        error: function(data){
            toastr.error(data.responseJSON.message);
        }
    })
    return result;
}

function getLabelsData(){
    var result = {};
    $.ajax({
        type: 'get',
        url: "/labels",
        async: false,
        contentType: "application/json",
        dataType: "json",
        success: function(data) {
            result = data;
        },
        error: function(data){
            toastr.error(data.responseJSON.message);
        }
    })
    return result;
}

function getLabelsDataById(labelId){
    var result = {};
    $.ajax({
        type: 'get',
        url: "/labels/label?labelIds=" + labelId,
        async: false,
        contentType: "application/json",
        dataType: "json",
        success: function(data) {
            result = data;
        },
        error: function(data){
            toastr.error(data.responseJSON.message);
        }
    })
    return result;
}





function dataMapping(obj){
    var result = {};
    $.ajax({
        type: 'post',
        url: "/scripts",
        async: false,
        contentType: "application/json",
        dataType: "json",
        data:JSON.stringify(obj),
        success: function(data) {
            result = data;
        },
        error: function(data){
            toastr.error('request fail');
        }
    })
    return result;
}


function updateTemplate(templateId, obj){
    var result = {};
    $.ajax({
        type: 'put',
        url: "/templates/"+templateId,
        async: false,
        contentType: "application/json",
        dataType: "json",
        data:JSON.stringify(obj),
        success: function(data) {
            result = data;
        },
        error: function(data){
            toastr.error(data.responseJSON.message);
        }
    })
    return result;
}

function getModelData(modelId){
    var result = {};
    $.ajax({
        type: 'get',
        url: "/models?modelIds=" + modelId,
        async: false,
        contentType: "application/json",
        dataType: "json",
        success: function(data) {
            result = data;
        },
        error: function(data){
            toastr.error(data.responseJSON.message);
        }
    })
    return result;
}

function getModels(){
    var result = {};
    $.ajax({
        type: 'get',
        url: "/models",
        async: false,
        contentType: "application/json",
        dataType: "json",
        success: function(data) {
            result = data;
        },
        error: function(data){
            toastr.error(data.responseJSON.message);
        }
    })
    return result;
}





