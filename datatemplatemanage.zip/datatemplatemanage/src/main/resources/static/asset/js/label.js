toastr.options.positionClass = 'toast-center-center'; //toastr提示框位置初始化

var $table = $('#table');
var $addBtn = $('#btn_labels_add');
var $editBtn = $('#btn_labels_edit');
var $deleteBtn = $('#btn_labels_delete');


$(function(){
    function operateFormatter(value, row, index) {
        return [
            '<button type="button" class="RoleOfedit btn btn-primary">Save</button>'
        ].join('');
    }

    window.operateEvents = {
        'click .RoleOfedit': function (e, value, row, index) {
            if (row.name == ""){

                toastr.warning('Name must not be null!');
                return false;
            }

            if (row.name != "" && row.id != 1){
                var obj = {};
                obj.name = row.name;
                obj.description = row.description;
                obj.id = row.id;
                var result = updateLabelsData(row.id,obj);
                if(result.code == 200 && result.message == 'OK'){
                    toastr.success('Edit Labels data successfully');
                }

            } else if (row.name != "" && row.id == 1){
                var obj = {};

                obj.name = row.name;
                obj.description = row.description;

                var result = insertLabelsData(obj);
                if (result.code == 200 && result.message == 'OK'){
                    toastr.success('Create Labels data successfully');
                    row.id = result.data;
                }
            }
        }
    };

    $table.bootstrapTable('destroy').bootstrapTable({
        url: "/labels",
        method:"get",
        toolbar: '#toolbar',
        striped: true,
        showColumns: false,
        showRefresh: true,
        pageList: [10, 20, 50, 100],
        clickToSelect: true,
        search: true,
        strictSearch: false,
        responseHandler: function(res){
            return res.data;
        },
        columns:[{
            field:'checkbox',
            checkbox: true,
        },{
            field:'id',
            title:'labels ID',
            align: 'center',
            visible: false,
        },{
            field:'name',
            title:'Name',
            align: 'center',
            editable: {
                type: 'text',
                title: 'Name',
                validate: function (v) {
                    if (v.replace(/(^\s*)|(\s*$)/g, "") == ""){
                        return 'The labels name cannot be empty.';
                    }
                    var data = $table.bootstrapTable('getData', true);
                    console.log(data)
                    var map = [];
                    for(var i in data){
                        var element = data[i];
                        map.push(element.name);
                    }
                    if(v){
                        var flag = findName(v,map);
                        if(flag == false){
                            return 'Name already exists. Please rename param.';
                        }
                    }
                },

            }
        },{
            field:'description',
            title:'Description',
            align: 'center',
            editable: {
                type: 'text',
                title: 'Description',
            },

        },{
            field: 'operate',
            title: 'Operate',
            align: 'center',
            width:'20%',
            events: operateEvents,
            formatter: operateFormatter
        }]
    });

});

function findName(name,map){

    var result = true;
    var tmp = map.indexOf(name);
    if(tmp != -1){
        result = false;
        return result;
    }
    return result;
}

$addBtn.click(function () {

    $table.bootstrapTable('insertRow', {
        index:0,
        row: {
            id:"1",
            name: "",
            description:""
        }
    });

})

function saveAddLabels() {
    var obj = {};
    var name = $('#labels_name').val();
    var description = $('#labels_description').val();
    if(name.replace(/(^\s*)|(\s*$)/g, "") == ""){
        toastr.warning('Name can not be empty!');
        return false;
    }
    obj.name = name;
    obj.description = description;

    var result = insertLabelsData(obj);
    if (result.code == 200 && result.message == 'OK'){
        toastr.success('Create Labels data successfully');
    }
    $('#modal_labels_add').modal('hide');
    $table.bootstrapTable('refresh');
}
function showCancelModal() {
    $('#model_add_cancel').modal('show');
}

function addCancel() {
    $('#modal_labels_add').modal('hide');
}


$editBtn.click(function () {
    var rows = $table.bootstrapTable('getSelections');
    if (rows.length == 0 || rows.length >1) {
        toastr.warning("Please select a data to edit!");
        return;
    }
    $('#edit_labels_name').val(rows[0].name);
    $('#edit_labels_description').val(rows[0].description);

    $('#edit_labels').modal('show');

})

function showEditCancel(){

    $('#model_edit_cancel').modal('show');
}

function saveEditLabels(){
    var rows = $table.bootstrapTable('getSelections');
    var obj = {};
    var name = $('#edit_labels_name').val();
    var description = $('#edit_labels_description').val();

    if(name.replace(/(^\s*)|(\s*$)/g, "") == ""){
        toastr.warning('Name can not be empty!');
        return false;
    }
    obj.name = name;
    obj.description = description;
    obj.id = rows[0].id;
    var result = updateLabelsData(rows[0].id,obj);
    if(result.code == 200 && result.message == 'OK'){
        toastr.success('Edit Labels data successfully');
        $('#edit_labels').modal('hide');
    } else {
        toastr.error(result.message);
    }

    $table.bootstrapTable('refresh');
}

function editCancel(){
    $('#edit_labels').modal('hide');
}




$deleteBtn.click(function(){
    var rows = $table.bootstrapTable('getSelections');
    if (rows.length == 0) {
        toastr.warning("Please select the data to delete!");
        return;
    } else{
        $('#waringAlert').modal('show');
    }

})

function saveDelete() {
    var rows = $table.bootstrapTable('getSelections');
    var ids = $.map($table.bootstrapTable('getSelections'), function (row) {
        return row.checkbox;
    });

    if (ids.length) {
        $table.bootstrapTable('remove', {
            field: 'checkbox',
            values: ids,
        });
    } else {
        toastr.warning('Please select a data delete');
    }
    var labelsIds = new Array();
    $(rows).each(function(){
        labelsIds.push(this.id);
    })
    deleteLabelsData(labelsIds);
    toastr.success('Delete this data successfully');
}


function deleteLabelsData(labelsId){
    var result = {};
    $.ajax({
        type: 'delete',
        url: "/labels/"+labelsId,
        async: false,
        contentType: "application/json",
        dataType: "json",
        success: function(data) {
            result = data;
        },
        error: function(data){
            toastr.error(data.responseJSON.message);
        }
    })
    return result;
}


function insertLabelsData(obj){
    var result = {};
    $.ajax({
        type: 'post',
        url: "/labels",
        async: false,
        contentType: "application/json",
        dataType: "json",
        data: JSON.stringify(obj),
        success: function(data) {
            result = data;
        },
        error: function(data){
            toastr.error(data.responseJSON.message);
        }
    });
    return result;

}

function updateLabelsData(labelsId, obj) {
    var result = {};
    $.ajax({
        type: 'put',
        url: "/labels/"+labelsId,
        async: false,
        contentType: "application/json",
        dataType: "json",
        data: JSON.stringify(obj),
        success: function(data) {
            result = data;
        },
        error: function(data){
            toastr.error(data.responseJSON.message);
        }
    });
    return result;
}
