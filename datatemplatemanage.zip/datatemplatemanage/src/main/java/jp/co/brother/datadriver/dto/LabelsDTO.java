package jp.co.brother.datadriver.dto;

import lombok.Data;

@Data
public class LabelsDTO {
	
	/**
	 * This is the id field of the labelsDTO
	 */
	private String id;
	
	/**
	 * This is the name field of the labelsDTO
	 */
	private String name;
	
	/**
	 * This is the description field of the labelsDTO
	 */
	private String description;
}
