package jp.co.brother.datadriver.config;

import feign.Request;
import feign.Retryer;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class FeignConfig {
    public static final int CONNECTTIMEOUTMILLIS = 3000;// 超时时间
    public static final int READTIMEOUTMILLIS = 180000;

    @Bean
    public Request.Options options() {
        return new Request.Options(CONNECTTIMEOUTMILLIS, READTIMEOUTMILLIS);
    }

    @Bean
    public Retryer feignRetryer() {
        return new Retryer.Default();
    }
}
