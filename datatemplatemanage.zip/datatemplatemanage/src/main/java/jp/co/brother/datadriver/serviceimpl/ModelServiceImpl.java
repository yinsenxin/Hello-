package jp.co.brother.datadriver.serviceimpl;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.Assert;

import jp.co.brother.datadriver.constant.Constant;
import jp.co.brother.datadriver.dao.DataDao;
import jp.co.brother.datadriver.dao.LabelModelDao;
import jp.co.brother.datadriver.dao.ModelDao;
import jp.co.brother.datadriver.dao.TemplateDao;
import jp.co.brother.datadriver.dao.TemplateModelDao;
import jp.co.brother.datadriver.domain.DataDO;
import jp.co.brother.datadriver.domain.ModelDO;
import jp.co.brother.datadriver.domain.TemplateDO;
import jp.co.brother.datadriver.domain.middle.LabelModelDO;
import jp.co.brother.datadriver.domain.middle.TemplateModelDO;
import jp.co.brother.datadriver.dto.ModelDTO;
import jp.co.brother.datadriver.exception.AlreadyExistsException;
import jp.co.brother.datadriver.exception.DataNotFoundException;
import jp.co.brother.datadriver.service.IModelService;
import jp.co.brother.datadriver.vo.ResultVO;

@Service
public class ModelServiceImpl implements IModelService{

	@Autowired
	private ModelDao modelDao;

	@Autowired
	private LabelModelDao labelModelDao;

	@Autowired
	private TemplateModelDao templateModelDao;
	
	@Autowired
	private DataDao dataDao;
	
	@Autowired
	private TemplateDao templateDao;
	
	/**
	 * Get All model about data
	 */
	@Override
	public ResultVO getModelData(String[] modelIds, String[] labels, String name) {
		ResultVO resultVO = new ResultVO(HttpStatus.OK);
		Query query = new Query();

		if (Objects.nonNull(modelIds) && modelIds.length > 0) {
			query.addCriteria(Criteria.where(Constant.MODEL_ID).in((Object[]) modelIds));
		}
		if (Objects.nonNull(labels) && labels.length > 0) {
			Query query2 = new Query();
			query2.addCriteria(Criteria.where(Constant.LABEL_MODEL_LABELID).in((Object[]) labels));
			List<LabelModelDO> find = labelModelDao.find(query2);
			List<String> modelId = new ArrayList<>();
			find.forEach(s -> modelId.add(s.getModelId()));
			query.addCriteria(Criteria.where(Constant.MODEL_ID).in(modelId));
		}
		if (StringUtils.isNotBlank(name)) {
			Pattern pattern = Pattern.compile(Constant.PATTERN_PREFIX + name + Constant.PATTERN_SUFFIX, Pattern.CASE_INSENSITIVE);
			query.addCriteria(Criteria.where(Constant.TEMPLATE_NAME).regex(pattern));
		}

		// Get all model data
		List<ModelDO> models = modelDao.find(query);
		// Get modelId
		List<String> modelId = new ArrayList<>();
		models.forEach(s -> modelId.add(s.getId()));
		// Make Search
		Query query2 = new Query();
		query2.addCriteria(Criteria.where(Constant.LABEL_MODEL_MODELID).in(modelId));
		// Get labelModel data
		List<LabelModelDO> labelModelDO = labelModelDao.find(query2);
		// Get templateModel data
		List<TemplateModelDO> templateModelDO = templateModelDao.find(query2);
		getLabelTemplateData(models, labelModelDO, templateModelDO);
		resultVO.setData(models);
		return resultVO;
	}
	
	
	/**
	 * Get special model data by modelIds
	 */
	@Override
	public ResultVO getModelDataById(String[] modelIds) {
		ResultVO resultVO = new ResultVO(HttpStatus.OK);

		Query query = new Query();
		if (Objects.nonNull(modelIds) && modelIds.length > 0) {
			query.addCriteria(Criteria.where(Constant.MODEL_ID).in((Object[]) modelIds));
		}
		List<ModelDO> modelDOs = modelDao.find(query);
		resultVO.setData(modelDOs);
		return resultVO;
	}


	/**
	 * Add special model data
	 */
	@Override
	@Transactional
	public ResultVO addModelData(ModelDTO modelDTO) {
		// Check the input parameter is valid
		checkParam(modelDTO);

		// Make Search
		Query query = new Query();
		query.addCriteria(Criteria.where(Constant.MODEL_NAME).is(modelDTO.getName()));

		if (modelDao.exists(query)) {
			throw new AlreadyExistsException(Constant.ALREADY_EXCEPTION_MODEL);
		}
		Date now = new Date();
		SimpleDateFormat dateFormat = new SimpleDateFormat(Constant.DATEFORMAT);
		modelDTO.setLastModifyDate(dateFormat.format(now));
		// Add model data to database
		ModelDO modelDO = modelDao.insert(dtoToDO(modelDTO));
		
		List<String> templates = modelDTO.getTemplates();
		Query query2 = new Query();
		query2.addCriteria(Criteria.where(Constant.TEMPLATE_MODEL_TEMPLATEID).in(templates));
		
		Query query3 = new Query();
		query3.addCriteria(Criteria.where(Constant.MODEL_ID).is(modelDO.getId()));
		
		// Add templateModel data to database
		if (!templates.isEmpty()) {
			List<TemplateModelDO> list = new ArrayList<>();
			
			if (templateModelDao.exists(query2)) {
				modelDao.findAllAndRemove(query3);
				throw new AlreadyExistsException(Constant.ALREADY_EXCEPTION_TEMPLATEMODEL);
			}
			for (String template : templates) {
				TemplateModelDO templateModelDO = new TemplateModelDO();
				templateModelDO.setModelId(modelDO.getId());
				templateModelDO.setTemplateId(template);
				list.add(templateModelDO);
			}
			templateModelDao.insertAll(list);
			
		}
		// Add labelsModel data to database
		if (!modelDTO.getLabels().isEmpty()) {
			addLabelModelData(modelDO.getId(), modelDTO.getLabels());
		}
		return new ResultVO(HttpStatus.OK);
	}

	/**
	 * Update model data
	 */
	@Override
	@Transactional
	public ResultVO updateModelData(String modelId, String type, ModelDTO modelDTO) {

		if (StringUtils.isNotBlank(type)) {
			return updateStatus(modelId, modelDTO);
		}
		return updateModel(modelId, modelDTO);
	}

	/**
	 * update model data
	 * @param modelId
	 * @param modelDTO
	 * @return
	 */
	public ResultVO updateModel(String modelId, ModelDTO modelDTO) {
		// Check the input parameter is valid
		checkParam(modelId, modelDTO);

		// Make Search
		Query query = new Query();
		query.addCriteria(Criteria.where(Constant.MODEL_ID).is(modelId));

		if (modelDao.exists(query)) {
			ModelDO modelDO = modelDao.findOne(query);
			if (!modelDTO.getName().equals(modelDO.getName())) {
				throw new AlreadyExistsException(Constant.NONEDIT_EXCEPTION_MODEL);
			}
			// lastModifyDate format
			Date now = new Date();
			SimpleDateFormat dateFormat = new SimpleDateFormat(Constant.DATEFORMAT);
			modelDTO.setLastModifyDate(dateFormat.format(now));
			ModelDO model = dtoToDO(modelDTO);
			// new templates
			List<String> templates = modelDTO.getTemplates();
			
			Query query3 = new Query();
			query3.addCriteria(Criteria.where(Constant.TEMPLATE_MODEL_MODELID).in(modelId));
			// old templates 
			List<String> templateList = new ArrayList<>();
			List<TemplateModelDO> templateModels = templateModelDao.find(query3);
			templateModels.forEach(s -> templateList.add(s.getTemplateId()));
			
			// difference templates
			List<String> reduce1 = templates.stream().filter(item -> !templateList.contains(item)).collect(Collectors.toList());
	        List<String> reduce2 = templateList.stream().filter(item -> !templates.contains(item)).collect(Collectors.toList());
	        List<String> lists = new ArrayList<>();
	        lists.addAll(reduce1);
	        lists.addAll(reduce2);
	        lists.removeAll(templateList);
			
			// get templateModel by difference templates data
			Query query4 = new Query();
			query4.addCriteria(Criteria.where(Constant.TEMPLATE_MODEL_TEMPLATEID).in(lists));
			
			if (templateModelDao.exists(query4)) {
				throw new AlreadyExistsException(Constant.ALREADY_EXCEPTION_TEMPLATEMODEL);
			}
			
			// Make Search
			Query query2 = new Query();
			query2.addCriteria(Criteria.where(Constant.LABEL_MODEL_MODELID).is(modelId));
			labelModelDao.findAllAndRemove(query2);
			// Add labelModel data to database
			List<String> labels = modelDTO.getLabels();
			if (!labels.isEmpty()) {
				addLabelModelData(modelId, labels);
			}
			templateModelDao.findAllAndRemove(query2);
			// Add templateModel data to database
			List<String> templateDOs = modelDTO.getTemplates();
			if (templateDOs.isEmpty()) {
				replaceOldRecord(modelId, model);
				Query query5 = new Query();
				query5.addCriteria(Criteria.where(Constant.TEST_DATA_MODELID).is(modelId));
				List<DataDO> dataDO = dataDao.find(query5);
				List<Map<String, String>> list = new ArrayList<>();
				for (DataDO dataDO2 : dataDO) {
					List<Map<String,String>> modelContent = dataDO2.getModelContent();
					for (Map<String,String> map : modelContent) {
						Map<String, String> maps = new HashMap<>();
						if (map.containsKey(Constant.IMPORTDATA_TEMPLATE)) {
							map.put(Constant.IMPORTDATA_TEMPLATE, "");
						}
						maps.putAll(map);
						list.add(maps);
					}
				}
				Update update = new Update();
				update.set(Constant.TEST_DATA_MODEL_CONTENT, list);
				dataDao.updateMulti(query5, update);
				return new ResultVO(HttpStatus.OK);
			}
			
			List<TemplateModelDO> list = new ArrayList<>();
			for (String template : templateDOs) {
				TemplateModelDO templateModelDO = new TemplateModelDO();
				templateModelDO.setModelId(modelId);
				templateModelDO.setTemplateId(template);
				list.add(templateModelDO);
			}
			// Insert data to template_model database
			List<TemplateModelDO> insertAll = (List<TemplateModelDO>) templateModelDao.insertAll(list);
			
			// Get templateName
			List<String> templateId = new ArrayList<>();
			insertAll.forEach(s -> templateId.add(s.getTemplateId()));
			Set<String> templateName = getTemplateDO(templateId);
			
			
			
			Query query5 = new Query();
			query5.addCriteria(Criteria.where(Constant.TEST_DATA_MODELID).is(modelId));
			List<DataDO> dataDO = dataDao.find(query5);
			
			List<Map<String, String>> content = new ArrayList<>();
			for (DataDO dataDO2 : dataDO) {
				List<Map<String,String>> modelContent = dataDO2.getModelContent();
				for (Map<String,String> map : modelContent) {
					String string = map.get(Constant.IMPORTDATA_TEMPLATE);
					if (!templateName.contains(string)) {
						map.put(Constant.IMPORTDATA_TEMPLATE, "");
					}
				}
				content.addAll(modelContent);
			}
			
			Update update = new Update();
			update.set(Constant.TEST_DATA_MODEL_CONTENT, content);
			dataDao.updateMulti(query5, update);
			
			
			// update model data to database
			replaceOldRecord(modelId, model);
		} else {
			throw new DataNotFoundException(Constant.DATA_NOTFOUND_EXCEPTION);
		}
		return new ResultVO(HttpStatus.OK);
	}

	/**
	 * delete special model data
	 */
	@Override
	@Transactional
	public ResultVO deleteModelData(String[] modelIds) {
		// Check the input parameter is valid
		Assert.notEmpty(modelIds, Constant.REQUEST_MODEL_ID);

		// Make Search
		Query query = new Query();
		query.addCriteria(Criteria.where(Constant.MODEL_ID).in((Object[]) modelIds));
		// Delete model data
		List<ModelDO> model = modelDao.findAllAndRemove(query);
		List<String> modelId = new ArrayList<>();
		model.forEach(s -> modelId.add(s.getId()));

		// Make Search
		Query query2 = new Query();
		query2.addCriteria(Criteria.where(Constant.LABEL_MODEL_MODELID).in(modelId));

		// Delete labelModel data
		labelModelDao.findAllAndRemove(query2);
		// Delete templateModel data
		templateModelDao.findAllAndRemove(query2);
		// Delete dataSet data
		Query query3 = new Query();
		query3.addCriteria(Criteria.where(Constant.TEST_DATA_MODELID).in(modelId));
		dataDao.findAllAndRemove(query3);
		return new ResultVO(HttpStatus.OK);
	}

	/**
	 * Add labelModel data to database
	 * @param modelId
	 * @param labels
	 */
	private void addLabelModelData(String modelId, List<String> labels){
		List<LabelModelDO> list = new ArrayList<>();
		for (String label : labels) {
			LabelModelDO labelModelDO = new LabelModelDO();
			labelModelDO.setModelId(modelId);
			labelModelDO.setLabelId(label);
			list.add(labelModelDO);
		}
		labelModelDao.insertAll(list);
	}

	/**
	 * Replace old model data
	 * @param modelId
	 * @param modelDO
	 */
	private void replaceOldRecord(String modelId, ModelDO modelDO) {
		// Make Search
		Query query = new Query();
		query.addCriteria(Criteria.where(Constant.MODEL_ID).is(modelId));

		// Make update
		Update update = new Update();
		if (modelDO.getStatus() != 1){
			update.set(Constant.MODEL_CONTENT, modelDO.getContent());
		}
		update.set(Constant.MODEL_DESCRIPTION, modelDO.getDescription());
		update.set(Constant.MODEL_LASTMODIFYDATE, modelDO.getLastModifyDate());
		update.set(Constant.MODEL_STATUS, modelDO.getStatus());

		// Update data
		modelDao.upsert(query, update);

	}
	
	/**
	 * Get label and template data
	 * @param models
	 * @param labelModelDO
	 * @param templateModelDO
	 */
	private void getLabelTemplateData (List<ModelDO> models, List<LabelModelDO> labelModelDO, List<TemplateModelDO> templateModelDO) {
		// Get labels data
		for (ModelDO model : models) {
			List <String> list = new ArrayList<>();
			for (LabelModelDO labelModel : labelModelDO) {
				if (model.getId().equals(labelModel.getModelId())){
					list.add(labelModel.getLabelId());
				}
			}
			model.setLabels(list);
		}
		// Get templates data
		for (ModelDO model : models) {
			List <String> list = new ArrayList<>();
			for (TemplateModelDO templateModel : templateModelDO) {
				if (model.getId().equals(templateModel.getModelId())){
					list.add(templateModel.getTemplateId());
				}
			}
			model.setTemplates(list);
		}
	}
	

	/**
	 *
	 * @param modelId
	 * @param modelDTO
	 */
	private ResultVO updateStatus(String modelId, ModelDTO modelDTO) {
		// Make Search
		Query query = new Query();
		query.addCriteria(Criteria.where(Constant.MODEL_ID).is(modelId));

		// Make update
		Update update = new Update();
		update.set(Constant.MODEL_STATUS, modelDTO.getStatus());
		// Update data
		modelDao.updateMulti(query, update);
		return new ResultVO(HttpStatus.OK);
	}
	
	
	/**
	 * DTO --> DO
	 * @param modelDTO
	 * @return
	 */
	private ModelDO dtoToDO(ModelDTO modelDTO) {

		ModelDO modelDO = new ModelDO();
		modelDO.setName(modelDTO.getName());
		modelDO.setStatus(modelDTO.getStatus());
		modelDO.setContent(modelDTO.getContent() == null ? new HashMap<>() : modelDTO.getContent());
		modelDO.setDescription(modelDTO.getDescription());
		modelDO.setLastModifyDate(modelDTO.getLastModifyDate());
		return modelDO;
	}
	
	
	/**
	 * Check the input parameter is valid
	 */
	private void checkParam(ModelDTO modelDTO) {
		Assert.notNull(modelDTO, Constant.REQUEST_BODY_MODEL);
		Assert.hasLength(modelDTO.getName(), Constant.REQUEST_MODEL_NAME);
		Assert.notNull(modelDTO.getStatus(), Constant.REQUEST_MODEL_STATUS);
		Assert.notNull(modelDTO.getContent(), Constant.REQUEST_MODEL_CONTENT);
	}

	/**
	 * Check the input parameter is valid
	 */
	private void checkParam(String modelId, ModelDTO modelDTO) {
		Assert.hasLength(modelId, Constant.REQUEST_MODEL_ID);
		Assert.notNull(modelDTO, Constant.REQUEST_BODY_MODEL);
		Assert.hasLength(modelDTO.getName(), Constant.REQUEST_MODEL_NAME);
		Assert.notNull(modelDTO.getStatus(), Constant.REQUEST_MODEL_STATUS);
		Assert.notNull(modelDTO.getContent(), Constant.REQUEST_MODEL_CONTENT);
	}
	
	/**
	 * 
	 * @return
	 */
	private Set<String> getTemplateDO(List<String> list){
		Set<String> templateName = new HashSet<>();
		Query query = new Query();
		query.addCriteria(Criteria.where(Constant.TEMPLATE_ID).in(list));
		List<TemplateDO> template = templateDao.find(query);
		template.forEach(s -> templateName.add(s.getName()));
		
		return templateName;
	}

}





