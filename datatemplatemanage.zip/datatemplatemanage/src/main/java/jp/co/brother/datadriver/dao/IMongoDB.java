package jp.co.brother.datadriver.dao;

import java.util.Collection;
import java.util.List;

import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;

import com.mongodb.client.result.UpdateResult;

public interface IMongoDB <T>{
	
	public boolean exists(Query query);
	
	public List<T> find(Query query);
	
    public T findOne(Query query);
    
    public List<T> findAll();
    
    public T findAndRemove(Query query);
    
	public List<T> findAllAndRemove(Query query);
    
    public T insert(T objectToSave);
    
    @SuppressWarnings("hiding")
	public <T> Collection<T> insertAll(Collection<T> t);
    
    public T save(T objectToSave);
    
    public UpdateResult upsert(Query query, Update update);
    
    public UpdateResult updateMulti(Query query, Update update);
    
    public Long count(Query query);

    
}
