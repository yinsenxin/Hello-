package jp.co.brother.datadriver.proxy;

import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import jp.co.brother.datadriver.constant.Constant;
import jp.co.brother.datadriver.dto.CaseDTO;
import jp.co.brother.datadriver.vo.ResultVO;

@Service
public class FeignHystrix implements CaseManager{

	@Override
	public ResultVO addAllCase(List<CaseDTO> cases) {
		
		ResultVO resultVO = new ResultVO(HttpStatus.INTERNAL_SERVER_ERROR);	
		resultVO.setMessage(Constant.CASEMANAGE_SERVER_FAILD);
		return resultVO;
	}

}
