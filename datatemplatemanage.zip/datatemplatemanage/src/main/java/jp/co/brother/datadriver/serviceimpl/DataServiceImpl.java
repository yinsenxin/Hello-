package jp.co.brother.datadriver.serviceimpl;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.io.StringWriter;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.regex.Pattern;
import java.util.stream.Collectors;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang.StringUtils;
import org.apache.velocity.VelocityContext;
import org.apache.velocity.app.Velocity;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.util.Assert;
import org.springframework.web.multipart.MultipartFile;

import com.alibaba.fastjson.JSON;

import jp.co.brother.datadriver.config.DataType;
import jp.co.brother.datadriver.constant.Constant;
import jp.co.brother.datadriver.dao.DataDao;
import jp.co.brother.datadriver.dao.LabelDataDao;
import jp.co.brother.datadriver.dao.ModelDao;
import jp.co.brother.datadriver.dao.TemplateDao;
import jp.co.brother.datadriver.dao.TemplateModelDao;
import jp.co.brother.datadriver.domain.DataDO;
import jp.co.brother.datadriver.domain.ModelDO;
import jp.co.brother.datadriver.domain.TemplateDO;
import jp.co.brother.datadriver.domain.middle.LabelDataDO;
import jp.co.brother.datadriver.domain.middle.TemplateModelDO;
import jp.co.brother.datadriver.dto.CaseDTO;
import jp.co.brother.datadriver.dto.DataDTO;
import jp.co.brother.datadriver.dto.DataInfoDTO;
import jp.co.brother.datadriver.exception.AlreadyExistsException;
import jp.co.brother.datadriver.exception.DataNotFoundException;
import jp.co.brother.datadriver.exception.FileTypeException;
import jp.co.brother.datadriver.exception.ReadFileException;
import jp.co.brother.datadriver.proxy.CaseManager;
import jp.co.brother.datadriver.service.IDataMappingService;
import jp.co.brother.datadriver.service.IDataService;
import jp.co.brother.datadriver.utils.CsvUtils;
import jp.co.brother.datadriver.utils.FileUtils;
import jp.co.brother.datadriver.vo.ResultVO;
import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class DataServiceImpl implements IDataService{

	@Autowired
	private DataDao dataDao;

	@Autowired
	private LabelDataDao labelDataDao;

	@Autowired
	private ModelDao modelDao;

	@Autowired
	private TemplateModelDao templateModelDao;

	@Autowired
	private TemplateDao templateDao;

	@Autowired
	private IDataMappingService dataMappingService;

	@Autowired
	private CaseManager caseManager;
	
	
	@Override
	public ResultVO getTestData(String[] dataIds, String[] labels, String name) {
		ResultVO resultVO = new ResultVO(HttpStatus.OK);

		// Make Search
		Query query = new Query();
		if (Objects.nonNull(dataIds) && dataIds.length > 0) {
			query.addCriteria(Criteria.where(Constant.TEST_DATA_ID).in((Object[]) dataIds));
		}
		if (Objects.nonNull(labels) && labels.length > 0) {
			Query query2 = new Query();
			query2.addCriteria(Criteria.where(Constant.LABEL_TESTDATA_LABELID).in((Object[]) labels));
			List<LabelDataDO> list = labelDataDao.find(query2);
			List<String> dataId = new ArrayList<>();
			list.forEach(s -> dataId.add(s.getDataId()));
			query.addCriteria(Criteria.where(Constant.TEST_DATA_ID).in(dataId));
		}
		if (StringUtils.isNotBlank(name)) {
			Pattern pattern = Pattern.compile(Constant.PATTERN_PREFIX + name + Constant.PATTERN_SUFFIX, Pattern.CASE_INSENSITIVE);
			query.addCriteria(Criteria.where(Constant.TEST_DATA_NAME).regex(pattern));
		}
		// Get all data to database
		List<DataDO> datas = dataDao.find(query);
		// Get dataId
		List<String> list = new ArrayList<>();
		datas.forEach(s -> list.add(s.getId()));

		// Get labelData
		Query query2 = new Query();
		query2.addCriteria(Criteria.where(Constant.LABEL_TESTDATA_DATAID).in(list));
		List<LabelDataDO> labelData = labelDataDao.find(query2);
		if (!labelData.isEmpty()) {
			for (DataDO dataDO : datas) {
				List<String> label = new ArrayList<>();
				for (LabelDataDO labelDataDO : labelData) {
					if (dataDO.getId().equals(labelDataDO.getDataId())) {
						label.add(labelDataDO.getLabelId());
					}
				}
				dataDO.setLabels(label);
			}
		}
		// Response data
		List<DataDTO> dataDTO = getDataDTO(datas);
		resultVO.setData(dataDTO);

		return resultVO;
	}

	@Override
	public ResultVO addTestData(DataDTO dataDTO) {
		// Check input parameter is valid
		checkParam(dataDTO);

		ResultVO resultVO = new ResultVO(HttpStatus.OK);
		if (checkExists(dataDTO)) {
			throw new AlreadyExistsException(Constant.ALREADY_EXCEPTION_TESTDATA);
		}
		// Set date property
		Date now = new Date();
		SimpleDateFormat dateFormat = new SimpleDateFormat(Constant.DATEFORMAT);
		dataDTO.setLastModifyDate(dateFormat.format(now));
		// UnReleased modelId cannot be used
		String modelId = dataDTO.getModelId();
		Query query = new Query();
		query.addCriteria(Criteria.where(Constant.MODEL_ID).is(modelId));
		if (!modelDao.exists(query)) {
			throw new DataNotFoundException(Constant.MODELID_NOTFOUND_EXCEPTION);
		}
		query.addCriteria(Criteria.where(Constant.MODEL_STATUS).is(Constant.MODEL_STATUS_VALUE));
		if(!modelDao.exists(query)){
			throw new DataNotFoundException(Constant.MODELID_NOT_USE);
		}
		DataDO dataDO = dtoToDO(dataDTO);
		// insert dataDO to database
		DataDO insertData = dataDao.insert(dataDO);
		List<String> labels = dataDTO.getLabels();
		if (!labels.isEmpty()) {
			List<LabelDataDO> labelDatas = new ArrayList<>();
			for (String string : labels) {
				LabelDataDO labelDataDO = new LabelDataDO();
				labelDataDO.setDataId(insertData.getId());
				labelDataDO.setLabelId(string);
				labelDatas.add(labelDataDO);
			}
			// insert labelData to database
			labelDataDao.insertAll(labelDatas);
		}
		return resultVO;
	}

	@Override
	public ResultVO updateTestData(String dataId, DataDTO dataDTO) {
		// Check input parameter is valid
		checkParam(dataId, dataDTO);
		
		// Make search
		ResultVO resultVO = new ResultVO(HttpStatus.OK);
		Query query = new Query();
		query.addCriteria(Criteria.where(Constant.TEST_DATA_ID).is(dataId));
		if (dataDao.exists(query)) {
			DataDO dataDO = dtoToDO(dataDTO);
			Update update = new Update();
			update.set(Constant.TEST_DATA_MODEL_TYPE, dataDO.getType());
			update.set(Constant.TEST_DATA_MODEL_CONTENT, dataDO.getModelContent());
			update.set(Constant.TEST_DATA_DESCRIPTION, dataDO.getDescription());
			dataDao.updateMulti(query, update);

			Query query2 = new Query();
			query2.addCriteria(Criteria.where(Constant.LABEL_TESTDATA_DATAID).is(dataId));
			labelDataDao.findAllAndRemove(query2);

			List<String> labels = dataDTO.getLabels();
			if (!labels.isEmpty()) {
				List<LabelDataDO> labelDatas = new ArrayList<>();
				for (String string : labels) {
					LabelDataDO labelDataDO = new LabelDataDO();
					labelDataDO.setDataId(dataId);
					labelDataDO.setLabelId(string);
					labelDatas.add(labelDataDO);
				}
				// insert labelData to database
				labelDataDao.insertAll(labelDatas);
			}
			return resultVO;
		} else {
			throw new DataNotFoundException(Constant.DATA_NOTFOUND_EXCEPTION);
		}
	}

	@Override
	public ResultVO deleteTestData(String[] dataIds) {
		// Check input parameter is valid
		Assert.notNull(dataIds, Constant.REQUEST_TESTDATA_ID);

		ResultVO resultVO = new ResultVO(HttpStatus.OK);
		// Make Search
		Query query = new Query();
		query.addCriteria(Criteria.where(Constant.TEST_DATA_ID).in((Object[]) dataIds));
		// Delete data
		dataDao.findAllAndRemove(query);
		// Make Search
		Query query2 = new Query();
		query2.addCriteria(Criteria.where(Constant.LABEL_TESTDATA_DATAID).in((Object[]) dataIds));
		labelDataDao.findAllAndRemove(query2);

		return resultVO;
	}

	@Override
	public ResultVO importTestData(MultipartFile file, String modelId, String dataId) {
		// Check input parameter is valid
		checkParam(file, modelId);
		ResultVO resultVO = new ResultVO(HttpStatus.OK);
		if (StringUtils.isNotBlank(dataId)) {
			List<Map<String, String>> list = new ArrayList<>();
			List<Map<String,String>> importData = checkImportData(list, file, modelId, dataId);
			resultVO.setData(importData);
			resultVO.setContent(list);
			return resultVO;
		}
		//  Check the validity of the file and parse the data
		List<Map<String,String>> data = checkImportData(file, modelId);
		resultVO.setData(data);
		return resultVO;
	}


	@Override
	public ResultVO exportTestData(String dataId){
		// Check input parameter is valid
		Assert.hasLength(dataId, Constant.REQUEST_TESTDATA_ID);

		// Get special DataDO by database
		DataDO dataDO = getDataDO(dataId);
		List<Map<String, String>> modelContent = dataDO.getModelContent();
		// Get mapping data by modelConent
		List<StringWriter> data = getMappingContent(modelContent, dataDO.getModelId());

		// Get CaseDO to add
		List<CaseDTO> cases = getCaseDO(modelContent, data, dataDO);
		return caseManager.addAllCase(cases);
	}

	@Override
	public void exportDataSet(String fileType,DataInfoDTO dataInfoDTO, HttpServletResponse response) {
		// Check input parameter is valid
		Assert.hasLength(dataInfoDTO.getDataId(), Constant.REQUEST_TESTDATA_ID);
		DataDO dataDO = getDataDO(dataInfoDTO.getDataId());
		Integer type = dataDO.getType().getValue();
		
		if (type.equals(Constant.DATA_TYPE_CASE) && fileType.equalsIgnoreCase(Constant.FILE_TYPE_CSV)) {
			exportCSV(dataDO, fileType, response);
		} else if (type.equals(Constant.DATA_TYPE_CASE) && fileType.equalsIgnoreCase(Constant.FILES_TYPE_JSON)) {
			exportJSON(dataDO, response);
		} else if (type.equals(Constant.DATA_TYPE_FILE)) {
			exportFile(dataDO, fileType, response);
		}
	}
	
	@Override
	public void exportModelContent(List<Map<String, String>> datas, HttpServletResponse response) {
		Assert.notEmpty(datas, Constant.REQUEST_TESTDATA_CONTENT);
		
		// Output Stream
		OutputStream os;
		try {
			os = response.getOutputStream();
			// Response export data
			CsvUtils.responseSetProperties(Constant.EXPORT_DATA_NAME + Constant.STRING_FORMAT_UNDERLINE, response, Constant.FILE_TYPE_CSV);
			List<StringBuilder> titleList = new ArrayList<>();
			List<String> list = new ArrayList<>();
			StringBuilder heads = new StringBuilder();
			Map<String, String> map2 = datas.get(0);
			for (Map.Entry<String, String> map : map2.entrySet()) {
				String key = map.getKey();
				list.add(key);
			}
			list.forEach(s -> heads.append(s));
			for (Map<String, String> data : datas) {
				StringBuilder titles = new StringBuilder();
				StringBuilder labelsContent = new StringBuilder();
				StringBuilder conditionsContent = new StringBuilder();
				Map<String, Object> map = new HashMap<>();
				
				 String string = data.get("labels");
				 String[] labels = string.split(";");
				// Analysis of labels correlation
				for (String labelContent : labels) {
					if (labelsContent.length() > 0) {
						labelsContent.append(Constant.CSV_AGGREGATE);
					}
					labelsContent.append(labelContent);
				}
				map.put(Constant.IMPORTDATA_LABELS, labelsContent);
				String string2 = data.get("conditions");
				String[] split = string2.split(";");

				// Analysis of conditions correlation
				for (int i = 0; i < split.length; i++) {
					if (conditionsContent.length() > 0) {
						conditionsContent.append(Constant.CSV_AGGREGATE);
					}
					conditionsContent.append(split[0] + Constant.CSV_CONDITIONS + split[1]);
				}
				map.put(Constant.IMPORTDATA_CONDITIONS, conditionsContent);

				// Analysis of name correlation
				map.put(Constant.IMPORTDATA_CASEID, data.get("CaseID"));

				// Analysis of description correlation
				map.put(Constant.IMPORTDATA_TEMPLATE,
						data.get("template") == null ? Constant.EMPTY_STRING : data.get("template"));
				
				
				
				
				
				// response data
//				datas.add(map);
				// CSV tool class download file
				titleList.add(titles);
			}
			//CsvUtils.doExport(datas, titleList, os);

		} catch (Exception e) {
			log.warn(Constant.LOG_FORMAT_SIMPLE, e);
		}
		
	}
	
	/**
	 * DTO --> DO
	 * @param dataDO
	 * @return
	 */
	private DataDTO doToDTO(DataDO dataDO) {
		DataDTO dataDTO = new DataDTO();
		dataDTO.setId(dataDO.getId());
		dataDTO.setName(dataDO.getName());
		dataDTO.setModelId(dataDO.getModelId());
		dataDTO.setLabels(dataDO.getLabels() == null ? new ArrayList<>() : dataDO.getLabels());
		dataDTO.setTemplates(dataDO.getTemplates());
		dataDTO.setModelContent(dataDO.getModelContent() == null ? new ArrayList<>() : dataDO.getModelContent());
		dataDTO.setDescription(dataDO.getDescription());
		dataDTO.setLastModifyDate(dataDO.getLastModifyDate());
		dataDTO.setType(dataDO.getType().getValue() == Constant.DATA_TYPE_CASE ? Constant.DATASET_TYPE_CASE : Constant.DATASET_TYPE_FILE);
		return dataDTO;
	}

	/**
	 * DO --> DTO
	 * @param dataDTO
	 * @return
	 */
	private DataDO dtoToDO(DataDTO dataDTO) {
		DataDO dataDO = new DataDO();
		dataDO.setName(dataDTO.getName());
		dataDO.setModelId(dataDTO.getModelId());
		dataDO.setTemplates(dataDTO.getTemplates() == null ? new ArrayList<>() : dataDTO.getTemplates());
		dataDO.setDescription(dataDTO.getDescription());
		dataDO.setType(dataDTO.getType().equals(Constant.DATASET_TYPE_CASE) ? DataType.TYPE_CASE : DataType.TYPE_FILE);
		dataDO.setLastModifyDate(dataDTO.getLastModifyDate());
		List<Map<String,String>> modelContent = dataDTO.getModelContent();
		
		if (!modelContent.isEmpty()) {
			for (Map<String, String> map : modelContent) {
					map.remove(Constant.MODEL_STATUS);
			}
			dataDO.setModelContent(modelContent);
		} else {
			dataDO.setModelContent(new ArrayList<>());
		}
		
		return dataDO;
	}

	/**
	 * Check input parameter is valid
	 * @param dataDTO
	 */
	private void checkParam(DataDTO dataDTO) {
		Assert.notNull(dataDTO, Constant.REQUEST_BODY_TESEDATA);
		Assert.hasLength(dataDTO.getName(), Constant.REQUEST_TESTDATA_NAME);
		Assert.hasLength(dataDTO.getModelId(), Constant.REQUEST_MODEL_ID);
		Assert.notNull(dataDTO.getType(), Constant.REQUEST_TESTDATA_TYPE);
		Assert.notEmpty(dataDTO.getModelContent(), Constant.REQUEST_TESTDATA_CONTENT);
		if (dataDTO.getLabels() == null) {
			dataDTO.setLabels(new ArrayList<>());
		}
		if (!(dataDTO.getType().equals(Constant.DATASET_TYPE_CASE)  || dataDTO.getType().equals(Constant.DATASET_TYPE_FILE))){
			throw new FileTypeException(Constant.EXPORT_DATA_TYPE);
		}
	}

	/**
	 * Check input parameter is valid
	 * @param dataId
	 * @param dataDTO
	 */
	private void checkParam(String dataId, DataDTO dataDTO) {
		Assert.hasLength(dataId, Constant.REQUEST_TESTDATA_ID);
		Assert.notNull(dataDTO, Constant.REQUEST_BODY_TESEDATA);
		Assert.notEmpty(dataDTO.getModelContent(), Constant.REQUEST_TESTDATA_CONTENT);
	}

	/**
	 * Check input parameter is valid
	 * @param file
	 * @param modelId
	 */
	private void checkParam(MultipartFile file, String modelId) {
		// Check that the input parameter is valid
		Assert.notNull(file, Constant.ASSERT_REQUEST_CASEFILE);
		Assert.hasLength(modelId, Constant.REQUEST_MODEL_ID);
		String fileName = file.getOriginalFilename();
		String suffix = fileName.substring(fileName.lastIndexOf(Constant.FILE_LAST_INDEXOF) + 1);

		if (!suffix.equalsIgnoreCase(Constant.FILE_TYPE_CSV)) {
			throw new FileTypeException(Constant.FILE_TYPE_FAILED);
		}
	}

	/**
	 * Response data to view
	 * @param datas
	 * @return
	 */
	private List<DataDTO> getDataDTO(List<DataDO> datas) {
		List<DataDTO> dataDTO = new ArrayList<>();
		for (DataDO dataDO : datas) {
			if (Objects.isNull(dataDO)) {
				log.warn(Constant.INVALID_DOCUMENT);
				continue;
			}
			DataDTO doToDTO = doToDTO(dataDO);
			dataDTO.add(doToDTO);
		}
		return dataDTO;
	}

	/**
	 * Check input name is exists
	 * @param dataDTO
	 * @return
	 */
	private boolean checkExists(DataDTO dataDTO) {
		Query query = new Query();
		query.addCriteria(Criteria.where(Constant.TEST_DATA_NAME).is(dataDTO.getName()));
		return dataDao.exists(query);
	}

	/**
	 * Check the validity of the file and parse the data
	 * @param file
	 * @param modelId
	 * @return
	 */
	private List<Map<String, String>> checkImportData(MultipartFile file, String modelId) {

		if (!file.isEmpty()) {
			try {
				String str = new String(file.getBytes(), StandardCharsets.UTF_8);
				List<String> contentList = new ArrayList<>();
				String[] lines = str.split(System.getProperty(Constant.LINE_SEPARATOR));
				for (int i = 1; i < lines.length; i++) {
					contentList.add(lines[i]);
				}
				String[] split2 = lines[0].split(Constant.CSV_DATA_SPLIT);
				List<String> headList = Arrays.asList(split2);
				// Determine whether the CSV file header has the same field
				long count = headList.stream().distinct().count();
				if (count < headList.size()) {
					throw new AlreadyExistsException(Constant.ALREADY_CSVFILE_SAME_HEAD);
				}
				Query query = new Query();
				query.addCriteria(Criteria.where(Constant.MODEL_ID).is(modelId));
				if (!modelDao.exists(query)) {
					throw new DataNotFoundException(Constant.MODELDATA_NOTFOUND_EXCEPTION);
				}
				// Check special field is valid
				checkField(split2, modelId);
				// Check special data is valid
				checkValid(contentList, modelId);
				// Get special data
				return getImportData(headList, contentList);
			} catch (IOException e) {
				log.warn(Constant.READ_FILE_FAILED, e);
				throw new ReadFileException(Constant.READ_FILE_FAILED);
			}
		} else {
			throw new ReadFileException(Constant.FILE_EMPTY_FAIED);
		}
	}

	/**
	 * Get import data
	 * @param headList
	 * @param contentList
	 * @return
	 */
	private List<Map <String, String>> getImportData(List<String> headList, List<String> contentList){
		List<Map <String, String>> lists = new ArrayList<>();
		try {
			for (int i = 0; i < contentList.size(); i++) {
				Map<String, String> map = new HashMap<>();
				for (int j = 0; j < headList.size();j++) {
					String[] split1 = contentList.get(i).split(Constant.CSV_DATA_SPLIT);
					for (int i1 = 0; i1 < split1.length; i1++) {
						map.put(headList.get(i1),split1[i1]);
					}
				}
				lists.add(map);
			}
			
		}catch(ArrayIndexOutOfBoundsException e) {
			throw new IllegalArgumentException(Constant.IMPORT_DATA_INVAILD);
		}
	
		
		return lists;
	}

	/**
	 * Check special field is valid
	 *
	 * 1.Determine whether there is caseId,labels,conditions,template in CSV file
	 * 2.Determine whether the data of the model exists
	 * @param headList
	 * @param split2
	 * @param modelId
	 */
	private void checkField(String[] split2, String modelId) {

		// Determine whether there is caseId,labels,conditions,template in CSV file
		Query query = new Query();
		query.addCriteria(Criteria.where(Constant.MODEL_ID).is(modelId));
		// Get model data
		ModelDO modelDO = modelDao.findOne(query);
		Map<String, String> content = modelDO.getContent();
		List<String> contentKey = new ArrayList<>();
		for (Map.Entry<String, String> entry : content.entrySet()) {
			contentKey.add(entry.getKey());
		}
		if (!split2[Constant.IMPORT_CASEID].equals(Constant.IMPORTDATA_CASEID)) {
			throw new DataNotFoundException(Constant.IMPORTDATA_CASEID_NOTEXISTS);
		}
		if (!split2[Constant.IMPORT_LABELS].equals(Constant.IMPORTDATA_LABELS)) {
			throw new DataNotFoundException(Constant.IMPORTDATA_LABELS_NOTEXISTS);
		}
		if (!split2[Constant.IMPORT_CONDITIONS].equals(Constant.IMPORTDATA_CONDITIONS)) {
			throw new DataNotFoundException(Constant.IMPORTDATA_CONDITIONS_NOTEXISTS);
		}
		if (!split2[Constant.IMPORT_TEMPLATE].equals(Constant.IMPORTDATA_TEMPLATE)) {
			throw new DataNotFoundException(Constant.IMPORTDATA_TEMPLATE_NOTEXISTS);
		}
		// Determine whether the data of the model exists
		if (!Arrays.asList(split2).containsAll(contentKey)) {
			throw new DataNotFoundException(Constant.IMPORTDATA_MODELCONTENT_NOTEXISTS);
		}
	}

	/**
	 * Check special data is valid
	 *
	 * 1.Determine whether template in CSV file is the value bound by model
	 * 2.Check templateName is valid
	 * 3.Determine the uniqueness of Case ID in CSV file
	 * @param contentList
	 * @param modelId
	 */
	private void checkValid(List<String> contentList, String modelId) {
		// Determine whether template in CSV file is the value bound by model
		Query query2 = new Query();
		query2.addCriteria(Criteria.where(Constant.TEMPLATE_MODEL_MODELID).in(modelId));

		List<TemplateModelDO> tempalteModel = templateModelDao.find(query2);
		// Get templateId
		List<String> templateId = new ArrayList<>();
		tempalteModel.forEach(s -> templateId.add(s.getTemplateId()));
		// Make Search templateDO data
		Query query3 = new Query();
		query3.addCriteria(Criteria.where(Constant.TEMPLATE_ID).in(templateId));
		List<TemplateDO> templateDO = templateDao.find(query3);
		// Get templateName
		List<String> templateName = new ArrayList<>();
		templateDO.forEach(s -> templateName.add(s.getName()));
		templateName.add(Constant.EMPTY_STRING);
		// Add templateName
		Set<String> set = new HashSet<>();
		// Add caseId
		List<String> caseId = new ArrayList<>();
		for (String value : contentList) {
			String[] split3 = value.split(Constant.CSV_DATA_SPLIT);
			for (int i = 0; i < split3.length; i++) {
				if (i == Constant.IMPORT_CASEID) {
					caseId.add(split3[i]);
				}
				if (i == Constant.IMPORT_TEMPLATE) {
					set.add(split3[i]);
				}
			}
		}
		// Check templateName is valid
		if(!templateName.containsAll(set)) {
			throw new DataNotFoundException(Constant.IMPORTDATA_TEMPLATENAME_NOTEXISTS);
		}
		// Determine the uniqueness of Case ID in CSV file
		long count2 = caseId.stream().distinct().count();
		if (count2 < caseId.size()) {
			throw new AlreadyExistsException(Constant.IMPORTDATA_CASEID_EXISTS);
		}
	}

	/**
	 * Check the validity of the file and parse the data
	 * @param list
	 * @param file
	 * @param modelId
	 * @param dataId
	 * @return
	 */
	private List<Map<String,String>> checkImportData(List<Map<String, String>> list, MultipartFile file, String modelId, String dataId){

		if (!file.isEmpty()) {
			try {
				// Make search
				Query query = new Query();
				query.addCriteria(Criteria.where(Constant.TEST_DATA_ID).is(dataId));
				if (!dataDao.exists(query)) {
					throw new DataNotFoundException(Constant.DATASET_DATA_NOTFOUND_EXCEPTION);
				}
				DataDO dataDO = dataDao.findOne(query);
				// Get old data
				List<Map<String, String>> modelContent = dataDO.getModelContent();
				String str = new String(file.getBytes(), StandardCharsets.UTF_8);
				String[] split = str.split(System.getProperty(Constant.LINE_SEPARATOR));
				String[] split2 = split[0].split(Constant.CSV_DATA_SPLIT);
				List<String> headList = Arrays.asList(split2);

				List<String> contentList = new ArrayList<>();
				for (int i = 0; i < split.length; i++) {
					if (i > 0) {
						contentList.add(split[i]);
					}
				}
				// Determine whether the CSV file header has the same field
				long count = headList.stream().distinct().count();
				if (count < headList.size()) {
					throw new AlreadyExistsException(Constant.ALREADY_CSVFILE_SAME_HEAD);
				}
				Query query2 = new Query();
				query2.addCriteria(Criteria.where(Constant.MODEL_ID).is(modelId));
				if (!modelDao.exists(query2)) {
					throw new DataNotFoundException(Constant.MODELDATA_NOTFOUND_EXCEPTION);
				}
				// Check special field is valid
				checkField(split2, modelId);
				// Check special data is valid
				checkValid(contentList, modelId);
				// Get new data
				List<Map<String, String>> importData = getImportData(headList, contentList);

				// Analyze old data and new data, get difference data
				parseData(list, modelContent, importData);
				return importData;
			} catch (IOException e) {
				log.warn(Constant.READ_FILE_FAILED, e);
				throw new ReadFileException(Constant.READ_FILE_FAILED);
			}
		} else {
			throw new ReadFileException(Constant.FILE_EMPTY_FAIED);
		}

	}
	
	/**
	 * old and new data to contains is empty
	 * @param list
	 * @param oldData
	 * @param newData
	 */
	private void checkIsEmpty(List<Map<String, String>> list, List<Map<String,String>> oldData, List<Map<String,String>> newData) {
		if (oldData.isEmpty()) {
			for (Map<String, String> map : newData) {
				Map<String, String> maps = new HashMap<>();
				for (Map.Entry<String, String> map2 : map.entrySet()) {
					maps.put(map2.getKey(), map2.getValue());
					maps.put(Constant.IMPORTDATA_STATUS, Constant.IMPORTDATA_STATUS_ADD);
				}
				list.add(maps);
			}
		}
		if (newData.isEmpty()) {
			for (Map<String, String> map : oldData) {
				Map<String, String> maps = new HashMap<>();
				for (Map.Entry<String, String> map2 : map.entrySet()) {
					maps.put(map2.getKey(), map2.getValue());
					maps.put(Constant.IMPORTDATA_STATUS, Constant.IMPORTDATA_STATUS_DELETE);
				}
				list.add(maps);
			}
		}
	}
	
	/**
	 * old and new data to contains is notEmpty
	 * @param modifyList
	 * @param set
	 * @param oldData
	 * @param newData
	 */
	private void checkIsValid(List<Map<String, String>> modifyList, Set<Map<String, String>> set, List<Map<String,String>> oldData, List<Map<String,String>> newData) {
		for (int i = 0; i < oldData.size(); i++) {
			for (int j = 0; j < newData.size(); j++) {
				Map<String, String> map = oldData.get(i);
				Map<String, String> map2 = newData.get(j);
				if (map.get(Constant.IMPORTDATA_CASEID).equals(map2.get(Constant.IMPORTDATA_CASEID))) {
					modifyList.add(map2);
				} else {
					set.add(map);
					set.add(map2);
				}
			}
		}
		// Clear others content
		Iterator<Map<String, String>> iterator = set.iterator();
		while (iterator.hasNext()) {
			Map<String, String> next = iterator.next();
			for (Map<String, String> map : modifyList) {
				String oldCaseId = next.get(Constant.IMPORTDATA_CASEID);
				String newCaseID = map.get(Constant.IMPORTDATA_CASEID);
				if (oldCaseId.equals(newCaseID)) {
					iterator.remove();
				}
			}
		}
	}
	
	/**
	 *
	 * Analyze old data and new data
	 * @param list
	 * @param modelContent
	 * @param importData
	 */
	private void parseData(List<Map<String, String>> list, List<Map<String,String>> modelContent, List<Map<String,String>> importData) {

		// Get intersection
		List<Map<String,String>> oldData = modelContent.stream().filter(item -> !importData.contains(item)).collect(Collectors.toList());
		List<Map<String,String>> newData = importData.stream().filter(item -> !modelContent.contains(item)).collect(Collectors.toList());
		
		// check data is empty
		if (oldData.isEmpty() || newData.isEmpty()) {
			checkIsEmpty(list, oldData, newData);
		} else {
			// The modified content is stored in lists
			List<Map<String, String>> modifyList = new ArrayList<>();
			// Set to store new and deleted content
			Set<Map<String, String>> set = new HashSet<>();
			// check data is valid , parse difference data
			checkIsValid(modifyList, set, oldData, newData);
			// Get difference data
			differenceData(modifyList, list, set, importData);
		}
		
		// if labels,conditions,template is null, set to old data
		for (Map<String, String> oldDatas : modelContent) {
			for (Map<String, String> newDatas : importData) {
				
				if (oldDatas.get(Constant.IMPORTDATA_CASEID).equals(newDatas.get(Constant.IMPORTDATA_CASEID))) {
					String labels = newDatas.get(Constant.IMPORTDATA_LABELS);
					String conditions = newDatas.get(Constant.IMPORTDATA_CONDITIONS);
					String template = newDatas.get(Constant.IMPORTDATA_TEMPLATE);
					if (labels.equals(Constant.EMPTY_STRING)) {
						newDatas.put(Constant.IMPORTDATA_LABELS, oldDatas.get(Constant.IMPORTDATA_LABELS));
					}
					if (conditions.equals(Constant.EMPTY_STRING)) {
						newDatas.put(Constant.IMPORTDATA_CONDITIONS, oldDatas.get(Constant.IMPORTDATA_CONDITIONS));
					}
					if (template.equals(Constant.EMPTY_STRING)) {
						newDatas.put(Constant.IMPORTDATA_TEMPLATE, oldDatas.get(Constant.IMPORTDATA_TEMPLATE));
					}
				}
			}
		}
	}

	/**
	 * Get difference data and return
	 * @param modifyList  record modify content
	 * @param list record difference data
	 * @param set
	 * @param importData
	 */
	private void differenceData(List<Map<String, String>> modifyList, List<Map<String, String>> differenceList, Set<Map<String, String>> set, List<Map<String,String>> importData){
		// Record the modified content
		for (Map<String, String> map : modifyList) {
			Map<String, String> maps = new HashMap<>();
			for (Map.Entry<String, String> map2 : map.entrySet()) {
				if (map2.getKey().equals(Constant.IMPORTDATA_CASEID)) {
					maps.put(map2.getKey(), map2.getValue());
					maps.put(Constant.IMPORTDATA_STATUS, Constant.IMPORTDATA_STATUS_UPDATE);
				}
			}
			differenceList.add(maps);
		}
		// Record add and deleted content
		for (Map<String, String> map : set) {
			Map<String, String> maps = new HashMap<>();
			for (Map<String, String> map2 : importData) {
				if (map.equals(map2)) {
					maps.put(Constant.IMPORTDATA_CASEID, map.get(Constant.IMPORTDATA_CASEID));
					maps.put(Constant.IMPORTDATA_STATUS, Constant.IMPORTDATA_STATUS_ADD);
					break;
				} else {
					maps.put(Constant.IMPORTDATA_CASEID, map.get(Constant.IMPORTDATA_CASEID));
					maps.put(Constant.IMPORTDATA_STATUS, Constant.IMPORTDATA_STATUS_DELETE);
				}
			}
			differenceList.add(maps);
		}
	}

	/**
	 * Template model mapping data
	 * @param modelContent
	 * @return
	 */
	private List<StringWriter> getMappingContent(List<Map<String, String>> modelContent, String modelId){
		List<Map<String, String>> lists = new ArrayList<>();
		for (Map<String, String> map : modelContent) {
			Map<String, String> newMap = new HashMap<>();
			for (Map.Entry<String, String> map2 : map.entrySet()) {
				String key = map2.getKey();
				String value = map2.getValue();
				if (!(key.equals(Constant.IMPORTDATA_CASEID) || key.equals(Constant.IMPORTDATA_LABELS) || key.equals(Constant.IMPORTDATA_CONDITIONS))) {
					newMap.put(key, value);
				}
			}
			lists.add(newMap);
		}
		// Get template data by templateName
		List<String> templateName = new ArrayList<>();
		lists.forEach(s -> templateName.add(s.get(Constant.IMPORTDATA_TEMPLATE)));
		List<TemplateDO> template = getTemplateData(templateName);
		
		// Get templateId
		List<String> templateId = new ArrayList<>();
		template.forEach(s -> templateId.add(s.getId()));
		
		Query query = new Query();
		query.addCriteria(Criteria.where(Constant.TEMPLATE_MODEL_TEMPLATEID).in(templateId));
		query.addCriteria(Criteria.where(Constant.TEMPLATE_MODEL_MODELID).is(modelId));
		
		// Get new templateId
		List<String> templateIds = new ArrayList<>();
		List<TemplateModelDO> templateModelDO = templateModelDao.find(query);
		for (TemplateModelDO templateModelDO2 : templateModelDO) {
			templateIds.add(templateModelDO2.getTemplateId());
		}
		
		List<TemplateDO> templateDO = getTemplateDO(templateIds);

		// Get mapping data
		@SuppressWarnings("unchecked")
		List<StringBuilder> str  = (List<StringBuilder>) dataMappingService.datasetToCase(templateDO, lists).getData();

		List<StringWriter> data = new ArrayList<>();
		for (int i = 0; i < lists.size(); i ++) {
			Map<String, String> map = lists.get(i);
			StringBuilder stringBuilder = str.get(i);
			StringWriter result = new StringWriter();
			VelocityContext context = new VelocityContext(map);
			Velocity.evaluate(context, result, Constant.IMPORTDATA_TEMPLATE,stringBuilder.toString());
			data.add(result);
		}
		return data;
	}

	/**
	 * Get template data by special name
	 * @param templateName
	 * @return
	 */
	private List<TemplateDO> getTemplateData (List<String> templateName){
		Query query = new Query();
		query.addCriteria(Criteria.where(Constant.TEMPLATE_NAME).in(templateName));
		return templateDao.find(query);
	}
	
	/**
	 * Get template data by special templateId
	 * @param templateId
	 * @return
	 */
	private List<TemplateDO> getTemplateDO(List<String> templateId){
		Query query = new Query();
		query.addCriteria(Criteria.where(Constant.TEMPLATE_ID).in(templateId));
		return templateDao.find(query);
	}
	/**
	 * Get dataDO data by special dataId
	 * @param dataId
	 * @return
	 */
	private DataDO getDataDO(String dataId) {
		Query query = new Query();
		query.addCriteria(Criteria.where(Constant.TEST_DATA_ID).is(dataId));
		if (!dataDao.exists(query)) {
			throw new DataNotFoundException(Constant.DATASET_DATA_NOTFOUND_EXCEPTION);
		}
		return dataDao.findOne(query);
	}
	
	/**
	 * Export CSV to local
	 * @param dataDO
	 * @param fileType
	 * @param response
	 */
	private void exportCSV (DataDO dataDO, String fileType, HttpServletResponse response) {
		List<Map<String, String>> modelContent = dataDO.getModelContent();
		// Get mapping data by modelContent
		List<StringWriter> data = getMappingContent(modelContent, dataDO.getModelId());
		// Get caseDO
		List<CaseDTO> targetDatas = getCaseDO(modelContent, data, dataDO);
		// Output Stream
		OutputStream os;
		try {
			os = response.getOutputStream();
			// Response export data
			CsvUtils.responseSetProperties(dataDO.getName() + Constant.STRING_FORMAT_UNDERLINE, response, fileType);
			List<Map<String, Object>> datas = new ArrayList<>();
			List<StringBuilder> titleList = new ArrayList<>();
			for (CaseDTO caseDO : targetDatas) {
				StringBuilder titles = new StringBuilder();
				titles.append(Constant.CSV_HEAD_CONTENT);
				StringBuilder labelsContent = new StringBuilder();
				StringBuilder conditionsContent = new StringBuilder();
				Map<String, Object> map = new HashMap<>();
				List<String> labels = caseDO.getLabels();
				// Analysis of labels correlation
				for (String labelContent : labels) {
					if (labelsContent.length() > 0) {
						labelsContent.append(Constant.CSV_AGGREGATE);
					}
					labelsContent.append(labelContent);
				}
				map.put(Constant.IMPORTDATA_LABELS, labelsContent);
				Map<String, String> conditions = caseDO.getConditions();

				// Analysis of conditions correlation
				for (Map.Entry<String, String> entry : conditions.entrySet()) {
					if (conditionsContent.length() > 0) {
						conditionsContent.append(Constant.CSV_AGGREGATE);
					}
					conditionsContent.append(entry.getKey() + Constant.CSV_CONDITIONS + entry.getValue());
				}
				map.put(Constant.IMPORTDATA_CONDITIONS, conditionsContent);

				// Analysis of name correlation
				map.put(Constant.CASE_NAME, caseDO.getName());

				// Analysis of description correlation
				map.put(Constant.CASE_DESCRIPTION, caseDO.getDescription() == null ? Constant.EMPTY_STRING : caseDO.getDescription());
				List<String> steps2 = caseDO.getSteps();

				// Analysis of steps correlation
				for (int i = 0; i < steps2.size(); i++) {
					titles.append(Constant.CSV_SYMBOLS_STEPS + i);
					map.put(Constant.CSV_SYMBOLS_STEPS + i, steps2.get(i));
					titles.append(Constant.CSV_DATA_SPLIT);
				}
				// response data
				datas.add(map);
				// CSV tool class download file
				titleList.add(titles);
			}
			CsvUtils.doExport(datas, titleList, os);

		} catch (Exception e) {
			log.warn(Constant.LOG_FORMAT_SIMPLE, e);
		}
	}
	
	/**
	 * Export JSON to local
	 * @param dataDO
	 * @param response
	 */
	private void exportJSON (DataDO dataDO, HttpServletResponse response) {
		List<Map<String,String>> modelContent = dataDO.getModelContent();
		List<StringWriter> data = getMappingContent(modelContent, dataDO.getModelId());

		// Get CaseDO to add
		List<CaseDTO> caseDO = getCaseDO(modelContent, data, dataDO);
		try { 
			OutputStream os = response.getOutputStream();
			 // Set file suffix
	        SimpleDateFormat sdf = new SimpleDateFormat(Constant.TIME_FORMAT_STYLE01);
	        String fn = Constant.EXPORT_PREFIX + sdf.format(new Date()) + Constant.FILE_LAST_INDEXOF + Constant.FILES_TYPE_JSON;
	        // Set response
	        response.setContentType(Constant.CONTENT_TYPE);
	        response.setCharacterEncoding(Constant.CODE_UTF_FORMART);
	        response.setHeader(Constant.HEADER_PRAGMA, Constant.HEADER_PUBLIC);
	        response.setHeader(Constant.HEADER_CACHE, Constant.HEADER_MAXAGE);
			response.setHeader(Constant.HEADER_CONTENT, Constant.HEADER_CONTENTTYPE + URLEncoder.encode(fn, Constant.CODE_UTF_FORMART));
	        os.write(JSON.toJSONString(caseDO).getBytes(Constant.CODE_FORMART));
			os.flush();
			os.close();
			
		} catch (Exception e) {
			log.info(Constant.EXPORT_FILE_FIALED);
			log.error(Constant.LOG_FORMAT, e.getClass().getName(), e.getMessage());
		}
	}
	
	/**
	 * Export special file to local
	 * @param dataDO
	 * @param fileType
	 * @param response
	 */
	private void exportFile(DataDO dataDO, String fileType, HttpServletResponse response) {
		// Get special DataDO by database
		List<Map<String, String>> modelContent = dataDO.getModelContent();
		List<String> caseID = new ArrayList<>();
		for (Map<String, String> map : modelContent) {
			String string = map.get(Constant.IMPORTDATA_CASEID);
			caseID.add(string);
		}
		// Get mapping data by modelContent
		List<StringWriter> data = getMappingContent(modelContent, dataDO.getModelId());
		SimpleDateFormat sdf = new SimpleDateFormat(Constant.TIME_FORMAT_STYLE01);
		String format = sdf.format(new Date());
		
		File parentFile = new File(Constant.FILE_TEMP_NAME);
		if (parentFile.exists()) {
			FileUtils.clear(parentFile);
		}
		File files = new File(Constant.FILE_TEMP_NAME + File.separator + format);
		if (!files.exists()) {
			files.mkdirs();
		}
		try (OutputStream outputStream = response.getOutputStream()){
			for (int i = 0; i < data.size(); i++) {
				File file = new File(files.getPath() + Constant.FILE_PATH + dataDO.getName()
						+ Constant.STRING_FORMAT_UNDERLINE + caseID.get(i) + Constant.FILE_LAST_INDEXOF + fileType);
				try(FileOutputStream writer = new FileOutputStream(file);
						BufferedOutputStream out = new BufferedOutputStream(writer)){
					out.write(data.get(i).toString().getBytes());
					out.flush();
				}
			}
			File sourceFile = new File(files.getPath());
			try (ZipOutputStream zos = new ZipOutputStream(outputStream)) {
				File[] sourceFiles = sourceFile.listFiles();
				byte[] bufs = new byte[1024 * 10];
				for (int i = 0; i < sourceFiles.length; i++) {
					// Create a ZIP entity and add it to the package
					ZipEntry zipEntry = new ZipEntry(sourceFiles[i].getName());
					zos.putNextEntry(zipEntry);
					// Read the file to be compressed and write it into the compressed package
					try (FileInputStream fis = new FileInputStream(sourceFiles[i]);
							BufferedInputStream bis = new BufferedInputStream(fis, 1024 * 10);) {
						int read = 0;
						while ((read = bis.read(bufs, 0, 1024 * 10)) != -1) {
							zos.write(bufs, 0, read);
						}
					}
				}
				response.setContentType(Constant.CONTENT_TYPE);
				response.setCharacterEncoding(Constant.CODE_UTF_FORMART);
				response.setHeader(Constant.HEADER_PRAGMA, Constant.HEADER_PUBLIC);
				response.setHeader(Constant.HEADER_CACHE, Constant.HEADER_MAXAGE);
				response.setHeader(Constant.HEADER_CONTENT, Constant.HEADER_CONTENTTYPE
						+ URLEncoder.encode(Constant.FILE_TEMPZIP_NAME, Constant.CODE_UTF_FORMART));
			} catch (Exception e) {
				log.warn(Constant.LOG_FORMAT_SIMPLE, e);
				throw new ReadFileException(Constant.FILE_WRITE_FAIED);
			}
		} catch (Exception e) {
			log.warn(Constant.LOG_FORMAT_SIMPLE, e);
		}
	}
	
	/**
	 * Get caseDO
	 * @param modelContent
	 * @param data
	 * @param dataDO
	 * @return
	 */
	private List<CaseDTO> getCaseDO(List<Map<String, String>> modelContent, List<StringWriter> data, DataDO dataDO){
		// add data to caseManage
		List<CaseDTO> cases = new ArrayList<>();
		for (int i = 0; i < modelContent.size(); i++) {
			Map<String, String> map = modelContent.get(i);

			CaseDTO caseDTO = new CaseDTO();
			caseDTO.setName(dataDO.getName() + Constant.STRING_FORMAT_UNDERLINE + map.get(Constant.IMPORTDATA_CASEID));
			try {
				Map<String, String> conditions = new HashMap<>();
				String string = map.get(Constant.IMPORTDATA_CONDITIONS);
				String[] condition = string.split(Constant.CSV_AGGREGATE);
				for (String string2 : condition) {
					
					String[] split = string2.split(Constant.CSV_CONDITIONS);
					if (StringUtils.isNotBlank(string2) && split.length > 1){
						conditions.put(split[0], split[1]);
					}
				}
				caseDTO.setConditions(conditions);
			} catch (ArrayIndexOutOfBoundsException e) {
				throw new IllegalArgumentException(Constant.IMPORT_DATA_CONDITIONS);
			}
			String string2 = map.get(Constant.IMPORTDATA_LABELS);
			String[] label = string2.split(Constant.CSV_AGGREGATE);
			caseDTO.setLabels(Arrays.asList(label));
			StringWriter stringWriter = data.get(i);
			String[] split = stringWriter.toString().split(Constant.STRING_FORMAT);
			caseDTO.setSteps(Arrays.asList(split));
			cases.add(caseDTO);
		}
		return cases;
	}


}
