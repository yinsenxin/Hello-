package jp.co.brother.datadriver.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import jp.co.brother.datadriver.dto.TemplateMappingDTO;
import jp.co.brother.datadriver.service.IDataMappingService;
import jp.co.brother.datadriver.vo.ResultVO;


@RestController
@RequestMapping("/scripts")
public class DataMappingController {
	
	@Autowired
	private IDataMappingService dataMappingService;
	
	@PostMapping(value = "", produces = "application/json;charset=UTF-8")
	public ResultVO index(@RequestBody TemplateMappingDTO templateMappingDTO) {
		
		return dataMappingService.templateAndModelMappingData(templateMappingDTO);
	}
	
}
