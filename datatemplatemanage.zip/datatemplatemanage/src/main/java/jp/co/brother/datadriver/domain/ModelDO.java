package jp.co.brother.datadriver.domain;

import java.util.List;
import java.util.Map;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.Field;

import lombok.Data;


@Data
@Document(collection = "model")
public class ModelDO {
	
	/**
	 * This is the id field of the modelDO
	 */
	@Id
	private String id;
	
	/**
	 * This is the name field of the modelDO
	 */
	private String name;
	
	/**
	 * This is the status field of the modelDO
	 */
	private Integer status;
	
	/**
	 * This is the labels field of the modelDO
	 */
	private List<String> labels;
	
	/**
	 * This is the templates field of the modelDO
	 */
	private List<String> templates;
	
	/**
	 * This is the content field of the modelDO
	 */
	private Map<String, String> content;
	
	/**
	 * This is the description field of the modelDO
	 */
	private String description;
	
	/**
	 * This is the lastModifyDate field of the modelDO
	 */
	@Field("last_modify_date")
	private String lastModifyDate;
	
	
}
