package jp.co.brother.datadriver.controller;

import jp.co.brother.datadriver.service.IModelService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import jp.co.brother.datadriver.dto.ModelDTO;
import jp.co.brother.datadriver.vo.ResultVO;

@RestController
@RequestMapping("/models")
public class ModelController {

    @Autowired
    private IModelService modelService;

    @GetMapping(value = "", produces = "application/json;charset=UTF-8")
    public ResultVO getModelDatas(@RequestParam(value = "modelIds", required = false) String[] modelIds,
                                  @RequestParam(value="labels", required = false) String[] labels,
                                  @RequestParam(value = "name", required = false) String name) {

        return modelService.getModelData(modelIds, labels, name);
    }

    @PostMapping(value = "", produces = "application/json;charset=UTF-8")
    public ResultVO addModelData(@RequestBody ModelDTO modelDTO) {


        return modelService.addModelData(modelDTO);
    }

    @PutMapping(value = "", produces = "application/json;charset=UTF-8")
    public ResultVO updateModelData(@RequestParam(value = "modelId", required = true)String modelId,
                                    @RequestParam(value = "type", required = false) String type,
                                    @RequestBody ModelDTO modelDTO) {

        return modelService.updateModelData(modelId, type, modelDTO);
    }

    @DeleteMapping(value = "/{modelId}", produces = "application/json;charset=UTF-8")
    public ResultVO deleteModelData(@PathVariable (required = true, value = "modelId")String [] modelIds) {

        return modelService.deleteModelData(modelIds);
    }


}
