package jp.co.brother.datadriver.exception;

public class AlreadyExistsException extends RuntimeException{

	/**
	 * Automatic generation
	 */
	private static final long serialVersionUID = -6946957056527600845L;
	
	public AlreadyExistsException () {}
	
	/* Call Throwable for exception handling */
	public AlreadyExistsException(String message) {
		super(message);
	}

}
