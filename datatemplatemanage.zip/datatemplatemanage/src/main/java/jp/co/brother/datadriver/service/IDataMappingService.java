package jp.co.brother.datadriver.service;

import java.util.List;
import java.util.Map;

import jp.co.brother.datadriver.domain.TemplateDO;
import jp.co.brother.datadriver.dto.TemplateMappingDTO;
import jp.co.brother.datadriver.vo.ResultVO;

public interface IDataMappingService {
	
	
	ResultVO templateAndModelMappingData(TemplateMappingDTO templateMappingDTO);
	
	ResultVO datasetToCase(List<TemplateDO> template, List<Map<String, String>> lists);
	
}
