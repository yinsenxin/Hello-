package jp.co.brother.datadriver.dao;

import java.util.Collection;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import com.mongodb.client.result.UpdateResult;

/**
 * Common classes for operating mongodb database
 * @author yinse
 *
 * @param <T>
 */
public abstract class AbstractMongo<T> implements IMongoDB<T>{
	
	@Autowired
    private MongoTemplate mongoTemplate;
	
	public abstract Class<T> getObjectClass();


	@Override
	public boolean exists(Query query) {
		return mongoTemplate.exists(query, getObjectClass());
	}

	@Override
	public List<T> find(Query query) {
		return mongoTemplate.find(query, getObjectClass());
	}

	@Override
	public T findOne(Query query) {
		return mongoTemplate.findOne(query, getObjectClass());
	}
	@Override
	public List<T> findAll() {
		return mongoTemplate.findAll(getObjectClass());
	}

	@Override
	public T findAndRemove(Query query) {
		 return mongoTemplate.findAndRemove(query, getObjectClass());
	}

	@Override
	public List<T> findAllAndRemove(Query query) {
		return mongoTemplate.findAllAndRemove(query, getObjectClass());
	}

	@Override
	public T insert(T objectToSave) {
		return mongoTemplate.insert(objectToSave);
	}

	@SuppressWarnings("hiding")
	@Override
	public <T> Collection<T> insertAll(Collection<T> t) {
		return mongoTemplate.insertAll(t);
	}

	@Override
	public T save(T objectToSave) {
		return mongoTemplate.save(objectToSave);
	}

	@Override
	public UpdateResult upsert(Query query, Update update) {
		return mongoTemplate.upsert(query, update, getObjectClass());
	}

	@Override
	public UpdateResult updateMulti(Query query, Update update) {
		return mongoTemplate.updateMulti(query, update, getObjectClass());
	}

	@Override
	public Long count(Query query) {
		return mongoTemplate.count(query, getObjectClass());
	}
}
