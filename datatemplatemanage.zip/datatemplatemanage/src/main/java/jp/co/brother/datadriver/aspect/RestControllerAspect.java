package jp.co.brother.datadriver.aspect;

import java.lang.reflect.Method;

import javax.servlet.http.HttpServletRequest;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;
import org.aspectj.lang.reflect.MethodSignature;
import org.springframework.stereotype.Component;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Aspect
@Component
public class RestControllerAspect {
	/**
     * 切面类中排除WebSocketServer。如果包含WebSocketServer的话，会导致程序启动时WebSocketServer类注册失败
     * http://www.pianshen.com/article/721751997/
     */
    @Pointcut("execution(* jp.co.brother.datadriver.controller.*Controller.*(..)) and @annotation(org.springframework.web.bind.annotation.RequestMapping)")
    private void cut() {
    }

    /**
     * 环绕通知
     * 
     * @param joinPoint
     *            连接点
     * @return 切入点返回值
     * @throws Throwable
     *             异常信息
     */
    @Around("cut()")
    public Object apiLog(ProceedingJoinPoint joinPoint) throws Throwable {
        MethodSignature signature = (MethodSignature) joinPoint.getSignature();
        Method method = signature.getMethod();// 获取被拦截的方法
        String methodName = method.getName(); // 获取被拦截的方法名

        ServletRequestAttributes attributes = (ServletRequestAttributes) RequestContextHolder.getRequestAttributes();
        HttpServletRequest request = attributes.getRequest();

        // 前处理
        String userAgent = request.getHeader("user-agent");
        log.info("Started request method [{}] params [{}] userAgent [{}]", methodName, "", userAgent);
        long start = System.currentTimeMillis();

        // 执行处理
        Object result = joinPoint.proceed();

        // 后处理
        log.info("Ended request method [{}] response is [{}] cost [{}] millis ", methodName, "",
                System.currentTimeMillis() - start);
        return result;
    }
}
