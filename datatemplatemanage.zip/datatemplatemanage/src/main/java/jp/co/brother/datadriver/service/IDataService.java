package jp.co.brother.datadriver.service;

import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletResponse;

import org.springframework.web.multipart.MultipartFile;

import jp.co.brother.datadriver.dto.DataDTO;
import jp.co.brother.datadriver.dto.DataInfoDTO;
import jp.co.brother.datadriver.vo.ResultVO;

public interface IDataService {
	
	/**
	 * Get all test data
	 * @param dataIds
	 * @param labels
	 * @param name
	 * @return
	 */
	ResultVO getTestData(String[] dataIds, String[] labels, String name);
	
	/**
	 * Add special data
	 * @param dataDTO
	 * @return
	 */
	ResultVO addTestData(DataDTO dataDTO);
	
	/**
	 * Modify special data
	 * @param dataId
	 * @param dataDTO
	 * @return
	 */
	ResultVO updateTestData(String dataId, DataDTO dataDTO);
	
	/**
	 * Delete special data
	 * @param dataIds
	 * @return
	 */
	ResultVO deleteTestData(String[] dataIds);
	
	/**
	 * Import data about test data
	 * @param modelId
	 * @param type
	 * @return
	 */
	ResultVO importTestData(MultipartFile file, String modelId, String dataId);
	
	/**
	 * Export data to caseManager 
	 * @param dataId
	 * @param response
	 */
	ResultVO exportTestData(String dataId);
	
	/**
	 * Export data to file 
	 * @param type
	 * @param dataId
	 * @return
	 */
	void exportDataSet(String type, DataInfoDTO dataInfoDTO, HttpServletResponse response);
	
	/**
	 * Export modelContent to file
	 * @param datas
	 */
	void exportModelContent(List<Map<String, String>> datas, HttpServletResponse response);
	
}



