package jp.co.brother.datadriver.dao;

import org.springframework.stereotype.Component;

import jp.co.brother.datadriver.domain.middle.LabelDataDO;

@Component
public class LabelDataDao extends AbstractMongo<LabelDataDO>{

	@Override
	public Class<LabelDataDO> getObjectClass() {
		
		return LabelDataDO.class;
	}

}
