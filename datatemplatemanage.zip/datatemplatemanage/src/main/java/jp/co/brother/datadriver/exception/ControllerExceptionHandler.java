package jp.co.brother.datadriver.exception;

import javax.servlet.http.HttpServletRequest;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import jp.co.brother.datadriver.constant.Constant;
import jp.co.brother.datadriver.vo.ResultVO;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@RestController
@ControllerAdvice
public class ControllerExceptionHandler {

    @ExceptionHandler(value = IllegalArgumentException.class)
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    public ResultVO illegalArgumentException(HttpServletRequest req, IllegalArgumentException e) {
        log.error(Constant.LOG_FORMAT, e.getClass().getName(), e.getMessage());
        ResultVO result = new ResultVO();
        result.setCode(HttpStatus.BAD_REQUEST.value());
        result.setMessage(e.getMessage());
        return result;
    }

    @ExceptionHandler(value = MethodArgumentNotValidException.class)
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    public ResultVO argumentNotValidExceptionHandler(HttpServletRequest req, MethodArgumentNotValidException e) {
        log.error(Constant.LOG_FORMAT, e.getClass().getName(), e.getMessage());
        ResultVO result = new ResultVO();
        result.setCode(HttpStatus.BAD_REQUEST.value());
        result.setMessage(e.getMessage());
        return result;
    }


    /**
     * In order to avoid FeignException, set the response status code to 404.
     * 
     * @param req
     * @param e
     * @return
     */
    @ExceptionHandler(value = DataNotFoundException.class)
    @ResponseStatus(HttpStatus.NOT_FOUND)
    public ResultVO dataNotFoundExceptionHandler(HttpServletRequest req, DataNotFoundException e) {
        ResultVO result = new ResultVO();
        result.setCode(HttpStatus.NOT_FOUND.value());
        result.setMessage(e.getMessage());
        return result;
    }
    
    /**
     * In order to avoid FeignException, set the response status code to 409.
     * @param req
     * @param e
     * @return
     */
    @ExceptionHandler(value = AlreadyExistsException.class)
    @ResponseStatus(HttpStatus.CONFLICT)
    public ResultVO alreadyExceptionHandler(HttpServletRequest req, AlreadyExistsException e) {
        ResultVO result = new ResultVO();
        result.setCode(HttpStatus.CONFLICT.value());
        result.setMessage(e.getMessage());
        return result;
    }
    
    /**
     * In order to avoid FeignException, set the response status code to 409.
     * @param req
     * @param e
     * @return
     */
    @ExceptionHandler(value = DataMappingException.class)
    @ResponseStatus(HttpStatus.NOT_FOUND)
    public ResultVO dataMappingExceptionHandler(HttpServletRequest req, DataMappingException e) {
        ResultVO result = new ResultVO();
        result.setCode(HttpStatus.NOT_FOUND.value());
        result.setMessage(e.getMessage());
        return result;
    }
    
    @ExceptionHandler(value = FileTypeException.class)
    @ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR)
    public ResultVO fileTypeExceptionHandler(HttpServletRequest req, FileTypeException e) {
        ResultVO result = new ResultVO();
        result.setCode(HttpStatus.INTERNAL_SERVER_ERROR.value());
        result.setMessage(e.getMessage());
        return result;
    }
    
    /**
     * In order to avoid FeignException, set the response status code to 500
     * @param req
     * @param e
     * @return
     */
    @ExceptionHandler(value = ReadFileException.class)
    @ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR)
    public ResultVO readFileExceptionHandler(HttpServletRequest req, ReadFileException e) {
        ResultVO result = new ResultVO();
        result.setCode(HttpStatus.INTERNAL_SERVER_ERROR.value());
        result.setMessage(e.getMessage());
        return result;
    }
    
    /**
     * In order to avoid FeignException, set the response status code to 500.
     * @param req
     * @param e
     * @return
     */
    @ExceptionHandler(Exception.class)
    @ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR)
    public ResultVO othersExceptionHandler(HttpServletRequest req, Exception e) {
        log.error(Constant.LOG_FORMAT, e.getClass().getName(), e.getMessage());
        ResultVO result = new ResultVO();
        result.setCode(HttpStatus.INTERNAL_SERVER_ERROR.value());
        result.setMessage(e.getMessage());
        return result;
    }
    
    
}
