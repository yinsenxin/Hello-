package jp.co.brother.datadriver.controller;

import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import jp.co.brother.datadriver.dto.DataDTO;
import jp.co.brother.datadriver.dto.DataInfoDTO;
import jp.co.brother.datadriver.service.IDataService;
import jp.co.brother.datadriver.vo.ResultVO;

@RestController
@RequestMapping("/datasets")
public class DataController {
	
	@Autowired
	private IDataService dataService;
	
	@Autowired
	private HttpServletResponse response;
	
	@GetMapping(value = "", produces = "application/json;charset=UTF-8")
	public ResultVO getDatas(@RequestParam(required = false, value = "datasetIds") String[] dataIds, 
					  @RequestParam(required = false, value = "labels") String[] labels, 
			          @RequestParam(required = false, value = "name") String name) {
		
		return dataService.getTestData(dataIds, labels, name);
	}
	
	@PostMapping(value = "", produces = "application/json;charset=UTF-8")
	public ResultVO addData(@RequestBody DataDTO dataDTO) {
		
		return dataService.addTestData(dataDTO);
	}
	
	@DeleteMapping(value = "/{datasetId}", produces = "application/json;charset=UTF-8")
	public ResultVO deleteData(@PathVariable(value = "datasetId", required = true) String[] dataIds) {
		
		return dataService.deleteTestData(dataIds);
	}
	
	@PutMapping(value = "/{datasetId}", produces = "application/json;charset=UTF-8")
	public ResultVO updateData(@PathVariable(required = true, value = "datasetId")String dataId, @RequestBody DataDTO dataDTO) {
		
		return dataService.updateTestData(dataId, dataDTO);
	}
	
	@PostMapping(value = "/parse")
	public ResultVO importData(MultipartFile file, @RequestParam(required = true, value = "modelId") String modelId,
							   @RequestParam(required = false, value = "datasetId") String dataId) {
		
		return dataService.importTestData(file, modelId, dataId);
	}
	
	@PostMapping(value = "/export/exportCase")
	public ResultVO exportDataCase(@RequestParam(required = true, value = "datasetId") String dataId) {
		return dataService.exportTestData(dataId);
	}
	
	@PostMapping(value = "/export")
	public void exportDataSet(DataInfoDTO dataInfoDTO, @RequestParam(required = true, value = "type") String type) {
		
		 dataService.exportDataSet(type, dataInfoDTO, response);
	}
	
	@PostMapping(value = "/export/datas")
	public void exportModelContent(List<Map<String, String>> datas) {
		dataService.exportModelContent(datas, response);
	}
	
}
