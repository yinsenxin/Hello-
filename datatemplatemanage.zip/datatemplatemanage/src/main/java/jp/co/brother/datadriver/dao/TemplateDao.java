package jp.co.brother.datadriver.dao;

import jp.co.brother.datadriver.domain.TemplateDO;
import org.springframework.stereotype.Component;

@Component
public class TemplateDao extends AbstractMongo<TemplateDO>{

	@Override
	public Class<TemplateDO> getObjectClass() {
		return TemplateDO.class;
	}

}
