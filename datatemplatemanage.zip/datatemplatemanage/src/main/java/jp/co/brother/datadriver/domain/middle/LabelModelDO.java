package jp.co.brother.datadriver.domain.middle;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.Field;

import lombok.Data;

@Data
@Document(collection = "label_model")
public class LabelModelDO {
	@Id
	private String id;

	@Field("label_id")
	private String labelId;

	@Field("model_id")
	private String modelId;
	
}
