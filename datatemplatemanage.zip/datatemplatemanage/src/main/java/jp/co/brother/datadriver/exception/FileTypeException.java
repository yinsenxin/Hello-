package jp.co.brother.datadriver.exception;

public class FileTypeException extends RuntimeException{

	/**
	 * Automatic generated
	 */
	private static final long serialVersionUID = 6930668584465975843L;
	
	public FileTypeException (String message) {
		super(message);
	}

}
