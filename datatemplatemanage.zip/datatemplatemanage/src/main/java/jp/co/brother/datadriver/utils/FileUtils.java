package jp.co.brother.datadriver.utils;

import java.io.File;

public class FileUtils {
	private FileUtils () {}
	
	 /**
     * Deletes an empty folder in the specified directory
     *
     * @param file
     */
	public static void clear(File file) {
        File[] listFiles = file.listFiles();
        for (File file2 : listFiles) {

            if (file2.isDirectory()) {
                clear(file2);
            } else {
            	file2.delete();
            }
        }
        file.delete();
    }
	
}
