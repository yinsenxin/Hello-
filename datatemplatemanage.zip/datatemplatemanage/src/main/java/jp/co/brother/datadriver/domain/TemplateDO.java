package jp.co.brother.datadriver.domain;

import java.util.List;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.Field;

import lombok.Data;

@Data
@Document(collection = "template")
public class TemplateDO {
	
	/**
	 * This is the id field of the templateDO
	 */
	@Id
	private String id;
	
	/**
	 * This is the name field of the templateDO
	 */
	private String name;
	
	/**
	 * This is the labels field of the templateDO
	 */
	private List<String> labels;
	
	/**
	 * This is the modelId field of the templateDO
	 */
	private String modelId;
	
	/**
	 * This is the content field of the templateDO
	 */
	private List<String> content;
	
	/**
	 * This is the description field of the templateDO
	 */
	private String description;
	
	/**
	 * This is the lastModifyDate field of the templateDO
	 */
	@Field("last_modify_date")
	private String lastModifyDate;
}
