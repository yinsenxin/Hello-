package jp.co.brother.datadriver.domain;

import java.util.List;
import java.util.Map;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.Field;

import jp.co.brother.datadriver.config.DataType;
import lombok.Data;

@Data
@Document(collection = "test_data")
public class DataDO {
	
	@Id
	private String id;
	
	private String name;
	
	@Field("label_id")
	private List<String> labels;
	
	@Field("model_id")
	private String modelId;
	
	@Field("template_id")
	private List<String> templates;
	
	@Field("model_content")
	private List<Map<String, String>> modelContent;
	
	private DataType type;
	
	@Field("last_modify_date")
	private String lastModifyDate;
	
	private String description;
	
}









