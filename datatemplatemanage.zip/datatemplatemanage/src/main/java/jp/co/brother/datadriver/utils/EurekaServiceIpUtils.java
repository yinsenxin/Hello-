package jp.co.brother.datadriver.utils;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.client.ServiceInstance;
import org.springframework.cloud.client.discovery.DiscoveryClient;
import org.springframework.cloud.netflix.eureka.EurekaDiscoveryClient;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
public class EurekaServiceIpUtils {
    @Autowired
    private DiscoveryClient discoveryClient;

    public String getHostPort(String serviceName) {
        List<ServiceInstance> serviceInstances = discoveryClient.getInstances(serviceName);
        String ip = null;
        if (!serviceInstances.isEmpty()) {
            String statusPageUrl = ((EurekaDiscoveryClient.EurekaServiceInstance) serviceInstances.get(0)).getInstanceInfo().getStatusPageUrl();
            ip = statusPageUrl.split("/swagger-ui")[0];
        }
        return ip;
    }

}
