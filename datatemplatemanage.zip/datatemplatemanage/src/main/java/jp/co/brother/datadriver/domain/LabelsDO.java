package jp.co.brother.datadriver.domain;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import lombok.Data;

@Data
@Document(collection = "labels")
public class LabelsDO {
	
	/**
	 * This is the id field of the labelsDO
	 */
	@Id
	private String id;
	
	/**
	 * This is the name field of the labelsDO
	 */
	private String name;
	
	/**
	 * This is the description field of the labelsDO
	 */
	private String description;
}
