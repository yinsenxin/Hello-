package jp.co.brother.datadriver.serviceimpl;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Objects;
import java.util.regex.Pattern;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.Assert;

import jp.co.brother.datadriver.constant.Constant;
import jp.co.brother.datadriver.dao.LabelTemplateDao;
import jp.co.brother.datadriver.dao.TemplateDao;
import jp.co.brother.datadriver.dao.TemplateModelDao;
import jp.co.brother.datadriver.domain.TemplateDO;
import jp.co.brother.datadriver.domain.middle.LabelTemplateDO;
import jp.co.brother.datadriver.domain.middle.TemplateModelDO;
import jp.co.brother.datadriver.dto.TemplateDTO;
import jp.co.brother.datadriver.exception.AlreadyExistsException;
import jp.co.brother.datadriver.exception.DataNotFoundException;
import jp.co.brother.datadriver.service.ITemplateService;
import jp.co.brother.datadriver.vo.ResultVO;

@Service
public class TemplateServiceImpl implements ITemplateService{
	
	@Autowired
	private TemplateDao templateDao;
	
	@Autowired
	private LabelTemplateDao labelTemplateDao;
	
	@Autowired
	private TemplateModelDao templateModelDao;
	
	/**
	 * Get All template about data
	 */
	@Override
	public ResultVO getTemplateData(String[] templateIds, String[] labels, String name) {
		ResultVO resultVO = new ResultVO(HttpStatus.OK);

		// Make Search about templateIds
		Query query = new Query();
		if (Objects.nonNull(templateIds) && templateIds.length > 0) {
			query.addCriteria(Criteria.where(Constant.TEMPLATE_ID).in((Object []) templateIds));
		}
		// Make Search about labels
		if (Objects.nonNull(labels) && labels.length > 0) {
			Query query2 = new Query();
			query2.addCriteria(Criteria.where(Constant.LABEL_TEMPLATE_LABELID).in((Object []) labels));
			List<LabelTemplateDO> find = labelTemplateDao.find(query2);
			List<String> templateId = new ArrayList<>();
			find.forEach(s -> templateId.add(s.getTemplateId()));
			query.addCriteria(Criteria.where(Constant.TEMPLATE_ID).in(templateId));
		}
		// Make Search about name
		if (StringUtils.isNotBlank(name)) {
			Pattern pattern = Pattern.compile(Constant.PATTERN_PREFIX + name + Constant.PATTERN_SUFFIX);
			query.addCriteria(Criteria.where(Constant.TEMPLATE_NAME).regex(pattern));
		}

		// Get all template data
		List<TemplateDO> templates = templateDao.find(query);

		// Get templateId
		List<String> templateId = new ArrayList<>();
		templates.forEach(s -> templateId.add(s.getId()));

		// Get LabelTemplate data
		Query query2 = new Query();
		query2.addCriteria(Criteria.where(Constant.LABEL_TEMPLATE_TEMPLATEID).in(templateId));
		List<LabelTemplateDO> labelTemplateDO = labelTemplateDao.find(query2);

		// Get TemplateModel data
		Query query3 = new Query();
		query3.addCriteria(Criteria.where(Constant.TEMPLATE_MODEL_TEMPLATEID).in(templateId));
		List<TemplateModelDO> templateModelDO = templateModelDao.find(query3);
		getLabelModelData(templates, labelTemplateDO, templateModelDO);
		
		resultVO.setData(templates);
		return resultVO;
		
	}
	
	@Override
	public ResultVO getValidTemplateData() {
		ResultVO resultVO = new ResultVO(HttpStatus.OK);

		// Make Search about templateIds
		Query query = new Query();
		// Get all template data
		List<TemplateDO> templates = templateDao.find(query);
		List<String> templateId = new ArrayList<>();
		templates.forEach(s -> templateId.add(s.getId()));

		Query query1 = new Query();
		query1.addCriteria(Criteria.where(Constant.TEMPLATE_MODEL_TEMPLATEID).in(templateId));
		List<TemplateModelDO> list = templateModelDao.find(query1);

		Iterator<TemplateDO> iterator = templates.iterator();
		while (iterator.hasNext()){
			TemplateDO templateDO = iterator.next();
			for (TemplateModelDO templateModelDO : list) {
				if(templateDO.getId().equals(templateModelDO.getTemplateId())){
					iterator.remove();
				}
			}
		}
		resultVO.setData(templates);
		return resultVO;
	}
	
	/**
	 * Add special template data
	 */
	@Override
	@Transactional
	public ResultVO addTemplateData(TemplateDTO templateDTO) {
		// Check the input parameter is valid
		checkParam(templateDTO);

		// Make Search
		Query query = new Query();
		query.addCriteria(Criteria.where(Constant.TEMPLATE_NAME).is(templateDTO.getName()));

		if (templateDao.exists(query)) {
			throw new AlreadyExistsException(Constant.ALREADY_EXCEPTION_TEMPLATE);
		}
		Date now = new Date();
		SimpleDateFormat dateFormat = new SimpleDateFormat(Constant.DATEFORMAT);
		templateDTO.setLastModifyDate(dateFormat.format(now));
		// Add template data to database
		TemplateDO templateDO = templateDao.insert(dtoToDO(templateDTO));
		// Add labelTemplate data to database
		if (!templateDTO.getLabels().isEmpty()) {
			addLabelTemplateData(templateDO.getId(), templateDTO.getLabels());
		}
		// Add TemplateModel data to database
		if (StringUtils.isNotBlank(templateDTO.getModelId())) {
			// insert new templateModel
			addTemplateModelData(templateDTO.getModelId(), templateDO.getId());
		}
		return new ResultVO(HttpStatus.OK);
	}

	/**
	 * Update special template data
	 */
	@Override
	@Transactional
	public ResultVO updateTemplateData(String templateId, TemplateDTO templateDTO) {
		// Check the input parameter is valid
		checkParam(templateId, templateDTO);

		// Make Search
		Query query = new Query();
		query.addCriteria(Criteria.where(Constant.TEMPLATE_ID).is(templateId));
		if (templateDao.exists(query)) {

			TemplateDO templateDO = templateDao.findOne(query);
			if (!templateDTO.getName().equals(templateDO.getName())) {
				throw new AlreadyExistsException(Constant.NONEDIT_EXCEPTION_TEMPLATE);
			}
			// lastModifyDate format
			Date now = new Date();
			SimpleDateFormat dateFormat = new SimpleDateFormat(Constant.DATEFORMAT);
			templateDTO.setLastModifyDate(dateFormat.format(now));

			TemplateDO templateDO2 = dtoToDO(templateDTO);
			replaceOldRecord(templateId, templateDO2);

			// edit labelTemplate data to database
			Query query3 = new Query();
			query3.addCriteria(Criteria.where(Constant.LABEL_TEMPLATE_TEMPLATEID).is(templateId));

			labelTemplateDao.findAllAndRemove(query3);
			// add labelTemplate data to database
			addLabelTemplateData(templateId, templateDTO.getLabels());

			// Make Search
			Query query1 = new Query();
			query1.addCriteria(Criteria.where(Constant.TEMPLATE_MODEL_TEMPLATEID).is(templateId));
			templateModelDao.findAllAndRemove(query1);
			// add templateModel data to database
			if (StringUtils.isNotBlank(templateDTO.getModelId())) {
				addTemplateModelData(templateDTO.getModelId(), templateId);
			}
		} else {
			throw new DataNotFoundException(Constant.DATA_NOTFOUND_EXCEPTION);
		}

		return new ResultVO(HttpStatus.OK);
	}
	
	/**
	 * Delete special template data by templateIds
	 */
	@Override
	@Transactional
	public ResultVO deleteTemplateData(String[] templateIds) {
		// Check the input parameter is valid
		Assert.notEmpty(templateIds, Constant.REQUEST_TEMPLATE_ID);

		// Make Search
		Query query = new Query();
		query.addCriteria(Criteria.where(Constant.TEMPLATE_ID).in((Object[]) templateIds));
		// Delete template data
		List<TemplateDO> template = templateDao.findAllAndRemove(query);
		List<String> templateId = new ArrayList<>();
		template.forEach(s -> templateId.add(s.getId()));
		// Make Search
		Query query2 = new Query();
		query2.addCriteria(Criteria.where(Constant.LABEL_TEMPLATE_TEMPLATEID).in(templateId));
		// Delete labelTemplate data
		labelTemplateDao.findAllAndRemove(query2);
		templateModelDao.findAllAndRemove(query2);

		return new ResultVO(HttpStatus.OK);
	}
	
	/**
	 * Add labelTemplate data to database
	 * @param templateId
	 * @param labels
	 */
	private void addLabelTemplateData (String templateId, List<String> labels){

		List<LabelTemplateDO> list = new ArrayList<>();
		for (String label : labels) {
			LabelTemplateDO labelTemplateDO = new LabelTemplateDO();
			labelTemplateDO.setTemplateId(templateId);
			labelTemplateDO.setLabelId(label);
			list.add(labelTemplateDO);
		}
		labelTemplateDao.insertAll(list);
	}

	/**
	 * Add templateModel data to database
	 * @param templateId
	 * @param modelId
	 */
	private void addTemplateModelData (String modelId, String templateId){
		TemplateModelDO templateModelDO = new TemplateModelDO();
		templateModelDO.setModelId(modelId);
		templateModelDO.setTemplateId(templateId);
		templateModelDao.insert(templateModelDO);
	}
	
	/**
	 * Get label and model data 
	 * @param templates
	 * @param labelTemplateDO
	 * @param templateModelDO
	 */
	private void getLabelModelData(List<TemplateDO> templates, List<LabelTemplateDO> labelTemplateDO, List<TemplateModelDO> templateModelDO) {
		// Get modelId data
		for (TemplateDO template : templates) {
			for (TemplateModelDO templateModel : templateModelDO) {
				if (template.getId().equals(templateModel.getTemplateId())) {
					template.setModelId(templateModel.getModelId());
				}
			}
			
		}
		// Get labelTemplate data
		for (TemplateDO template : templates) {
			List<String> list = new ArrayList<>();
			for (LabelTemplateDO labelTemplate : labelTemplateDO) {
				if (template.getId().equals(labelTemplate.getTemplateId())) {
					list.add(labelTemplate.getLabelId());
				}
			}
			template.setLabels(list);
		}
	}
	
	/**
	 * Update some fields 
	 * @param templateId
	 * @param templateDO
	 */
	private void replaceOldRecord(String templateId, TemplateDO templateDO) {
		/* Make search criteria */
		Query query = new Query();
		query.addCriteria(Criteria.where(Constant.TEMPLATE_ID).is(templateId));

		/* Make update */
		Update update = new Update();
		update.set(Constant.TEMPLATE_CONTENT, templateDO.getContent());
		update.set(Constant.TEMPLATE_LASTMODIFYDATE, templateDO.getLastModifyDate());
		update.set(Constant.TEMPLATE_DESCRIPTION, templateDO.getDescription());
		
		/* Update data */
		templateDao.upsert(query, update);
	}
	
	/**
	 * DTO --> DO 
	 * @param templateDTO
	 * @return
	 */
	private TemplateDO dtoToDO(TemplateDTO templateDTO) {
		TemplateDO templateDO = new TemplateDO();
		templateDO.setName(templateDTO.getName());
		templateDO.setContent(templateDTO.getContent() == null ? new ArrayList<>() : templateDTO.getContent());
		templateDO.setDescription(templateDTO.getDescription());
		templateDO.setLastModifyDate(templateDTO.getLastModifyDate());
		return templateDO;
	}

	
	/**
	 * Check the input parameter is valid
	 */
	private void checkParam(TemplateDTO templateDTO) {
		Assert.notNull(templateDTO, Constant.REQUEST_BODY_TEMPLATE);
		Assert.hasLength(templateDTO.getName(), Constant.REQUEST_TEMPLATE_NAME);
		Assert.notNull(templateDTO.getContent(), Constant.REQUEST_TEMPLATE_CONTENT);
	}
	
	/**
	 * Check the input parameter is valid
	 */
	private void checkParam(String templateId, TemplateDTO templateDTO) {
		Assert.hasLength(templateId, Constant.REQUEST_TEMPLATE_ID);
		Assert.notNull(templateDTO, Constant.REQUEST_BODY_TEMPLATE);
		Assert.hasLength(templateDTO.getName(), Constant.REQUEST_TEMPLATE_NAME);
		Assert.notNull(templateDTO.getContent(), Constant.REQUEST_TEMPLATE_CONTENT);
	}

}
