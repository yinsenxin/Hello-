package jp.co.brother.datadriver.constant;

public class Constant {

	private Constant() {}


	public static final String STRING_FORMAT ="\n";
	public static final String DBMANAGER_SERVER = "DBMANAGER";
	public static final Integer MODEL_STATUS_VALUE = 1;
	public static final String FILE_PATH = "\\";
	public static final String STRING_FORMAT_UNDERLINE = "_";
	public static final String CSV_CONDITIONS = ":";
	public static final String FILE_LAST_INDEXOF = ".";
	public static final String CSV_DATA_SPLIT = ",";
	public static final String CSV_AGGREGATE = ";";
	public static final String FILE_TYPE_CSV = "csv";
	public static final String FILES_TYPE_JSON = "json";
	public static final String LINE_SEPARATOR = "line.separator";
	public static final String IMPORTDATA_STATUS = "status";
	public static final String IMPORTDATA_STATUS_UPDATE = "update";
	public static final String IMPORTDATA_STATUS_ADD = "add";
	public static final String IMPORTDATA_STATUS_DELETE = "delete";
	public static final String CSV_SYMBOLS_STEPS = "steps_";
	public static final String CSV_SYMBOLS_STEP = "step";
	public static final String FILE_TEMP_NAME = "TempFiles";
	public static final String FILE_TEMPZIP_NAME = "Export.zip";
	public static final String EXPORT_DATA_NAME = "exportData";
	
	public static final String DATASET_TYPE_CASE = "case";
	public static final String DATASET_TYPE_FILE = "file";
	
	
	public static final Integer DATA_TYPE_CASE = 0;
	public static final Integer DATA_TYPE_FILE = 1;
	
	
	public static final Integer IMPORT_CASEID = 0;
	public static final Integer IMPORT_LABELS = 1;
	public static final Integer IMPORT_CONDITIONS = 2;
	public static final Integer IMPORT_TEMPLATE = 3;
	
	public static final String IMPORTDATA_CASEID = "CaseID";
	public static final String IMPORTDATA_LABELS = "labels";
	public static final String IMPORTDATA_CONDITIONS = "conditions";
	public static final String IMPORTDATA_TEMPLATE = "template";
	public static final String CASE_NAME= "name";
	public static final String CASE_DESCRIPTION = "description";
	
	public static final String IMPORTDATA_CASEID_EXISTS = "The same \"CaseID\" exists!";
	public static final String IMPORTDATA_CASEID_NOTEXISTS = "CaseID does not exist in the file!";
	public static final String IMPORTDATA_LABELS_NOTEXISTS = "labels does not exist in the file!";
	public static final String IMPORTDATA_CONDITIONS_NOTEXISTS = "conditions does not exist in the file!";
	public static final String IMPORTDATA_TEMPLATE_NOTEXISTS = "template does not exist in the file!";
	public static final String IMPORTDATA_MODELCONTENT_NOTEXISTS = "relevant data of model does not exist";
	public static final String IMPORTDATA_TEMPLATENAME_NOTEXISTS = "template name is not exists in model";
	
	// Log related information
	public static final String LOG_FORMAT = "{} : {}";
	public static final String LOG_FORMAT_SIMPLE = "{}";
	public static final String DATEFORMAT = "yyyy-MM-dd HH:mm:ss";
	public static final String PATTERN_PREFIX = "^.*";
	public static final String PATTERN_SUFFIX = ".*$";

	// There's a field for labels
	public static final String LABELS_ID = "_id";
	public static final String LABELS_NAME = "name";
	public static final String LABELS_DESCRIPTION = "description";

	// There's a field for model
	public static final String MODEL_ID = "_id";
	public static final String MODEL_NAME = "name";
	public static final String MODEL_STATUS = "status";
	public static final String MODEL_CONTENT = "content";
	public static final String MODEL_DESCRIPTION = "description";
	public static final String MODEL_LASTMODIFYDATE = "last_modify_date";

	// There's a field for template
	public static final String TEMPLATE_ID = "_id";
	public static final String TEMPLATE_NAME = "name";
	public static final String TEMPLATE_CONTENT = "content";
	public static final String TEMPLATE_DESCRIPTION = "description";
	public static final String TEMPLATE_LASTMODIFYDATE = "last_modify_date";

	// There's a field for LabelTemplate
	public static final String LABEL_TEMPLATE_ID = "_id";
	public static final String LABEL_TEMPLATE_TEMPLATEID = "template_id";
	public static final String LABEL_TEMPLATE_LABELID = "label_id";

	// There's a field for LabelModel
	public static final String LABEL_MODEL_ID = "_id";
	public static final String LABEL_MODEL_MODELID = "model_id";
	public static final String LABEL_MODEL_LABELID = "label_id";

	// There's a field for templateModel
	public static final String TEMPLATE_MODEL_ID = "_id";
	public static final String TEMPLATE_MODEL_MODELID = "model_id";
	public static final String TEMPLATE_MODEL_TEMPLATEID = "template_id";

	// There's a field for test_data
	public static final String TEST_DATA_ID = "_id";
	public static final String TEST_DATA_NAME = "name";
	public static final String TEST_DATA_LABELS = "label_id";
	public static final String TEST_DATA_MODELID = "model_id";
	public static final String TEST_DATA_TEMPLATES = "template_id";
	public static final String TEST_DATA_MODEL_CONTENT = "model_content";
	public static final String TEST_DATA_MODEL_CONTENT_TEMPLATE = "model_content.template";
	public static final String TEST_DATA_MODEL_TYPE = "type";
	public static final String TEST_DATA_LASTMODIFYDATE = "last_modify_date";
	public static final String TEST_DATA_DESCRIPTION = "description";

	// There's a field for LabelTestData
	public static final String LABEL_TESTDATA_ID = "_id";
	public static final String LABEL_TESTDATA_LABELID = "label_id";
	public static final String LABEL_TESTDATA_DATAID = "data_id";


	// Check parameter validity for labels
	public static final String REQUEST_BODY_LABELS = "Body of this request must not be null!";
	public static final String REQUEST_LABELS_ID = "labelId must not be null!";
	public static final String REQUEST_LABELS_NAME = "labelName must not be null!";

	// Check parameter validity for model
	public static final String REQUEST_BODY_MODEL = "Body of this request must not be null!";
	public static final String REQUEST_MODEL_ID = "modelId must not be null!";
	public static final String REQUEST_MODEL_NAME = "modelName must not be null!";
	public static final String REQUEST_MODEL_STATUS = "modelStatus must not be null!";
	public static final String REQUEST_MODEL_CONTENT = "modelContent must not be null!";

	// Check parameter validity for template
	public static final String REQUEST_BODY_TEMPLATE = "Body of this request must not be null!";
	public static final String REQUEST_TEMPLATE_ID = "templateId must not be null!";
	public static final String REQUEST_TEMPLATE_NAME = "templateName must not be null!";
	public static final String REQUEST_TEMPLATE_CONTENT = "templateContent must not be null!";
	public static final String REQUEST_TEMPLATE = "template must not be null!";
	public static final String REQUEST_TEMPLATE_MODELDATA = "tempalteData must not be null!";

	// Check parameter validity for data
	public static final String REQUEST_BODY_TESEDATA = "Body of this request must not be null!";
	public static final String REQUEST_TESTDATA_ID = "dataId must not be null!";
	public static final String REQUEST_TESTDATA_NAME = "dataName must not be null!";
	public static final String REQUEST_TESTDATA_MODEL = "modelId must not be null!";
	public static final String REQUEST_TESTDATA_CONTENT = "content must not be null!";
	public static final String REQUEST_TESTDATA_TYPE = "type must not be null!";
	public static final String ASSERT_REQUEST_CASEFILE = "The uploaded file is empty!";



	// Exception information
	public static final String MODELID_NOTFOUND_EXCEPTION = "modelId data not found!";
	public static final String DATA_NOTFOUND_EXCEPTION = "Target data not found!";
	public static final String MODELDATA_NOTFOUND_EXCEPTION = "Model data not found!";
	public static final String DATASET_DATA_NOTFOUND_EXCEPTION = "DataSet data not found!";
	public static final String ALREADY_EXCEPTION_LABELS = "The \"labelName\" has already exists!";
	public static final String ALREADY_EXCEPTION_TEMPLATE = "The \"templateName\" has already exists!";
	public static final String ALREADY_EXCEPTION_MODEL = "The \"modelName\" has already exists!";
	public static final String ALREADY_EXCEPTION_TESTDATA = "The \"dataName\" has already exists!";
	public static final String NONEDIT_EXCEPTION_TEMPLATE = "The templateName cannot be edit!";
	public static final String NONEDIT_EXCEPTION_MODEL = "The modelName cannot be edit!";
	public static final String DATAMAPPING_EXCEPTION = 	"Mismatched data in template and model data!";
	public static final String ALREADY_EXCEPTION_TEMPLATEMODEL = "Template is already bound!";
	public static final String FILE_TYPE_FAILED = "Please select the correct file type such as CSV";
	public static final String FILE_EMPTY_FAIED = "The uploaded file is empty";
	public static final String READ_FILE_FAILED = "An exception occurred while reading the file";
	public static final String EXPORT_FILE_FIALED = "Error occurred while export case data";
	public static final String DELETE_FILE_FAIED = "Deleting the file failed= {}";

	public static final String INVALID_DOCUMENT = "Invalid document";
	public static final String DATATYPE_ILLEGAL = "Illegal dataType. DataType should be \"case\" OR \"file\"!";
	public static final String MODELID_NOT_USE = "UnReleased modelId cannot be used";
	public static final String ALREADY_CSVFILE_SAME_HEAD = "The same attribute exists in the CSV file header";
	public static final String EXPORT_DATA_TYPE = "The dataset type must be case or file";
	public static final String IMPORT_DATA_CONDITIONS = "Conditions must be is key:value";
	public static final String CASEMANAGE_SERVER_FAILD = "CaseManager server is invalid!";
	
	public static final String IMPORT_DATA_INVAILD = "Check if the CSV file is valid";
	
	
	// CSV 
	public static final String EMPTY_STRING = "";
	public static final String CODE_FORMART = "GBK";
	public static final String CODE_UTF_FORMART = "UTF-8";
	public static final String TIME_FORMAT_STYLE01 = "yyyyMMddHHmmssSSS";
	public static final String FILES_TYPE_CSV = ".csv";
	public static final String HEADER_CONTENT = "Content-Disposition";
    public static final String HEADER_CONTENTTYPE = "attachment;fileName=";
    public static final String HEADER_CONTENTLENGTH = "Content-Length";
    public static final String HEADER_PRAGMA = "Pragma";
    public static final String HEADER_PUBLIC = "public";
    public static final String HEADER_CACHE = "Cache-Control";
    public static final String HEADER_MAXAGE = "max-age=30";
    public static final String CONTENT_TYPE = "application/octet-stream";
    public static final String CSV_HEAD_CONTENT = "labels,conditions,name,description,";
    public static final String EXPORT_PREFIX = "CaseExport_";
    public static final String FILE_WRITE_FAIED = "File writing to disk failed";
	

}
