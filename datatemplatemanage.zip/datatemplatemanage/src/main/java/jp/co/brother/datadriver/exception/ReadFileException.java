package jp.co.brother.datadriver.exception;

public class ReadFileException extends RuntimeException{

	/**
	 * Automatic generated
	 */
	private static final long serialVersionUID = -878496888741277565L;
	
	public ReadFileException(String message) {
		super(message);
	}

}
