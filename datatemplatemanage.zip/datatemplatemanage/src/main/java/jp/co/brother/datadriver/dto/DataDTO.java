package jp.co.brother.datadriver.dto;

import java.util.List;
import java.util.Map;

import lombok.Data;

@Data
public class DataDTO {
	
	private String id;
	
	private String name;
	
	private List<String> labels;
	
	private String modelId;
	
	private List<String> templates;
	
	private List<Map<String, String>> modelContent;
	
	private String type;
	
	private String lastModifyDate;
	
	private String description;
}
