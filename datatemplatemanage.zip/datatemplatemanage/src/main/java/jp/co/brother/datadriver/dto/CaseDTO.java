package jp.co.brother.datadriver.dto;

import java.util.List;
import java.util.Map;

import lombok.Data;

@Data
public class CaseDTO {
	/**
	 * The unique ID of the CaseDTO data.
	 */
    private String id;
    /**
	 * The name of the CaseDTO data;
	 */
    private String name;
    /**
	 * The conditions of the CaseDTO data;
	 */
    private Map<String, String> conditions;
    /**
   	 * The labels of the CaseDTO data;
   	 */
    private List<String> labels;
    /**
   	 * The steps of the CaseDTO data;
   	 */
    private List<String> steps;
    /**
   	 * The description of the CaseDTO data;
   	 */
    private String description;
}
