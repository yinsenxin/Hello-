package jp.co.brother.datadriver.utils;

import java.io.IOException;
import java.io.OutputStream;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletResponse;

import jp.co.brother.datadriver.constant.Constant;
import lombok.extern.slf4j.Slf4j;


@Slf4j
public class CsvUtils {
	
	private CsvUtils() {}

    /**
     * CSV文件列分隔符
     */
    private static final String CSV_COLUMN_SEPARATOR = ",";

    /**
     * CSV文件行分隔符
     */
    private static final String CSV_ROW_SEPARATOR = "\r\n";

    /**
     * @param dataList 集合数据
     * @param titles   表头部数据
     * @param keys     表内容的键值
     * @param os       输出流
     * @throws IOException 
     * @throws  
     */
    public static void doExport(List<Map<String, Object>> dataList, List<StringBuilder> titles, OutputStream os) throws IOException {
		
    	List<String> titleArr = new ArrayList<>();
    	
    	for (StringBuilder stringBuilder : titles) {
			String[] split = stringBuilder.toString().split(CSV_ROW_SEPARATOR);
			List<String> asList = Arrays.asList(split);
			titleArr.addAll(asList);
		}
    	
    	for (int i = 0; i < dataList.size(); i++) {
    		StringBuilder buf = new StringBuilder();
    		// 2.组装表头
			buf.append(titleArr.get(i)).append(CSV_COLUMN_SEPARATOR);
    		buf.append(CSV_ROW_SEPARATOR);
    		
    		String string = titleArr.get(i);
    		Map<String, Object> map = dataList.get(i);
    		String[] split = string.split(",");
    		for (String string2 : split) {
    			buf.append(map.get(string2));
    			buf.append(CSV_COLUMN_SEPARATOR);
			}
    		buf.append(CSV_ROW_SEPARATOR);
			os.write(buf.toString().getBytes(Constant.CODE_FORMART));
		}
		// 4.写出响应
		os.flush();
		os.close();
    }

    /**
       * 设置Header 
     *
     * @param fileName
     * @param response
     * @throws UnsupportedEncodingException
     */
    public static void responseSetProperties(String fileName, HttpServletResponse response, String suffix) {
		// 1.设置文件后缀
		SimpleDateFormat sdf = new SimpleDateFormat(Constant.TIME_FORMAT_STYLE01);
		String fn = fileName + sdf.format(new Date()) + Constant.FILE_LAST_INDEXOF + suffix;
		// 2.设置响应
		response.setContentType(Constant.CONTENT_TYPE);
		response.setCharacterEncoding(Constant.CODE_UTF_FORMART);
		response.setHeader(Constant.HEADER_PRAGMA, Constant.HEADER_PUBLIC);
		response.setHeader(Constant.HEADER_CACHE, Constant.HEADER_MAXAGE);
		try {
			response.setHeader(Constant.HEADER_CONTENT,
					Constant.HEADER_CONTENTTYPE + URLEncoder.encode(fn, Constant.CODE_UTF_FORMART));
		} catch (UnsupportedEncodingException e) {
			log.warn(Constant.LOG_FORMAT_SIMPLE, e);
		}
    }

}
