package jp.co.brother.datadriver.serviceimpl;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.Assert;

import jp.co.brother.datadriver.constant.Constant;
import jp.co.brother.datadriver.dao.LabelDataDao;
import jp.co.brother.datadriver.dao.LabelModelDao;
import jp.co.brother.datadriver.dao.LabelTemplateDao;
import jp.co.brother.datadriver.dao.LabelsDao;
import jp.co.brother.datadriver.domain.LabelsDO;
import jp.co.brother.datadriver.dto.LabelsDTO;
import jp.co.brother.datadriver.exception.AlreadyExistsException;
import jp.co.brother.datadriver.exception.DataNotFoundException;
import jp.co.brother.datadriver.service.ILabelsService;
import jp.co.brother.datadriver.vo.ResultVO;

@Service
public class LabelsServiceImpl implements ILabelsService{

	@Autowired
	private LabelsDao labelsDao;
	
	@Autowired
	private LabelTemplateDao labelTemplateDao;
	
	@Autowired
	private LabelModelDao labelModelDao;
	
	@Autowired
	private LabelDataDao labelDataDao;

	@Override
	public ResultVO getLabelsData(String[] labelsId) {
		ResultVO resultVO = new ResultVO(HttpStatus.OK);
		
		// Make Search
		Query query = new Query();
		if (Objects.nonNull(labelsId) && labelsId.length > 0) {
			query.addCriteria(Criteria.where(Constant.LABELS_ID).in((Object[]) labelsId));
		}
		
		List<LabelsDTO> list = new ArrayList<>();
		List<LabelsDO> labelsDOs = labelsDao.find(query);
		
		labelsDOs.forEach(labelsDO -> list.add(doToDTO(labelsDO)));
		resultVO.setData(list);
		return resultVO;
	}
	
	@Override
	public ResultVO getLabelsDataById(String[] labelId) {
		ResultVO resultVO = new ResultVO(HttpStatus.OK);
		
		// Make Search
		if (Objects.nonNull(labelId) && labelId.length > 0) {
			Query query = new Query();
			query.addCriteria(Criteria.where(Constant.LABELS_ID).in((Object[]) labelId));
			 List<LabelsDO> find = labelsDao.find(query);
			resultVO.setData(find);
		} else {
			resultVO.setData(new ArrayList<>());
		}
		
		return resultVO;
	}

	@Override
	@Transactional
	public ResultVO addLabelsData(LabelsDTO labelsDTO) {
		// Check the input parameter is valid
		checkParam(labelsDTO);
		
		ResultVO resultVO = new ResultVO(HttpStatus.OK);
		LabelsDO labelsDO = dtoToDO(labelsDTO);
		
		// Make Search
		Query query = new Query();
		query.addCriteria(Criteria.where(Constant.LABELS_NAME).is(labelsDTO.getName()));
		
		if(labelsDao.exists(query)) {
			throw new AlreadyExistsException(Constant.ALREADY_EXCEPTION_LABELS);
		}
		LabelsDO labelsDOs = labelsDao.insert(labelsDO);
		
		resultVO.setData(labelsDOs.getId());
		return resultVO;
	}

	@Override
	@Transactional
	public ResultVO deleteLabelsData(String[] ids) {
		// Check the input parameter is valid
		Assert.notEmpty(ids, Constant.REQUEST_LABELS_ID);

		// Make Search
		Query query = new Query();
		query.addCriteria(Criteria.where(Constant.LABELS_ID).in((Object[]) ids));
		labelsDao.findAllAndRemove(query);

		Query query1 = new Query();
		query1.addCriteria(Criteria.where(Constant.LABEL_TEMPLATE_LABELID).in((Object[]) ids));
		// delete labelTemplate data
		labelTemplateDao.findAllAndRemove(query1);
		// delete labelModel data
		labelModelDao.findAllAndRemove(query1);
		// delete labelData data
		labelDataDao.findAllAndRemove(query1);
		
		return new ResultVO(HttpStatus.OK);
	}

	@Override
	@Transactional
	public ResultVO updateLabelsData(String labelsId, LabelsDTO labelsDTO) {
		// Check the input parameter is valid
		checkParam(labelsId, labelsDTO);

		Query query = new Query();
		query.addCriteria(Criteria.where(Constant.LABELS_ID).is(labelsId));

		if (labelsDao.exists(query)) {
			LabelsDO labelsDOs = labelsDao.findOne(query);
			if (!labelsDTO.getName().equals(labelsDOs.getName())) {
				Query query1 = new Query();
				query1.addCriteria(Criteria.where(Constant.LABELS_NAME).is(labelsDTO.getName()));
				if (labelsDao.exists(query1)) {
					throw new AlreadyExistsException(Constant.ALREADY_EXCEPTION_LABELS);
				}
			}
			LabelsDO labelsDO = dtoToDO(labelsDTO);
			replaceOldRecord(labelsId, labelsDO);

		} else {
			throw new DataNotFoundException(Constant.DATA_NOTFOUND_EXCEPTION);
		}

		return new ResultVO(HttpStatus.OK);
	}

	/**
	 * 
	 * @param labelId
	 * @param labelsDO
	 */
	private void replaceOldRecord(String labelId, LabelsDO labelsDO) {
		/* Make search criteria */
		Query query = new Query();
		query.addCriteria(Criteria.where(Constant.LABELS_ID).is(labelId));

		/* Make update */
		Update update = new Update();
		update.set(Constant.LABELS_NAME, labelsDO.getName());
		update.set(Constant.LABELS_DESCRIPTION, labelsDO.getDescription());

		/* Update data */
		labelsDao.upsert(query, update);
	}

	/**
	 * DTO --> DO
	 * @param labelsDTO
	 * @return
	 */
	private LabelsDO dtoToDO(LabelsDTO labelsDTO){
		LabelsDO labelsDO = new LabelsDO();
		labelsDO.setName(labelsDTO.getName());
		labelsDO.setDescription(labelsDTO.getDescription());
		return labelsDO;
	}

	/**
	 * DO --> DTO
	 * @param labelsDO
	 * @return
	 */
	private LabelsDTO doToDTO(LabelsDO labelsDO){
		LabelsDTO labelsDTO = new LabelsDTO();
		labelsDTO.setId(labelsDO.getId());
		labelsDTO.setName(labelsDO.getName());
		labelsDTO.setDescription(labelsDO.getDescription());
		return labelsDTO;
	}

	/**
	 * Check the input parameter is valid
	 */
	private void checkParam(LabelsDTO labelsDTO){
		Assert.notNull(labelsDTO, Constant.REQUEST_BODY_LABELS);
		Assert.hasLength(labelsDTO.getName(), Constant.REQUEST_LABELS_NAME);
	}

	/**
	 * Check the input parameter is valid
	 * @param labelId
	 * @param labelsDTO
	 */
	private void checkParam(String labelId, LabelsDTO labelsDTO){
		Assert.notNull(labelId, Constant.REQUEST_LABELS_ID);
		Assert.notNull(labelsDTO, Constant.REQUEST_BODY_LABELS);
		Assert.hasLength(labelsDTO.getName(), Constant.REQUEST_LABELS_NAME);
	}

}
