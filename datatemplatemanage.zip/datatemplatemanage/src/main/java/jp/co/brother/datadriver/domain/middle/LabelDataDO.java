package jp.co.brother.datadriver.domain.middle;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.Field;

import lombok.Data;

@Data
@Document(collection = "label_data")
public class LabelDataDO {
	
	@Id
	private String id;
	
	@Field("label_id")
	private String labelId;
	
	@Field("data_id")
	private String dataId;
	
	
	
}
