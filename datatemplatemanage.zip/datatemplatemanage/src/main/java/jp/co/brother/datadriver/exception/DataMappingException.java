package jp.co.brother.datadriver.exception;

public class DataMappingException extends RuntimeException{

	/**
	 * Automatic generation
	 */
	private static final long serialVersionUID = -8233731464796170768L;
	
	public DataMappingException () {}
	
	/* Call Throwable for exception handling */
	public DataMappingException (String message) {
		
		super(message);
	}
	
}
