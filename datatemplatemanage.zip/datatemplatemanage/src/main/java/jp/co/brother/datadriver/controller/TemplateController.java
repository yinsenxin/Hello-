package jp.co.brother.datadriver.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import jp.co.brother.datadriver.dto.TemplateDTO;
import jp.co.brother.datadriver.service.ITemplateService;
import jp.co.brother.datadriver.vo.ResultVO;

@RestController
@RequestMapping("/templates")
public class TemplateController {
	
	@Autowired
	private ITemplateService templateService;
	
	
	@GetMapping(value = "", produces = "application/json;charset=UTF-8")
	public ResultVO getTemplateData(@RequestParam (required = false, value = "templateIds") String[] templateIds,
									@RequestParam (required = false, value = "labels") String[] labels,
									@RequestParam (required = false, value = "name") String name ) {	
		
		return templateService.getTemplateData(templateIds, labels, name);
	}
	
	@GetMapping(value = "/valid", produces = "application/json;charset=UTF-8")
	public ResultVO getValidTemplateData() {

		return templateService.getValidTemplateData();
	}
	
	@PostMapping(value = "", produces = "application/json;charset=UTF-8")
	public ResultVO addTemplateData(@RequestBody TemplateDTO templateDTO) {
		
		return templateService.addTemplateData(templateDTO);
	}
	
	@DeleteMapping(value = "/{templateId}", produces = "application/json;charset=UTF-8")
	public ResultVO deleteTemplateData(@PathVariable (required = true, value = "templateId") String[] templateIds) {
		
		return templateService.deleteTemplateData(templateIds);
	}
	
	@PutMapping(value = "/{templateId}", produces = "application/json;charset=UTF-8")
	public ResultVO updateTemplateData(@PathVariable (required = true, value = "templateId") String templateId, 
									   @RequestBody TemplateDTO templateDTO) {
		
		return templateService.updateTemplateData(templateId, templateDTO);
	}
	
}





