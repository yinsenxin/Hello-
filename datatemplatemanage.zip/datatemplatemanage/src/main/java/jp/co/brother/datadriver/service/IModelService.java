package jp.co.brother.datadriver.service;

import jp.co.brother.datadriver.dto.ModelDTO;
import jp.co.brother.datadriver.vo.ResultVO;

public interface IModelService {
	
	/**
	 * Get all model data
	 * @param modelIds
	 * @param labels
	 * @param name
	 * @return
	 */
	ResultVO getModelData(String[] modelIds, String[] labels, String name);
	
	/**
	 * Get special modal data
	 * @param modelId
	 * @return
	 */
	ResultVO getModelDataById(String[] modelIds);
	
	/**
	 * Add special model data
	 * @param modelDTO
	 * @return
	 */
	ResultVO addModelData(ModelDTO modelDTO);
	
	/**
	 * Update special model data by Id
	 * @param modelId
	 * @param modelDTO
	 * @return
	 */
	ResultVO updateModelData(String modelId, String type, ModelDTO modelDTO);
	
	/**
	 * Delete special model data by Id
	 * @param modelIds
	 * @return
	 */
	ResultVO deleteModelData(String[] modelIds);
	
	
}
