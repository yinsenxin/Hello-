package jp.co.brother.datadriver.vo;

import org.springframework.http.HttpStatus;

import lombok.Data;

/**
 * 
 * @author yinse
 *
 */
@Data
public class ResultVO {
	/**
	 * Encapsulated return status code
	 */
	private Integer code;
	/**
	 * Encapsulated return information
	 */
	private String message;
	/**
	 * Encapsulated return data
	 */
	private Object data;
	/**
	 * Encapsulated return content
	 */
	private Object content;
	
	
    public ResultVO(Integer code, String msg) {
        this.code = code;
        this.message = msg;
    }
    
    public ResultVO(HttpStatus status) {
        this.code = status.value();
        this.message = status.getReasonPhrase();
    }

	public ResultVO() {
		super();
	}
}
