package jp.co.brother.datadriver.controller;

import jp.co.brother.datadriver.dto.LabelsDTO;
import jp.co.brother.datadriver.service.ILabelsService;
import jp.co.brother.datadriver.vo.ResultVO;
import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/labels")
public class LabelsController {

    @Autowired
    private ILabelsService labelsService;

    @GetMapping(value = "", produces = "application/json;charset=UTF-8")
    public ResultVO getLabelsData(@RequestParam (value = "labelsId" , required = false) String[] labelsId){

        return labelsService.getLabelsData(labelsId);
    }
    
    @GetMapping(value = "/label", produces = "application/json;charset=UTF-8")
    public ResultVO getLabelsDataById(@RequestParam (value = "labelIds" , required = true) String[] labelId) {
    	return labelsService.getLabelsDataById(labelId);
    }
    
    @PostMapping(value = "", produces = "application/json;charset=UTF-8")
    public ResultVO addLabelsData(@RequestBody LabelsDTO labelsDTO){

        return labelsService.addLabelsData(labelsDTO);
    }

    @DeleteMapping(value = "/{labelsId}", produces = "application/json;charset=UTF-8")
    public ResultVO deleteLabelsData(@PathVariable(value = "labelsId", required = true) String[] labelsIds){
        return labelsService.deleteLabelsData(labelsIds);
    }

    @PutMapping(value = "/{labelsId}", produces = "application/json;charset=UTF-8")
    public ResultVO updateLabelsData(@PathVariable(value = "labelsId", required = true) String labelsId ,
                                    @RequestBody LabelsDTO labelsDTO){
        return labelsService.updateLabelsData(labelsId, labelsDTO);

    }
}
