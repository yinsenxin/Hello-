package jp.co.brother.datadriver.dto;

import lombok.Data;

@Data
public class DataInfoDTO {
	private String dataId;
}
