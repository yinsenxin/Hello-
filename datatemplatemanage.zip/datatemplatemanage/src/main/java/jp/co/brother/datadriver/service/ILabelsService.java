package jp.co.brother.datadriver.service;

import jp.co.brother.datadriver.dto.LabelsDTO;
import jp.co.brother.datadriver.vo.ResultVO;

public interface ILabelsService {
	
	/**
	 * Gets all labels data
	 * @return
	 */
	ResultVO getLabelsData(String[] labelsId);
	
	/**
	 * Gets special labels data
	 * @param id
	 * @return
	 */
	ResultVO getLabelsDataById(String[] id);
	
	/**
	 * Add special labels data
	 * @param labelsDTO
	 * @return
	 */
	ResultVO addLabelsData(LabelsDTO labelsDTO);
	
	/**
	 * Delete special labels data
	 * @param ids
	 * @return
	 */
	ResultVO deleteLabelsData(String[] ids);
	
	/**
	 * Update special labels data
	 * @param id
	 * @param labelsDTO
	 * @return
	 */
	ResultVO updateLabelsData(String id, LabelsDTO labelsDTO);
	
}
