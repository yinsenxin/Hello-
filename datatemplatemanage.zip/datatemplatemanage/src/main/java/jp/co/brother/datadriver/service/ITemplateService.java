package jp.co.brother.datadriver.service;

import jp.co.brother.datadriver.dto.TemplateDTO;
import jp.co.brother.datadriver.vo.ResultVO;

public interface ITemplateService {
	
	ResultVO getTemplateData(String[] templateIds, String[] labels, String name);
	
	ResultVO getValidTemplateData();
	
	ResultVO addTemplateData(TemplateDTO templateDTO);
	
	ResultVO updateTemplateData(String templateId, TemplateDTO templateDTO);
	
	ResultVO deleteTemplateData(String[] templateIds);
	
}
