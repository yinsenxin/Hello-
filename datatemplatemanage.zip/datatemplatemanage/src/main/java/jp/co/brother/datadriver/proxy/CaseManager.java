package jp.co.brother.datadriver.proxy;

import java.util.List;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PostMapping;

import jp.co.brother.datadriver.dto.CaseDTO;
import jp.co.brother.datadriver.vo.ResultVO;

@FeignClient(name = "DBMANAGER", fallback = FeignHystrix.class)
public interface CaseManager {
	
 	@PostMapping(value = "/cases/addAll", produces = "application/json;charset=UTF-8")
    ResultVO addAllCase(List<CaseDTO> cases);
}
