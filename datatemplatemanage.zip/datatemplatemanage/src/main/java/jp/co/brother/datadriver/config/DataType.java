package jp.co.brother.datadriver.config;

public enum DataType {
	
	TYPE_CASE(0),TYPE_FILE(1);
	
	private Integer value;
	
	
	private DataType(Integer value) {
		this.value = value;
	}
	
	public Integer getValue() {
		
		return value;
	}
	
	
	
}
