package jp.co.brother.datadriver.dao;

import org.springframework.stereotype.Component;

import jp.co.brother.datadriver.domain.middle.LabelModelDO;

@Component
public class LabelModelDao extends AbstractMongo<LabelModelDO>{

	@Override
	public Class<LabelModelDO> getObjectClass() {
		return LabelModelDO.class;
	}

}
