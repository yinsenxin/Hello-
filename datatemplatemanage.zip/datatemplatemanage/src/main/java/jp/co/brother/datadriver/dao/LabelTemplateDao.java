package jp.co.brother.datadriver.dao;

import org.springframework.stereotype.Component;

import jp.co.brother.datadriver.domain.middle.LabelTemplateDO;

@Component
public class LabelTemplateDao extends AbstractMongo<LabelTemplateDO>{

	@Override
	public Class<LabelTemplateDO> getObjectClass() {
		return LabelTemplateDO.class;
	}

}
