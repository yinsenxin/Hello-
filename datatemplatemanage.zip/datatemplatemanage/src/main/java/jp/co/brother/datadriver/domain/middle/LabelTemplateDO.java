package jp.co.brother.datadriver.domain.middle;


import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import lombok.Data;
import org.springframework.data.mongodb.core.mapping.Field;

@Data
@Document(collection = "label_template")
public class LabelTemplateDO {
	
	@Id
	private String id;

	@Field("label_id")
	private String labelId;

	@Field("template_id")
	private String templateId;
}
