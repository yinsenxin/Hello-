package jp.co.brother.datadriver.dao;

import org.springframework.stereotype.Component;

import jp.co.brother.datadriver.domain.LabelsDO;

@Component
public class LabelsDao extends AbstractMongo<LabelsDO>{

	@Override
	public  Class<LabelsDO> getObjectClass() {

		return LabelsDO.class;
	}


}
