package jp.co.brother.datadriver.dto;

import java.util.List;
import java.util.Map;

import lombok.Data;

@Data
public class TemplateMappingDTO {
	
	/**
	 * template content data
	 */
	private List<String> templateContent;
	
	/**
	 * model content data
	 */
	private Map<String, String> modelContent;
}
