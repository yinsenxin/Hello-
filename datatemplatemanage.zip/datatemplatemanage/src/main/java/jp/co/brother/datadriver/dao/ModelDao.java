package jp.co.brother.datadriver.dao;

import jp.co.brother.datadriver.domain.ModelDO;
import org.springframework.stereotype.Component;

@Component
public class ModelDao extends AbstractMongo<ModelDO>{

	@Override
	public Class<ModelDO> getObjectClass() {
		return ModelDO.class;
	}

}
