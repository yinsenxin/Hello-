package jp.co.brother.datadriver.controller;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

import jp.co.brother.datadriver.constant.Constant;
import jp.co.brother.datadriver.utils.EurekaServiceIpUtils;

@Controller
public class FreeMarkerController {
	
	@Autowired
	private EurekaServiceIpUtils eurekaServiceIpUtils;

	@GetMapping(value="/label")
    public String getLabels() {
        return "label";
    }
    
	@GetMapping(value="/model")
    public String getModel() {
        return "model";
    }

    @GetMapping(value="/template")
    public String getTemplate() {
        return "template";
    }
    
    @GetMapping(value = "/data")
    public String getData(Map<String, String> map) {
    	String hostPort = eurekaServiceIpUtils.getHostPort(Constant.DBMANAGER_SERVER);
    	map.put("serviceName", hostPort);
    	return "data";
    }

}
