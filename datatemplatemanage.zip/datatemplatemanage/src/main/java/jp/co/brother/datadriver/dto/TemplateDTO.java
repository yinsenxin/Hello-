package jp.co.brother.datadriver.dto;

import java.util.List;

import lombok.Data;

@Data
public class TemplateDTO {
	
	/**
	 * This is the id field of the templateDTO
	 */
	private String id;
	
	/**
	 * This is the name field of the templateDTO
	 */
	private String name;
	
	/**
	 * This is the labels field of the templateDTO
	 */
	private List<String> labels; 
	
	/**
	 * This is the modelId field of the templateDTO
	 */
	private String modelId;
	
	/**
	 * This is the content field of the templateDTO
	 */
	private List<String> content;
	
	/**
	 * This is the description field of the templateDTO
	 */
	private String description;
	
	/**
	 * This is the lastModifyDate field of the templateDTO
	 */
	private String lastModifyDate;
}		
