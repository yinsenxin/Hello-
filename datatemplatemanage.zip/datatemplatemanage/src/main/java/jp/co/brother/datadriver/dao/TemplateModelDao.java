package jp.co.brother.datadriver.dao;

import org.springframework.stereotype.Component;

import jp.co.brother.datadriver.domain.middle.TemplateModelDO;

@Component
public class TemplateModelDao extends AbstractMongo<TemplateModelDO>{

	@Override
	public Class<TemplateModelDO> getObjectClass() {

		return TemplateModelDO.class;
	}
	
}
