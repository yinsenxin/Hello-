package jp.co.brother.datadriver.exception;

public class DataNotFoundException extends RuntimeException {
    /**
     * Automatic generated
     */
    private static final long serialVersionUID = -219272517885606807L;

    public DataNotFoundException(String s) {
        super(s);
    }
}