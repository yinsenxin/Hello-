package jp.co.brother.datadriver.domain.middle;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.Field;

import lombok.Data;

@Data
@Document(collection = "template_model")
public class TemplateModelDO {
	
	@Id
	private String id;

	@Field("model_id")
	private String modelId;

	@Field("template_id")
	private String templateId;

}
