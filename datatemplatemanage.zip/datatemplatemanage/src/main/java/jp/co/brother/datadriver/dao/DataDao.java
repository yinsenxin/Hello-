package jp.co.brother.datadriver.dao;

import org.springframework.stereotype.Component;

import jp.co.brother.datadriver.domain.DataDO;

@Component
public class DataDao extends AbstractMongo<DataDO>{

	@Override
	public Class<DataDO> getObjectClass() {
		
		return DataDO.class;
	}

}
