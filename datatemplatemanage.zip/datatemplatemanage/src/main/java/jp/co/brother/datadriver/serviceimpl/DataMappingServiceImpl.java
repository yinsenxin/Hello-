package jp.co.brother.datadriver.serviceimpl;

import java.io.StringWriter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.velocity.VelocityContext;
import org.apache.velocity.app.Velocity;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.util.Assert;

import jp.co.brother.datadriver.constant.Constant;
import jp.co.brother.datadriver.domain.TemplateDO;
import jp.co.brother.datadriver.dto.TemplateMappingDTO;
import jp.co.brother.datadriver.service.IDataMappingService;
import jp.co.brother.datadriver.vo.ResultVO;

@Service
public class DataMappingServiceImpl implements IDataMappingService{

	@Override
	public ResultVO templateAndModelMappingData(TemplateMappingDTO templateMappingDTO) {
		// Check input parameter is valid
		checkParam(templateMappingDTO);

		ResultVO resultVO = new ResultVO(HttpStatus.OK);
		
		// Get template data
		StringBuilder sb = new StringBuilder();
		List<String> templateContent = templateMappingDTO.getTemplateContent();
		for (String string : templateContent) {
			sb.append(string);
			sb.append(Constant.STRING_FORMAT);
		}
		
		Map<String, String> map = new HashMap<>();
		Map<String, String> modelContent = templateMappingDTO.getModelContent();
		for (Map.Entry<String, String> entry : modelContent.entrySet()) {
			String key = entry.getKey();
			String value = entry.getValue();
			String[] split = value.split("  ");
			map.put(key, key + split[0]);
		}
		
		String string = sb.toString();
		StringWriter result = new StringWriter();
		VelocityContext context = new VelocityContext(map);
		Velocity.evaluate(context, result, Constant.IMPORTDATA_TEMPLATE, string);
		resultVO.setData(result.toString());
		return resultVO;
	}
	
	/**
	 * Check input Parameter is valid
	 * @param templateMappingDTO
	 */
	private void checkParam(TemplateMappingDTO templateMappingDTO) {
		
		Assert.notNull(templateMappingDTO, Constant.REQUEST_BODY_MODEL);
		Assert.notEmpty(templateMappingDTO.getTemplateContent(), Constant.REQUEST_TEMPLATE_MODELDATA);
		
	}

	@Override
	public ResultVO datasetToCase(List<TemplateDO> template, List<Map<String, String>> lists) {
		Assert.notEmpty(lists, Constant.REQUEST_TESTDATA_CONTENT);
		List<Map<String, List<String>>> templateData = new ArrayList<>();
		ResultVO resultVO = new ResultVO(HttpStatus.OK);
		List<String> empty = new ArrayList<>();
		// template data
		for (Map<String, String> map : lists) {
			Map<String, List<String>> maps = new HashMap<>();
			for (TemplateDO templateDO : template) {
				if (map.get(Constant.IMPORTDATA_TEMPLATE).equals(templateDO.getName())) {
					maps.put(map.get(Constant.IMPORTDATA_TEMPLATE), templateDO.getContent());
				} else if (map.get(Constant.IMPORTDATA_TEMPLATE).equals("")) {
					maps.put(map.get(Constant.IMPORTDATA_TEMPLATE), empty);
				}
			}
			templateData.add(maps);
		}
		List<StringBuilder> str = new ArrayList<>();
		for (Map<String, List<String>> map : templateData) {
			StringBuilder sb = new StringBuilder();
			for (Map.Entry<String, List<String>> entry : map.entrySet()) {
				List<String> value = entry.getValue();
				for (String templateContent : value) {
					sb.append(templateContent);
					sb.append(Constant.STRING_FORMAT);
				}
			}
			str.add(sb);
		}
		resultVO.setData(str);
		return resultVO;
	}

}
